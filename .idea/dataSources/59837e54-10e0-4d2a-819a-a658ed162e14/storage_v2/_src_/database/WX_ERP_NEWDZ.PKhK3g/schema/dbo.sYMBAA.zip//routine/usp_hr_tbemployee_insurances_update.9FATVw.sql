/*
 begin tran
exec usp_hr_tbemployee_insurances_update

select employee_id,identitycard,company_id,* from iw_tbemployees where employee_id = 1111

select employee_id,identitycard,company_id,* from  hr_tbemployee_perinfs where employee_id = 1111
--delete from hr_tbemployee_insurances where employee_id = 18
rollback tran
commit tran


insert into hr1
select * from wx_erp_newdz..hr1

drop PROCEDURE usp_iw_tbemployees_update

*/
create PROCEDURE usp_hr_tbemployee_insurances_update 
as
declare
	@employee_id int,
	@employee_no varchar(6),
	@company_id int,
	@ERP_ID varchar (6)  ,
	@kq_no varchar (6) ,
	@employee_name varchar (20) ,
	@employee_state varchar (1) ,
	@fcmc_type varchar (2) ,
	@worktype_no varchar (2) ,
	@business_no varchar (2) ,
	@scfcc_type varchar (1) ,
	@work_time_type varchar (50) ,
	@employee_sex varchar (1) ,
	@birthday datetime  ,
	@identitycard varchar (18) ,
	@sb_num varchar (20) ,
	@marriage varchar (1) ,
	@polity varchar (1) ,
	@edulevel varchar (1) ,
	@address varchar (50) ,
	@condition varchar (1) ,
	@firstwork_date datetime  ,
	@telephone1 varchar (20) ,
	@telephone2 varchar (20) ,
	@begin_date datetime  ,
	@end_date datetime  ,
	@note varchar (100) ,
	@ht_begin_dt datetime  ,
	@ht_end_dt datetime  
-- 
-- sp_help hr_tbemployee_insurances
-- 
-- select * from hr_tbemployee_insurances
-- select * from hr_tbemployee_perinfs
DECLARE HR_C1 SCROLL CURSOR FOR

     select iw_tbemployees.employee_id,iw_tbemployees.employee_no ,
	    hr_tbemployee_perinfs.ht_begin_dt,hr_tbemployee_perinfs.ht_end_dt
       from iw_tbemployees ,hr_tbemployee_perinfs where hr_tbemployee_perinfs.employee_id =iw_tbemployees.employee_id and employee_state = '1'

OPEN  HR_C1

FETCH NEXT FROM HR_C1 INTO 	@employee_id ,@employee_no ,@ht_begin_dt,@ht_end_dt

WHILE (@@FETCH_STATUS = 0)
BEGIN

		 insert into hr_tbemployee_insurances (insurance_type,begin_date,end_date,employee_id,company_id,create_user_no,create_datetime,register_date)

	              values('01',@ht_begin_dt,@ht_end_dt,@employee_id,0,'admin',getdate(),getdate())
	
		    IF  @@ERROR <> 0 OR @@ROWCOUNT = 0
		    BEGIN
		        RAISERROR('HR_TBEMPLOYEE_PERINFS INSERT ERROR',16,-1)
			CLOSE HR_C1
			DEALLOCATE HR_C1
		        RETURN -1
		    END  
	
		 insert into hr_tbemployee_insurances (insurance_type,begin_date,end_date,employee_id,company_id,create_user_no,create_datetime,register_date)

	              values('02',@ht_begin_dt,@ht_end_dt,@employee_id,0,'admin',getdate(),getdate())
	
		    IF  @@ERROR <> 0 OR @@ROWCOUNT = 0
		    BEGIN
		        RAISERROR('HR_TBEMPLOYEE_PERINFS INSERT ERROR',16,-1)
			CLOSE HR_C1
			DEALLOCATE HR_C1
		        RETURN -1
		    END  

		 insert into hr_tbemployee_insurances (insurance_type,begin_date,end_date,employee_id,company_id,create_user_no,create_datetime,register_date)

	              values('03',@ht_begin_dt,@ht_end_dt,@employee_id,0,'admin',getdate(),getdate())
	
		    IF  @@ERROR <> 0 OR @@ROWCOUNT = 0
		    BEGIN
		        RAISERROR('HR_TBEMPLOYEE_PERINFS INSERT ERROR',16,-1)
			CLOSE HR_C1
			DEALLOCATE HR_C1
		        RETURN -1
		    END  
   		 insert into hr_tbemployee_insurances (insurance_type,begin_date,end_date,employee_id,company_id,create_user_no,create_datetime,register_date)

	              values('04',@ht_begin_dt,@ht_end_dt,@employee_id,0,'admin',getdate(),getdate())
	
		    IF  @@ERROR <> 0 OR @@ROWCOUNT = 0
		    BEGIN
		        RAISERROR('HR_TBEMPLOYEE_PERINFS INSERT ERROR',16,-1)
			CLOSE HR_C1
			DEALLOCATE HR_C1
		        RETURN -1
		    END  

   		 insert into hr_tbemployee_insurances (insurance_type,begin_date,end_date,employee_id,company_id,create_user_no,create_datetime,register_date)

	              values('05',@ht_begin_dt,@ht_end_dt,@employee_id,0,'admin',getdate(),getdate())
	
		    IF  @@ERROR <> 0 OR @@ROWCOUNT = 0
		    BEGIN
		        RAISERROR('HR_TBEMPLOYEE_PERINFS INSERT ERROR',16,-1)
			CLOSE HR_C1
			DEALLOCATE HR_C1
		        RETURN -1
		    END  

--    		 insert into hr_tbemployee_insurances (insurance_type,begin_date,end_date,employee_id,company_id,create_user_no,create_datetime,register_date)
-- 
-- 	              values('09',@ht_begin_dt,@ht_end_dt,@employee_id,0,'admin',getdate(),getdate())
-- 	
-- 		    IF  @@ERROR <> 0 OR @@ROWCOUNT = 0
-- 		    BEGIN
-- 		        RAISERROR('HR_TBEMPLOYEE_PERINFS INSERT ERROR',16,-1)
-- 			CLOSE HR_C1
-- 			DEALLOCATE HR_C1
-- 		        RETURN -1
-- 		    END  
-- 




	FETCH NEXT FROM HR_C1 INTO 	@employee_id ,@employee_no ,@ht_begin_dt,@ht_end_dt
END 

CLOSE HR_C1
DEALLOCATE HR_C1




CREATE VIEW dbo.xs_vwxsfhjsd_lines_2
AS
SELECT *
FROM dbo.xs_tbxsfhjsd_lines
UNION ALL
SELECT *
FROM dbo.xs_tbxsfhjsd_lines_level2



CREATE VIEW dbo.jp_test_cpckd_lines
AS
SELECT dbo.kc_tbCpckd_lines.ck_date, dbo.kc_tbCpckd_lines.ck_weight, 
      dbo.kc_tbCpckd_lines.cklx_no, dbo.kc_tbCpckd_lines.ck_framework_no, 
      dbo.kc_tbCpckd_lines.ck_thdh_no, dbo.kc_tbCpckd_lines.cprkd_lines_id, 
      dbo.kc_tbCprkd_lines.cppm_no, dbo.kc_tbCprkd_lines.cpgg, 
      dbo.kc_tbCprkd_lines.cpgg_color, dbo.kc_tbCprkd_lines.quality_level, 
      dbo.kc_tbCprkd_lines.cpjh, dbo.kc_tbCpkchzs.weight, dbo.kc_tbCpkchzs.rk_weight, 
      dbo.kc_tbCpkchzs.hz_month
FROM dbo.kc_tbCpkchzs INNER JOIN
      dbo.kc_tbCprkd_lines ON 
      dbo.kc_tbCpkchzs.cprkd_line_id = dbo.kc_tbCprkd_lines.id INNER JOIN
      dbo.kc_tbCpckd_lines ON 
      dbo.kc_tbCprkd_lines.id = dbo.kc_tbCpckd_lines.cprkd_lines_id



CREATE VIEW dbo.wj_vwcl_rk90
AS
SELECT dbo.wj_tbClrkd_lines.cl_id, dbo.wj_tbClrkd_lines.ckdd_no, 
      dbo.wj_tbClrkd_lines.fkd_synum, dbo.wj_tbClrkds.company_id, 
      dbo.wj_tbClrkd_lines.fkd_synum2, dbo.wj_tbClrkd_lines.rkd_money
FROM dbo.wj_tbClrkds INNER JOIN
      dbo.wj_tbClrkd_lines ON 
      dbo.wj_tbClrkds.clrkd_id = dbo.wj_tbClrkd_lines.clrkd_id
WHERE (DATEDIFF([day], dbo.wj_tbClrkds.create_datetime, GETDATE()) <= 90) AND 
      (dbo.wj_tbClrkd_lines.fkd_synum > 0)



CREATE VIEW xs_vwxsckd_lines_3 AS SELECT * FROM xs_tbxsckd_lines UNION SELECT * FROM xs_tbxsckd_lines_level2 UNION SELECT * FROM xs_tbxsckd_lines_level3

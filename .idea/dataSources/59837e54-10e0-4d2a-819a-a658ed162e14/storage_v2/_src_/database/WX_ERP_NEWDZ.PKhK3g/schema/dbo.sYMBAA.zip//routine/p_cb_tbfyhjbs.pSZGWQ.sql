







-- 
-- if  object_id('p_iw_tbemployees')>0
-- DROP PROCEDURE dbo.p_iw_tbemployees;

--sp_help cb_tbfydjs
/*
select * from cb_tbfydjs  where working_proceduer_no = '0017'
select M11,* from cb_tbfyhjbs where line_no = '0017'and  wk_yymm = '2016'order by wlmc_no1,wlmc_no2,wlmc_no3 
select M3,* from cb_tbfyhjbs  where   wk_yymm = '2016' and line_no = '0017'  order by line_no,wlmc_no1,wlmc_no2,wlmc_no3
*/
-- sp_help  cb_tbfyhjbs

--select * from  cb_tbfyhjbs where   wk_yymm = '2016'order by wlmc_no1,wlmc_no2,wlmc_no3 

--delete from cb_tbfydjs
--exec p_cb_tbfyhjbs '999','201803','0017'
CREATE           procedure [dbo].[p_cb_tbfyhjbs] (	@spid		int,
					@wk_yymm 	varchar(6),
					@line_no	varchar(4))
as
BEGIN
   
 declare @wk_yy		varchar(4),
	 @wk_mm		varchar(2),
	 @wk_last_yy	varchar(4),
 	 @wlmc_no1	varchar(4),
 	 @wlmc_no2	varchar(4),
 	 @wlmc_no3	varchar(4),
 	 @wlmc_name1	varchar(50),
 	 @wlmc_name2	varchar(50),
 	 @wlmc_name3	varchar(50),
 	 @weight	numeric(18,6),
 	 @weight_cl	numeric(18,6),	--产量
 	 @je		numeric(18,6),
	 @je_hj		numeric(18,6),
	 @dj		numeric(18,6),
	 @sql		varchar(6000)
--set @wk_yymm = '201611'
--set @line_no = '0026'
set @wk_yy  	= substring(@wk_yymm,1,4)
set @wk_mm   	= cast(cast(substring(@wk_yymm,5,2) as int) as varchar(2))
set @wk_last_yy	= convert(varchar(04),dateadd(year,-1,@wk_yymm+'01'),112)

--1.年初插入表头
-- select 1 from cb_tbfyhjbs where wk_yymm = @wk_yy
-- if @@rowcount = 0
-- BEGIN 
-- 	print @@rowcount
-- 	insert into cb_tbfyhjbs (id,wk_yymm,line_no,wlmc_no1,wlmc_name1,wlmc_no2,wlmc_name2,wlmc_no3,wlmc_name3,create_datetime,create_user_no,company_id,data_id)
-- 	select id,@wk_yy,line_no,wlmc_no1,wlmc_name1,wlmc_no2,wlmc_name2,wlmc_no3,wlmc_name3 ,getdate(),'admin',0,0
-- 	from cb_tbfyhjbs
-- 	where wk_yymm = @wk_last_yy
-- END

-- delete from cb_tbfyhjbs where wk_yymm = @wk_yy
-- 
-- insert into cb_tbfyhjbs (id,wk_yymm,line_no,wlmc_no1,wlmc_name1,wlmc_no2,wlmc_name2,wlmc_no3,wlmc_name3,create_datetime,create_user_no,company_id,data_id)
-- select distinct id,'2016', working_proceduer_no,a.wlmc_no1,b.wl_name,a.wlmc_no2,c.wlpm_add_name,a.wlmc_no3,d.wlpm_add_name3,getdate(),'admin',0,0
--   from cb_tbfydjs a,cb_tbwlpms b,cb_tbwlpm_adds c,cb_tbwlpm_adds3 d
--  where a.wk_yymm = '201611'
--    and a.wlmc_no1 = b.wl_no
--    and a.wlmc_no2 *= c.wlpm_add_no
--    and a.wlmc_no3 *= d.wlpm_add_no3
-- 

--2.滞空当月数据0
  SET @sql = 'update cb_tbfyhjbs set m' + @wk_mm + '=' + cast(0 as varchar(24))
     	   + ' where wk_yymm = ' + '''' + @wk_yy + ''''
  exec(@sql)
 	--   + ' and line_no = ' + '''' + @line_no + ''''

--2.insert
DECLARE cb_tbfyhjbs_c1 CURSOR FOR 
	
	select working_proceduer_no,a.wlmc_no1,b.wl_name,isnull(a.wlmc_no2,''),isnull(c.wlpm_add_name,''),isnull(a.wlmc_no3,''),isnull(d.wlpm_add_name3,''),a.weight,a.je
          from cb_tbfydjs a inner join cb_tbwlpms b on a.wlmc_no1 = b.wl_no
		       left outer join cb_tbwlpm_adds c on  a.wlmc_no2 = c.wlpm_add_no
			   left outer join cb_tbwlpm_adds3 d on a.wlmc_no3 = d.wlpm_add_no3
          where a.wk_yymm = @wk_yymm
           and a.working_proceduer_no = @line_no
 
OPEN cb_tbfyhjbs_c1  
FETCH NEXT FROM cb_tbfyhjbs_c1 into @line_no,@wlmc_no1,@wlmc_name1,@wlmc_no2,@wlmc_name2,@wlmc_no3,@wlmc_name3,@weight,@je
WHILE @@FETCH_STATUS = 0
    BEGIN
		select @weight_cl = a.weight	
          from cb_tbfydjs a inner join cb_tbwlpms b on a.wlmc_no1 = b.wl_no
		       left outer join cb_tbwlpm_adds c on  a.wlmc_no2 = c.wlpm_add_no
			   left outer join cb_tbwlpm_adds3 d on a.wlmc_no3 = d.wlpm_add_no3
         where a.wk_yymm = @wk_yymm
           and a.working_proceduer_no =  @line_no
		   and a.wlmc_no1 = '01' --产量

	if isnull(@weight_cl,0) = 0	 --0的时候
		begin 
			select @je_hj = sum(isnull(je,0)),@dj = 0
			  from cb_tbfydjs a inner join cb_tbwlpms b on a.wlmc_no1 = b.wl_no
					left outer join cb_tbwlpm_adds c on  a.wlmc_no2 = c.wlpm_add_no
					left outer join cb_tbwlpm_adds3 d on a.wlmc_no3 = d.wlpm_add_no3
		     where a.wk_yymm = @wk_yymm
		           and a.working_proceduer_no =  @line_no
				   and a.wlmc_no1 not in ('01','02','03','04','13')  --成本项目合计
		end
	else 
		begin 
			select @je_hj = sum(isnull(je,0)),@dj = sum(isnull(je,0))/@weight_cl
		      from cb_tbfydjs a inner join cb_tbwlpms b on a.wlmc_no1 = b.wl_no
				   left outer join cb_tbwlpm_adds c on  a.wlmc_no2 = c.wlpm_add_no
				   left outer join cb_tbwlpm_adds3 d on a.wlmc_no3 = d.wlpm_add_no3
		     where a.wk_yymm = @wk_yymm
		       and a.working_proceduer_no =  @line_no
			   and a.wlmc_no1 not in ('01','02','03','04','13')  --成本项目合计
		end

-- print @line_no + '|' + @wlmc_name1+ '|' + @wlmc_name2 + '|' + @wlmc_name3 + '|' + cast(@weight_cl as varchar(24))
-- print @line_no + '|' + @wlmc_no1+ '|' + @wlmc_no2 + '|' + @wlmc_no3

	if @wlmc_no1 in ( '01')	--1.产量
		begin 
			print @line_no + ',' +@wlmc_no1 + ',' + cast(@weight as varchar(30))
		  SET @sql = 'update cb_tbfyhjbs set m' + @wk_mm + '=' + cast(@weight as varchar(30))
			   + ' where wk_yymm = ' + '''' + @wk_yy + ''''
			   + ' and line_no = ' + '''' + @line_no + ''''
			   + ' and isnull(wlmc_no1,'''') = ' + '''' + @wlmc_no1 + ''''
			   + ' and isnull(wlmc_no2,'''') = ' + '''' + @wlmc_no2 + ''''
			   + ' and isnull(wlmc_no3,'''') = ' + '''' + @wlmc_no3 + ''''
			exec(  @sql)
		end
	--if @wlmc_no1 in ( '04a')	
		begin --1.合计
		  SET @sql = 'update cb_tbfyhjbs set m' + @wk_mm + '=' + cast(@je_hj as varchar(30))
			   + ' where wk_yymm = ' + '''' + @wk_yy + ''''
			   + ' and line_no = ' + '''' + @line_no + ''''
			   + ' and isnull(wlmc_no1,'''') = ' + '''' + '04' + 'a'+''''
			exec(  @sql)
		end
	--if @wlmc_no1 in ( '04b')	
		begin --1.TON/rmb
		  SET @sql = 'update cb_tbfyhjbs set m' + @wk_mm + '=' + cast(@dj as varchar(30))
			   + ' where wk_yymm = ' + '''' + @wk_yy + ''''
			   + ' and line_no = ' + '''' + @line_no + ''''
			   + ' and isnull(wlmc_no1,'''') = ' + '''' + '04' + 'b'+''''
			exec(  @sql)
		end

	if @wlmc_no1 in ( '02','03','04','05','06','10','11','12','13')	--1.成材率,A级品率,B级品率,工资,折旧,修理费用,公摊费用,大修理费用,废料价值
		begin 
		  SET @sql = 'update cb_tbfyhjbs set m' + @wk_mm + '=' + cast(@je as varchar(30))
		     	   + ' where wk_yymm = ' + '''' + @wk_yy + ''''
		           + ' and line_no = ' + '''' + @line_no + ''''
		           + ' and isnull(wlmc_no1,'''') = ' + '''' + @wlmc_no1 + ''''
		           + ' and isnull(wlmc_no2,'''') = ' + '''' + @wlmc_no2 + ''''
		           + ' and isnull(wlmc_no3,'''') = ' + '''' + @wlmc_no3 + ''''

		   exec(  @sql)
		end
        /*------二级-------*/
	IF @wlmc_no1 in ( '07','08','09') and 
           @wlmc_no2 in ( '0701','0702','0703','0805','0906','0802','0803','0907','0904','0807','0808','0809','0901','0911','0912','0913','0914','0915','0916','0917','0918','0919','0920')	
			--1.电费,蒸气,天然气,锡,清洗剂,锌,锌铝合金,耐指纹涂料,盐酸,轧制油,轧辊,液氨,五金材料,包装材料,砂轮,胶辊,挤水辊,沉没辊,毛刷辊',电机风机,辐射管,片碱,钝化液
		BEGIN 
		  --主要信息
		  SET @sql = 'update cb_tbfyhjbs set m' + @wk_mm + '=' + cast(@je as varchar(30))
		     	   + ' where wk_yymm = ' + '''' + @wk_yy + ''''
		           + ' and line_no = ' + '''' + @line_no + ''''
		           + ' and isnull(wlmc_no1,'''') = ' + '''' + @wlmc_no1 + ''''
		           + ' and isnull(wlmc_no2,'''') = ' + '''' + @wlmc_no2 + ''''
		           + ' and isnull(wlmc_no3,'''') = ' + '''' + @wlmc_no3 + ''''
		   exec(  @sql)
		  IF @weight_cl <> 0 
			  BEGIN 
-- 				PRINT @wlmc_no1
-- 				PRINT @wlmc_no2
-- 				PRINT @wlmc_no3
-- 				PRINT @weight_cl
-- 				PRINT @je/@weight_cl
-- 				PRINT @je/@weight
-- 				PRINT @weight
				  --明细信息a --电费单耗（金额）=电费（金额）/产量
				  SET @sql = 'update cb_tbfyhjbs set m' + @wk_mm + '=' + cast(round(@je/@weight_cl,4) as varchar(30))       
				     	   + ' where wk_yymm = ' + '''' + @wk_yy + ''''
				           + ' and line_no = ' + '''' + @line_no + ''''
				           + ' and isnull(wlmc_no1,'''') = ' + '''' + @wlmc_no1 + ''''
				           + ' and isnull(wlmc_no2,'''') = ' + '''' + @wlmc_no2 + 'a'+''''
				         --  + ' and isnull(wlmc_no3,'''') = ' + '''' + @wlmc_no3 + 'a'+''''
				   exec(  @sql)
				  --明细信息b --电费单耗（度/吨）=用电度数/产量
				  SET @sql = 'update cb_tbfyhjbs set m' + @wk_mm + '=' + cast(round(@weight/@weight_cl,4) as varchar(30))
				     	   + ' where wk_yymm = ' + '''' + @wk_yy + ''''
				           + ' and line_no = ' + '''' + @line_no + ''''
				           + ' and isnull(wlmc_no1,'''') = ' + '''' + @wlmc_no1 + ''''
				           + ' and isnull(wlmc_no2,'''') = ' + '''' + @wlmc_no2 +'b'+ ''''
				        --   + ' and isnull(wlmc_no3,'''') = ' + '''' + @wlmc_no3 +'b'+ ''''
				   exec(  @sql)
				  IF @weight <> 0
				  	BEGIN 
						PRINT @weight
						  --明细信息c --电费单价（元/度）=电费金额/用电度数
						  SET @sql = 'update cb_tbfyhjbs set m' + @wk_mm + '=' + cast(round(@je/@weight,4) as varchar(30))
						     	   + ' where wk_yymm = ' + '''' + @wk_yy + ''''
						           + ' and line_no = ' + '''' + @line_no + ''''
						           + ' and isnull(wlmc_no1,'''') = ' + '''' + @wlmc_no1 + ''''
						           + ' and isnull(wlmc_no2,'''') = ' + '''' + @wlmc_no2 +'c'+ ''''
					--	           + ' and isnull(wlmc_no3,'''') = ' + '''' + @wlmc_no3 +'c'+ ''''
						   exec(  @sql)
					END
			   END
		END	
        /*------三级-------*/	
	IF @wlmc_no1 in ( '09') and 
           @wlmc_no2 in ( '0902') and
	   @wlmc_no3 in ( '9201','9202','9203','9204','9205','9206','9207','9208','9209','9210')--1.抗磨液压油,机械油,美孚齿轮油,磨削液,机床导轨油,主轴油,工业齿轮油	柴油,防锈油,其他油
		BEGIN 
		  --主要信息
		  SET @sql = 'update cb_tbfyhjbs set m' + @wk_mm + '=' + cast(@je as varchar(30))
		     	   + ' where wk_yymm = ' + '''' + @wk_yy + ''''
		           + ' and line_no = ' + '''' + @line_no + ''''
		           + ' and isnull(wlmc_no1,'''') = ' + '''' + @wlmc_no1 + ''''
		           + ' and isnull(wlmc_no2,'''') = ' + '''' + @wlmc_no2 + ''''
		           + ' and isnull(wlmc_no3,'''') = ' + '''' + @wlmc_no3 + ''''
		   exec(  @sql)
		  IF @weight_cl <> 0 
			  BEGIN 
				  --明细信息a --电费单耗（金额）=电费（金额）/产量
				  SET @sql = 'update cb_tbfyhjbs set m' + @wk_mm + '=' + cast(round(@je/@weight_cl,4) as varchar(30))       
				     	   + ' where wk_yymm = ' + '''' + @wk_yy + ''''
				           + ' and line_no = ' + '''' + @line_no + ''''
				           + ' and isnull(wlmc_no1,'''') = ' + '''' + @wlmc_no1 + ''''
				           + ' and isnull(wlmc_no2,'''') = ' + '''' + @wlmc_no2 + ''''
				           + ' and isnull(wlmc_no3,'''') = ' + '''' + @wlmc_no3 + 'a'+''''
				   exec(  @sql)
				  --明细信息b --电费单耗（度/吨）=用电度数/产量
				  SET @sql = 'update cb_tbfyhjbs set m' + @wk_mm + '=' + cast(round(@weight/@weight_cl,4) as varchar(30))
				     	   + ' where wk_yymm = ' + '''' + @wk_yy + ''''
				           + ' and line_no = ' + '''' + @line_no + ''''
				           + ' and isnull(wlmc_no1,'''') = ' + '''' + @wlmc_no1 + ''''
				           + ' and isnull(wlmc_no2,'''') = ' + '''' + @wlmc_no2 + ''''
				           + ' and isnull(wlmc_no3,'''') = ' + '''' + @wlmc_no3 +'b'+ ''''
				   exec(  @sql)
				  IF @weight <> 0
				  	BEGIN 
						PRINT @weight
						  --明细信息c --电费单价（元/度）=电费金额/用电度数
						  SET @sql = 'update cb_tbfyhjbs set m' + @wk_mm + '=' + cast(round(@je/@weight,4) as varchar(30))
						     	   + ' where wk_yymm = ' + '''' + @wk_yy + ''''
						           + ' and line_no = ' + '''' + @line_no + ''''
						           + ' and isnull(wlmc_no1,'''') = ' + '''' + @wlmc_no1 + ''''
						           + ' and isnull(wlmc_no2,'''') = ' + '''' + @wlmc_no2 + ''''
						           + ' and isnull(wlmc_no3,'''') = ' + '''' + @wlmc_no3 +'c'+ ''''
						   exec(  @sql)
					END
			   END
		END			


        FETCH NEXT FROM cb_tbfyhjbs_c1 into @line_no,@wlmc_no1,@wlmc_name1,@wlmc_no2,@wlmc_name2,@wlmc_no3,@wlmc_name3,@weight,@je
    END
CLOSE cb_tbfyhjbs_c1  --关闭游标
DEALLOCATE cb_tbfyhjbs_c1  --释放游标
-- 
END;











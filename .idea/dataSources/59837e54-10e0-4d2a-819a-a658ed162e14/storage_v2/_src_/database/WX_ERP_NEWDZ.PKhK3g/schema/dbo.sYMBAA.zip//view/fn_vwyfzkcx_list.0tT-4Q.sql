
create view fn_vwyfzkcx_list
as
select company_id, 
       ghs_id, 
       remark as summary ,
       fk_date as dj_date ,
       substring(convert(char(10),fk_date,101),7,4) + 
       substring(convert(char(10),fk_date,101),1,2) as hz_month        , 
       0 as fk_money0 , 
       0 as fk_money1 , 
       fk_moneye as fk_money2
from fn_yfzkdj 
where dj_type = '00'
union all 
select company_id             , 
       ghs_id                 , 
       remark as summary      ,
       fk_date as dj_date     ,
       substring(convert(char(10),fk_date,101),7,4) + 
       substring(convert(char(10),fk_date,101),1,2) as hz_month        , 
       0         as fk_money0 , 
       fk_money  as fk_money1 , 
       fk_moneye as fk_money2
from fn_yfzkdj 
where dj_type = '01'
union all
select company_id            , 
       ghs_id                , 
       remark as summary     ,
       fp_kpdate as dj_date  ,
       substring(convert(char(10),fp_kpdate,101),7,4) + 
       substring(convert(char(10),fp_kpdate,101),1,2) as hz_month      , 
       fp_money  as fk_money0 , 
       0         as fk_money1        , 
       fk_moneye as fk_money2
from wj_clfp 


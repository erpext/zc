
CREATE VIEW dbo.wj_vwqgd
AS
SELECT dbo.wj_qgd.qgd_no, dbo.wj_qgd.company_id, dbo.wj_qgd.ghs_id, dbo.wj_qgd.qgr, 
      dbo.wj_qgd.qg_date, dbo.wj_qgd.qgyy, dbo.wj_qgd.sh_flag, dbo.wj_qgd.shr, 
      dbo.wj_qgd.shyy, dbo.wj_qgd.sh_date, dbo.wj_qgdmx.cl_id, dbo.wj_qgdmx.qg_num1, 
      dbo.wj_qgdmx.clsldw1_no, dbo.wj_qgdmx.price, dbo.wj_qgdmx.qg_purpose, 
      dbo.wj_qgd.create_user_no, dbo.wj_qgd.id
FROM dbo.wj_qgd INNER JOIN
      dbo.wj_qgdmx ON dbo.wj_qgd.id = dbo.wj_qgdmx.master_id


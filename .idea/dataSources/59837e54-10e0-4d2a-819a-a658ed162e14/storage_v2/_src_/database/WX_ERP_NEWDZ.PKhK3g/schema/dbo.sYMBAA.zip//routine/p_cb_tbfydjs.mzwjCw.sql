








-- 
-- if  object_id('p_iw_tbemployees')>0
-- DROP PROCEDURE dbo.p_iw_tbemployees;

--sp_help cb_tbfydjs
/*
select * from cb_tbfydjs  where working_proceduer_no = '0017'
select M11,* from cb_tbfyhjbs where line_no = '0017'and  wk_yymm = '2016'order by wlmc_no1,wlmc_no2,wlmc_no3 
select M3,* from cb_tbfyhjbs  where   wk_yymm = '2016' and line_no = '0017'  order by line_no,wlmc_no1,wlmc_no2,wlmc_no3
*/
-- sp_help  cb_tbfyhjbs

--select * from  cb_tbfydjs  where   wk_yymm = '201701'order by wlmc_no1,wlmc_no2,wlmc_no3 

--delete from cb_tbfydjs where   wk_yymm = '201701'
--exec p_cb_tbfydjs '777','201701','0038','admin'

create           procedure p_cb_tbfydjs (@spid		int,
					@wk_yymm 	varchar(6),
					@line_no	varchar(4),
					@user_no	varchar(12))
as
BEGIN
   
 declare @wk_yy		varchar(4),
	 @wk_mm		varchar(2),
	 @wk_last_yymm	varchar(6),
 	 @wlmc_no1	varchar(4),
 	 @wlmc_no2	varchar(4),
 	 @wlmc_no3	varchar(4),
 	 @wlmc_name1	varchar(50),
 	 @wlmc_name2	varchar(50),
 	 @wlmc_name3	varchar(50),
 	 @weight	numeric(18,6),
 	 @weight_cl	numeric(18,6),	--产量
 	 @je		numeric(18,6),
	 @je_hj		numeric(18,6),
	 @dj		numeric(18,6),
	 @sql		varchar(6000)
--set @wk_yymm = '201611'
--set @line_no = '0026'
set @wk_yy  	= substring(@wk_yymm,1,4)
set @wk_mm   	= cast(cast(substring(@wk_yymm,5,2) as int) as varchar(2))
set @wk_last_yymm	= convert(varchar(06),dateadd(month,-1,@wk_yymm+'01'),112)

--1.年初插入表头
select 1 from cb_tbfydjs  where wk_yymm = @wk_yy
if @@rowcount = 0
BEGIN 
	insert into cb_tbfydjs(	wk_yymm,working_proceduer_no,wlmc_no1,wlmc_no2,wlmc_no3,
				 weight,je,bfb,data_id,company_id,
				create_user_no,create_datetime)
	select 	@wk_yymm,cb_tbfydjs.working_proceduer_no,cb_tbfydjs.wlmc_no1,cb_tbfydjs.wlmc_no2,cb_tbfydjs.wlmc_no3,
				1,0,0,0,0,
				@user_no,getdate()
		from cb_tbfydjs
	 where wk_yymm = @wk_last_yymm;	

	 IF @@error <> 0
		begin 
		  RAISERROR ('insert error' , 16, 1)
 		  ROLLBACK TRANSACTION
		end


END




END





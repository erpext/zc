
-- 
-- if  object_id('p_iw_tbemployees')>0
-- DROP PROCEDURE dbo.p_iw_tbemployees;
--exec p_iw_tbemployees 'XX','XX','0000060'
--select * from hr_tbempoloyeetot 
--select * from hr_tbempoloyeetot1
--select * from hr_tbempoloyeetot2

--delete from hr_tbempoloyeetot
CREATE    procedure p_iw_tbemployees (@fcmc_type as varchar(2),@work_major_job varchar(50),@employee_state0 varchar(50),@worktype_no varchar(02))
as
BEGIN
   
declare @employee_no	varchar(6),
	@employee_name 	varchar(20),
	@company_id	int,
	@company_abbr	varchar(20),
	@dept_id	int,
	@dept_name	varchar(20),
	@workshop_id	int,	
	@workshop_nm	varchar(20),
	@team_id	int,
	@team_nm	varchar(20),
	@employee_name0	varchar(1000),
	@employee_name1	varchar(1000),
	@employee_name2	varchar(1000),
	@employee_name3	varchar(1000),

	@employee_cnt0	varchar(50),
	@employee_cnt1	varchar(50),
	@employee_cnt2	varchar(50),
	@employee_cnt3	varchar(50),
	@fcmc_name	varchar(50),

	@employee_state1	varchar(1),
	@employee_state2	varchar(1),
	@employee_state3	varchar(1),
	@employee_state4	varchar(1),
	@employee_state5	varchar(1),
	@employee_state6	varchar(1),
	@employee_state7	varchar(1)

set @employee_state1 = substring(@employee_state0,1,1)
set @employee_state2 = substring(@employee_state0,2,1)
set @employee_state3 = substring(@employee_state0,3,1)
set @employee_state4 = substring(@employee_state0,4,1)
set @employee_state5 = substring(@employee_state0,5,1)
set @employee_state6 = substring(@employee_state0,6,1)
set @employee_state7 = substring(@employee_state0,7,1)

--print @employee_state1 print @employee_state2 print @employee_state3 print @employee_state4 print @employee_state5 print @employee_state6 print @employee_state7
--1.删除临时表
delete from hr_tbempoloyeetot		--最终
delete from hr_tbempoloyeetot1		--2次整理
delete from hr_tbempoloyeetot2		--一次整理

-- sp_help hr_tbempoloyeetot2
--2.删选
insert into hr_tbempoloyeetot2(
			employee_id,employee_no,employee_name,employee_type,employee_sex,firstWork_date,work_procedure,note,employee_state,dept_id,team_id,company_id,
			givemoneystandard,Create_user_no,Create_datetime,Update_user_no,Update_datetime,identitycard,sb_company_id,sb_num,product_line,ck_place,product_workshop,
			work_time_type,work_major_job,dd_no,workshop_id
			)
select iw_tbemployees.employee_id,iw_tbemployees.employee_no,iw_tbemployees.employee_name,iw_tbemployees.employee_type,iw_tbemployees.employee_sex,iw_tbemployees.firstWork_date,iw_tbemployees.work_procedure,iw_tbemployees.note,iw_tbemployees.employee_state,iw_tbemployees.dept_id,iw_tbemployees.team_id,iw_tbemployees.company_id,
       iw_tbemployees.givemoneystandard,iw_tbemployees.Create_user_no,iw_tbemployees.Create_datetime,iw_tbemployees.Update_user_no,iw_tbemployees.Update_datetime,iw_tbemployees.identitycard,iw_tbemployees.sb_company_id,iw_tbemployees.sb_num,iw_tbemployees.product_line,iw_tbemployees.ck_place,iw_tbemployees.product_workshop,
       iw_tbemployees.work_time_type,iw_tbemployees.work_major_job,iw_tbemployees.dd_no,iw_tbemployees.workshop_id
  from iw_tbemployees
	LEFT OUTER JOIN hr_tbemployee_perinfs on iw_tbemployees.employee_id = hr_tbemployee_perinfs.employee_id
	LEFT OUTER JOIN iw_tbcompanys on iw_tbemployees.company_id  = iw_tbcompanys.company_id 
	LEFT OUTER JOIN iw_tbdepts    on iw_tbemployees.dept_id     = iw_tbdepts.dept_id
	LEFT OUTER JOIN iw_tbdepts as iw_tbdepts_workshop    on iw_tbemployees.workshop_id = iw_tbdepts_workshop.dept_id and iw_tbdepts_workshop.dept_type_id = 3
	LEFT OUTER JOIN iw_tbdepts as iw_tbdepts_team        on iw_tbemployees.team_id     = iw_tbdepts_team.dept_id and iw_tbdepts_team.dept_type_id = 4
 where 1 = 1
  AND ((iw_tbemployees.employee_state = @employee_state1 )
    or (iw_tbemployees.employee_state = @employee_state2 )
    or (iw_tbemployees.employee_state = @employee_state3 ) 
    or (iw_tbemployees.employee_state = @employee_state4 )
    or (iw_tbemployees.employee_state = @employee_state5 )
    or (iw_tbemployees.employee_state = @employee_state6 )
    or (iw_tbemployees.employee_state = @employee_state7 ))
   and (hr_tbemployee_perinfs.fcmc_type 	= @fcmc_type or @fcmc_type = 'XX')
   and (iw_tbemployees.work_major_job   	= @work_major_job OR  @work_major_job = 'XX')
   and (hr_tbemployee_perinfs.worktype_no   	= @worktype_no OR  @worktype_no = 'XX')  --工种
--  and iw_tbemployees.employee_name = '吴明晓'
--
-- 
--3.整理
INSERT INTO hr_tbempoloyeetot1
select 	hr_tbempoloyeetot2.company_id ,
	iw_tbcompanys.company_abbr,
	hr_tbempoloyeetot2.employee_no,
	(select count(*) from hr_tbempoloyeetot2 a where a.company_id = hr_tbempoloyeetot2.company_id  ) employee_cnt0,
	(select employee_name from hr_tbempoloyeetot2 a where a.company_id = hr_tbempoloyeetot2.company_id and a.employee_no = hr_tbempoloyeetot2.employee_no) employee_name0,
	hr_tbempoloyeetot2.dept_id ,
	iw_tbdepts.dept_name,
	(select count(*) from hr_tbempoloyeetot2 a where a.company_id = hr_tbempoloyeetot2.company_id and a.dept_id = hr_tbempoloyeetot2.dept_id ) employee_cnt1,
	(select employee_name from hr_tbempoloyeetot2 a where a.company_id = hr_tbempoloyeetot2.company_id and a.employee_no = hr_tbempoloyeetot2.employee_no and a.dept_id = hr_tbempoloyeetot2.dept_id) employee_name1,
	hr_tbempoloyeetot2.workshop_id ,
	iw_tbdepts_workshop.dept_name as workshop_nm,
	(select count(*) from hr_tbempoloyeetot2 a where a.company_id = hr_tbempoloyeetot2.company_id and a.workshop_id = hr_tbempoloyeetot2.workshop_id and a.dept_id = hr_tbempoloyeetot2.dept_id  ) employee_cnt2,
	(select employee_name from hr_tbempoloyeetot2 a where a.company_id = hr_tbempoloyeetot2.company_id  and a.employee_no = hr_tbempoloyeetot2.employee_no and a.dept_id = hr_tbempoloyeetot2.dept_id and a.workshop_id = hr_tbempoloyeetot2.workshop_id ) employee_name2,
	hr_tbempoloyeetot2.team_id ,
	iw_tbdepts_team.dept_name as team_nm,
	(select count(*) from hr_tbempoloyeetot2 a where a.company_id = hr_tbempoloyeetot2.company_id and a.workshop_id = hr_tbempoloyeetot2.workshop_id  and a.dept_id = hr_tbempoloyeetot2.dept_id and a.team_id = hr_tbempoloyeetot2.team_id  ) employee_cnt3,
	(select employee_name from hr_tbempoloyeetot2 a where a.company_id = hr_tbempoloyeetot2.company_id  and a.employee_no = hr_tbempoloyeetot2.employee_no and a.dept_id = hr_tbempoloyeetot2.dept_id and a.workshop_id = hr_tbempoloyeetot2.workshop_id and a.team_id = hr_tbempoloyeetot2.team_id  ) employee_name3
   from hr_tbempoloyeetot2 
	 LEFT OUTER JOIN hr_tbemployee_perinfs on hr_tbempoloyeetot2.employee_id = hr_tbemployee_perinfs.employee_id
	 LEFT OUTER JOIN iw_tbcompanys on hr_tbempoloyeetot2.company_id  = iw_tbcompanys.company_id 
	 LEFT OUTER JOIN iw_tbdepts    on hr_tbempoloyeetot2.dept_id     = iw_tbdepts.dept_id
	 LEFT OUTER JOIN iw_tbdepts as iw_tbdepts_workshop    on hr_tbempoloyeetot2.workshop_id = iw_tbdepts_workshop.dept_id and iw_tbdepts_workshop.dept_type_id = 3
	 LEFT OUTER JOIN iw_tbdepts as iw_tbdepts_team        on hr_tbempoloyeetot2.team_id     = iw_tbdepts_team.dept_id and iw_tbdepts_team.dept_type_id = 4
 where 1 = 1
--    AND (iw_tbemployees.employee_state = @employee_state1 or @employee_state1 = '1')
--     or (iw_tbemployees.employee_state = @employee_state2 or @employee_state2 = '1')
--     or (iw_tbemployees.employee_state = @employee_state3 or @employee_state3 = '1') 
--     or (iw_tbemployees.employee_state = @employee_state4 or @employee_state4 = '1')
--     or (iw_tbemployees.employee_state = @employee_state5 or @employee_state5 = '1')
--     or (iw_tbemployees.employee_state = @employee_state6 or @employee_state6 = '1')
--     or (iw_tbemployees.employee_state = @employee_state7 or @employee_state7 = '1')
--    and (hr_tbemployee_perinfs.fcmc_type = @fcmc_type or @fcmc_type = 'XX')
--    and (iw_tbemployees.work_major_job   = @work_major_job OR  @fcmc_type = 'XX')
-- --   and iw_tbemployees.employee_name = '吴明晓'

group by 
	hr_tbempoloyeetot2.company_id ,
	iw_tbcompanys.company_abbr,
	hr_tbempoloyeetot2.dept_id ,
	iw_tbdepts.dept_name,
	hr_tbempoloyeetot2.workshop_id, 
	iw_tbdepts_workshop.dept_name,
	hr_tbempoloyeetot2.team_id ,
	iw_tbdepts_team.dept_name ,
	hr_tbempoloyeetot2.employee_no,
	hr_tbempoloyeetot2.employee_name


--4.master insert
INSERT INTO hr_tbempoloyeetot(company_abbr,employee_cnt0,dept_name,employee_cnt1,workshop_nm,employee_cnt2,team_nm,employee_cnt3)
select  distinct company_abbr,employee_cnt0,dept_name,employee_cnt1,workshop_nm,employee_cnt2,team_nm,employee_cnt3  from hr_tbempoloyeetot1
-- select  company_abbr,sum(employee_cnt0),dept_name,sum(employee_cnt1),workshop_nm,sum(employee_cnt2),team_nm,sum(employee_cnt3)  from hr_tbempoloyeetot1
-- group by company_abbr,dept_name,workshop_nm,team_nm
-- union all
-- union all
-- select  distinct company_abbr,employee_cnt0,dept_name,employee_cnt1,workshop_nm,employee_cnt2,NULL,0  from hr_tbempoloyeetot1
-- union all
-- select  distinct company_abbr,employee_cnt0,dept_name,employee_cnt1,NULL,0,NULL,0  from hr_tbempoloyeetot1
-- union all
-- select  distinct company_abbr,employee_cnt0,NULL,0,NULL,0,NULL,0  from hr_tbempoloyeetot1

--5.detail insert
DECLARE detail CURSOR FOR 
	select * from hr_tbempoloyeetot1

OPEN detail  
FETCH NEXT FROM detail into @company_id,@company_abbr,@employee_no,@employee_cnt0,@employee_name0,@dept_id,@dept_name,@employee_cnt1,@employee_name1,@workshop_id,@workshop_nm,@employee_cnt2,@employee_name2,@team_id,@team_nm,@employee_cnt3,@employee_name3

WHILE @@FETCH_STATUS = 0
    BEGIN
		--3
--print @employee_name3

		    update hr_tbempoloyeetot
                       set employee_name3 = isnull(employee_name3,'') + (case when isnull(employee_name3,'') = '' then '' else ',' end )+ @employee_name3,employee_name2 = NULL,employee_name1 = NULL,employee_name0 = NULL
		     WHERE company_abbr = @company_abbr AND  dept_name  = @dept_name AND workshop_nm = @workshop_nm AND team_nm = @team_nm 

		--2 
--print @employee_name2
		    update hr_tbempoloyeetot
                       set employee_name2 = isnull(employee_name2,'') + (case when isnull(employee_name2,'') = '' then '' else ',' end ) + (case when isnull(@employee_name3,'') <> '' then NULL ELSE @employee_name2 end),employee_name1 = NULL,employee_name0 = NULL
		     WHERE company_abbr = @company_abbr AND  dept_name  = @dept_name AND workshop_nm = @workshop_nm AND isnull(team_nm,'xxx') = isnull(@team_nm,'xxx')

		--1
--print @employee_name1
		    update hr_tbempoloyeetot
                       set employee_name1 = isnull(employee_name1,'') + (case when isnull(employee_name1,'') = '' then '' else ',' end ) + (case when isnull(@employee_name2,'') <> '' then NULL ELSE @employee_name1 end),employee_name0 = NULL
		     WHERE company_abbr = @company_abbr AND  dept_name  = @dept_name AND isnull(workshop_nm,'xxx') = isnull(@workshop_nm,'xxx') AND isnull(team_nm,'xxx') = isnull(@team_nm,'xxx')
		--0
--print @employee_name0
		    update hr_tbempoloyeetot
                       set employee_name0 = isnull(employee_name0,'') + (case when isnull(employee_name0,'') = '' then '' else ',' end ) + (case when isnull(@employee_name1,'') <> '' then NULL ELSE @employee_name0 end)
		     WHERE company_abbr = @company_abbr AND  isnull(dept_name,'xxx')  = isnull(@dept_name,'xxx') AND isnull(workshop_nm,'xxx') = isnull(@workshop_nm,'xxx') AND isnull(team_nm,'xxx') = isnull(@team_nm,'xxx')



        FETCH NEXT FROM detail  into @company_id,@company_abbr,@employee_no,@employee_cnt0,@employee_name0,@dept_id,@dept_name,@employee_cnt1,@employee_name1,@workshop_id,@workshop_nm,@employee_cnt2,@employee_name2,@team_id,@team_nm,@employee_cnt3,@employee_name3
    END
CLOSE detail  --关闭游标
DEALLOCATE detail  --释放游标

END;




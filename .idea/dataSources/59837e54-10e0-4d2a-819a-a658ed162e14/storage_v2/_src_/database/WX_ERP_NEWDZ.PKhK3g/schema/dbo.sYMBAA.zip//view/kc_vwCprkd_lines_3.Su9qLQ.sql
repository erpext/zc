CREATE VIEW kc_vwCprkd_lines_3 AS SELECT * FROM kc_tbCprkd_lines UNION SELECT * FROM kc_tbCprkd_lines_level2 UNION SELECT * FROM kc_tbCprkd_lines_level3

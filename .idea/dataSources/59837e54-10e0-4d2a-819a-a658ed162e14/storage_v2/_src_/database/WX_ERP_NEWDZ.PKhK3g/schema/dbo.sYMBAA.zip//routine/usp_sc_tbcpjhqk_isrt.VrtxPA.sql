--exec usp_sc_tbcpjhqk_isrt '','',''
--select cpjh1,cpjh2,cpjh3,cpjh4,cpjh5,cpjh6,cpjh7,cpjh8,cpjh9,cpjh10,cpjh11,cpjh12,cpjh13,cpjh14,cpjh15,cpjh20,* from sc_tbcpjhqk(nolock)
--delete from sc_tbcpjhqk
--select * from   sc_tbcpjhqk(nolock)
/*-----------------------------------第一组为对应的可销售的产品信息，第二十组为原料信息---------------------------------------------------*/
CREATE  procedure [usp_sc_tbcpjhqk_isrt](@hz_month 	varchar(06),
					@framework_no	varchar(02),
					@cpph 		varchar (20)
                        		) AS

DECLARE @cppm_no1		varchar(2),	@cppm_no2		varchar(2),	@cppm_no3		varchar(2),	@cppm_no4		varchar(2),	@cppm_no5		varchar(2),	@cppm_no6		varchar(2),	@cppm_no7		varchar(2),	@cppm_no8		varchar(2),	@cppm_no9		varchar(2),	@cppm_no10		varchar(2),	
	@cpgg_ply1		numeric(6,3),	@cpgg_ply2		numeric(6,3),	@cpgg_ply3		numeric(6,3),	@cpgg_ply4		numeric(6,3),	@cpgg_ply5		numeric(6,3),	@cpgg_ply6		numeric(6,3),	@cpgg_ply7		numeric(6,3),	@cpgg_ply8		numeric(6,3),	@cpgg_ply9		numeric(6,3),	@cpgg_ply10		numeric(6,3),
	@cpgg_width1		numeric(6,1),	@cpgg_width2		numeric(6,1),	@cpgg_width3		numeric(6,1),	@cpgg_width4		numeric(6,1),	@cpgg_width5		numeric(6,1),	@cpgg_width6		numeric(6,1),	@cpgg_width7		numeric(6,1),	@cpgg_width8		numeric(6,1),	@cpgg_width9		numeric(6,1),	@cpgg_width10		numeric(6,1),
	@cpgg_length1		numeric(18,1),	@cpgg_length2		numeric(18,1),	@cpgg_length3		numeric(18,1),	@cpgg_length4		numeric(18,1),	@cpgg_length5		numeric(18,1),	@cpgg_length6		numeric(18,1),	@cpgg_length7		numeric(18,1),	@cpgg_length8		numeric(18,1),	@cpgg_length9		numeric(18,1),	@cpgg_length10		numeric(18,1),	
	@quality_level1		varchar(02),	@quality_level2		varchar(02),	@quality_level3		varchar(02),	@quality_level4		varchar(02),	@quality_level5		varchar(02),	@quality_level6		varchar(02),	@quality_level7		varchar(02),	@quality_level8		varchar(02),	@quality_level9		varchar(02),	@quality_level10		varchar(02),
	@cpgg_add1		varchar(10),	@cpgg_add2		varchar(10),	@cpgg_add3		varchar(10),	@cpgg_add4		varchar(10),	@cpgg_add5		varchar(10),	@cpgg_add6		varchar(10),	@cpgg_add7		varchar(10),	@cpgg_add8		varchar(10),	@cpgg_add9		varchar(10),	@cpgg_add10		varchar(10),	
	@cpph1			varchar(20),	@cpph2			varchar(20),	@cpph3			varchar(20),	@cpph4			varchar(20),	@cpph5			varchar(20),	@cpph6			varchar(20),	@cpph7			varchar(20),	@cpph8			varchar(20),	@cpph9			varchar(20),	@cpph10			varchar(20),
	@weight1		numeric(12,3),	@weight2		numeric(12,3),	@weight3		numeric(12,3),	@weight4		numeric(12,3),	@weight5		numeric(12,3),	@weight6		numeric(12,3),	@weight7		numeric(12,3),	@weight8		numeric(12,3),	@weight9		numeric(12,3),	@weight10		numeric(12,3),
	@procedure_no1		varchar(4),	@procedure_no2		varchar(4),	@procedure_no3		varchar(4),	@procedure_no4		varchar(4),	@procedure_no5		varchar(4),	@procedure_no6		varchar(4),	@procedure_no7		varchar(4),	@procedure_no8		varchar(4),	@procedure_no9		varchar(4),	@procedure_no10		varchar(4),				--工序
	@product_line1		varchar(10),	@product_line2		varchar(10),	@product_line3		varchar(10),	@product_line4		varchar(10),	@product_line5		varchar(10),	@product_line6		varchar(10),	@product_line7		varchar(10),	@product_line8		varchar(10),	@product_line9		varchar(10),	@product_line10		varchar(10),				--生产线
	@product_time1		datetime,	@product_time2		datetime,	@product_time3		datetime,	@product_time4		datetime,	@product_time5		datetime,	@product_time6		datetime,	@product_time7		datetime,	@product_time8		datetime,	@product_time9		datetime,	@product_time10		datetime,				--生产时间
	@framework_no1		varchar(2),	@framework_no2		varchar(2),	@framework_no3		varchar(2),	@framework_no4		varchar(2),	@framework_no5		varchar(2),	@framework_no6		varchar(2),	@framework_no7		varchar(2),	@framework_no8		varchar(2),	@framework_no9		varchar(2),	@framework_no10		varchar(2),				--公司
	@prod_workshop_no1	varchar(4),	@prod_workshop_no2	varchar(2),	@prod_workshop_no3	varchar(2),	@prod_workshop_no4	varchar(2),	@prod_workshop_no5	varchar(2),	@prod_workshop_no6	varchar(2),	@prod_workshop_no7	varchar(2),	@prod_workshop_no8	varchar(2),	@prod_workshop_no9	varchar(2),	@prod_workshop_no10	varchar(2),				--车间
	@prod_team_no1		varchar(12),	@prod_team_no2		varchar(12),	@prod_team_no3		varchar(12),	@prod_team_no4		varchar(12),	@prod_team_no5		varchar(12),	@prod_team_no6		varchar(12),	@prod_team_no7		varchar(12),	@prod_team_no8		varchar(12),	@prod_team_no9		varchar(12),	@prod_team_no10		varchar(12),				--班组
	@cpjh1			varchar(20),	@cpjh2			varchar(20),	@cpjh3			varchar(20),	@cpjh4			varchar(20),	@cpjh5			varchar(20),	@cpjh6			varchar(20),	@cpjh7			varchar(20),	@cpjh8			varchar(20),	@cpjh9			varchar(20),	@cpjh10			varchar(20),
	@br1			varchar(20),	@br2			varchar(20),	@br3			varchar(20),	@br4			varchar(20),	@br5			varchar(20),	@br6			varchar(20),	@br7			varchar(20),	@br8			varchar(20),	@br9			varchar(20),	@br10			varchar(20),				--来源牌号
	@prod_company1		varchar(30),	@prod_company2		varchar(30),	@prod_company3		varchar(30),	@prod_company4		varchar(30),	@prod_company5		varchar(30),	@prod_company6		varchar(30),	@prod_company7		varchar(30),	@prod_company8		varchar(30),	@prod_company9		varchar(30),	@prod_company10		varchar(30),				--生产厂家
	@source_product_code1	varchar(40),	@source_product_code2	varchar(40),	@source_product_code3	varchar(40),	@source_product_code4	varchar(40),	@source_product_code5	varchar(40),	@source_product_code6	varchar(40),	@source_product_code7	varchar(40),	@source_product_code8	varchar(40),	@source_product_code9	varchar(40),	@source_product_code10	varchar(40),
	@source_company_no1	varchar(4),	@source_company_no2	varchar(4),	@source_company_no3	varchar(4),	@source_company_no4	varchar(4),	@source_company_no5	varchar(4),	@source_company_no6	varchar(4),	@source_company_no7	varchar(4),	@source_company_no8	varchar(4),	@source_company_no9	varchar(4),	@source_company_no10	varchar(4),	
	@pre_db_company_no1	varchar(4),	@pre_db_company_no2	varchar(4),	@pre_db_company_no3	varchar(4),	@pre_db_company_no4	varchar(4),	@pre_db_company_no5	varchar(4),	@pre_db_company_no6	varchar(4),	@pre_db_company_no7	varchar(4),	@pre_db_company_no8	varchar(4),	@pre_db_company_no9	varchar(4),	@pre_db_company_no10	varchar(4)

DECLARE @cppm_no11		varchar(2),	@cppm_no12		varchar(2),	@cppm_no13		varchar(2),	@cppm_no14		varchar(2),	@cppm_no15		varchar(2),	@cppm_no16		varchar(2),	@cppm_no17		varchar(2),	@cppm_no18		varchar(2),	@cppm_no19		varchar(2),	@cppm_no20		varchar(2),	
	@cpgg_ply11		numeric(6,3),	@cpgg_ply12		numeric(6,3),	@cpgg_ply13		numeric(6,3),	@cpgg_ply14		numeric(6,3),	@cpgg_ply15		numeric(6,3),	@cpgg_ply16		numeric(6,3),	@cpgg_ply17		numeric(6,3),	@cpgg_ply18		numeric(6,3),	@cpgg_ply19		numeric(6,3),	@cpgg_ply20		numeric(6,3),
	@cpgg_width11		numeric(6,1),	@cpgg_width12		numeric(6,1),	@cpgg_width13		numeric(6,1),	@cpgg_width14		numeric(6,1),	@cpgg_width15		numeric(6,1),	@cpgg_width16		numeric(6,1),	@cpgg_width17		numeric(6,1),	@cpgg_width18		numeric(6,1),	@cpgg_width19		numeric(6,1),	@cpgg_width20		numeric(6,1),
	@cpgg_length11		numeric(18,1),	@cpgg_length12		numeric(18,1),	@cpgg_length13		numeric(18,1),	@cpgg_length14		numeric(18,1),	@cpgg_length15		numeric(18,1),	@cpgg_length16		numeric(18,1),	@cpgg_length17		numeric(18,1),	@cpgg_length18		numeric(18,1),	@cpgg_length19		numeric(18,1),	@cpgg_length20		numeric(18,1),	
	@quality_level11	varchar(10),	@quality_level12	varchar(10),	@quality_level13	varchar(10),	@quality_level14	varchar(10),	@quality_level15	varchar(10),	@quality_level16	varchar(10),	@quality_level17	varchar(10),	@quality_level18	varchar(10),	@quality_level19	varchar(10),	@quality_level20	varchar(10),	
	@cpgg_add11		varchar(10),	@cpgg_add12		varchar(10),	@cpgg_add13		varchar(10),	@cpgg_add14		varchar(10),	@cpgg_add15		varchar(10),	@cpgg_add16		varchar(10),	@cpgg_add17		varchar(10),	@cpgg_add18		varchar(10),	@cpgg_add19		varchar(10),	@cpgg_add20		varchar(10),	
	@cpph11			varchar(20),	@cpph12			varchar(20),	@cpph13			varchar(20),	@cpph14			varchar(20),	@cpph15			varchar(20),	@cpph16			varchar(20),	@cpph17			varchar(20),	@cpph18			varchar(20),	@cpph19			varchar(20),	@cpph20			varchar(20),
	@weight11		numeric(12,3),	@weight12		numeric(12,3),	@weight13		numeric(12,3),	@weight14		numeric(12,3),	@weight15		numeric(12,3),	@weight16		numeric(12,3),	@weight17		numeric(12,3),	@weight18		numeric(12,3),	@weight19		numeric(12,3),	@weight20		numeric(12,3),
	@procedure_no11		varchar(4),	@procedure_no12		varchar(4),	@procedure_no13		varchar(4),	@procedure_no14		varchar(4),	@procedure_no15		varchar(4),	@procedure_no16		varchar(4),	@procedure_no17		varchar(4),	@procedure_no18		varchar(4),	@procedure_no19		varchar(4),	@procedure_no20		varchar(4),				--工序
	@product_line11		varchar(10),	@product_line12		varchar(10),	@product_line13		varchar(10),	@product_line14		varchar(10),	@product_line15		varchar(10),	@product_line16		varchar(10),	@product_line17		varchar(10),	@product_line18		varchar(10),	@product_line19		varchar(10),	@product_line20		varchar(10),				--生产线
	@product_time11		datetime,	@product_time12		datetime,	@product_time13		datetime,	@product_time14		datetime,	@product_time15		datetime,	@product_time16		datetime,	@product_time17		datetime,	@product_time18		datetime,	@product_time19		datetime,	@product_time20		datetime,				--生产时间
	@framework_no11		varchar(2),	@framework_no12		varchar(2),	@framework_no13		varchar(2),	@framework_no14		varchar(2),	@framework_no15		varchar(2),	@framework_no16		varchar(2),	@framework_no17		varchar(2),	@framework_no18		varchar(2),	@framework_no19		varchar(2),	@framework_no20		varchar(2),				--公司
	@prod_workshop_no11	varchar(4),	@prod_workshop_no12	varchar(2),	@prod_workshop_no13	varchar(2),	@prod_workshop_no14	varchar(2),	@prod_workshop_no15	varchar(2),	@prod_workshop_no16	varchar(2),	@prod_workshop_no17	varchar(2),	@prod_workshop_no18	varchar(2),	@prod_workshop_no19	varchar(2),	@prod_workshop_no20	varchar(2),				--车间
	@prod_team_no11		varchar(12),	@prod_team_no12		varchar(12),	@prod_team_no13		varchar(12),	@prod_team_no14		varchar(12),	@prod_team_no15		varchar(12),	@prod_team_no16		varchar(12),	@prod_team_no17		varchar(12),	@prod_team_no18		varchar(12),	@prod_team_no19		varchar(12),	@prod_team_no20		varchar(12),				--班组
	@cpjh11			varchar(20),	@cpjh12			varchar(20),	@cpjh13			varchar(20),	@cpjh14			varchar(20),	@cpjh15			varchar(20),	@cpjh16			varchar(20),	@cpjh17			varchar(20),	@cpjh18			varchar(20),	@cpjh19			varchar(20),	@cpjh20			varchar(20),
	@br11			varchar(20),	@br12			varchar(20),	@br13			varchar(20),	@br14			varchar(20),	@br15			varchar(20),	@br16			varchar(20),	@br17			varchar(20),	@br18			varchar(20),	@br19			varchar(20),	@br20			varchar(20),				--来源牌号
	@prod_company11		varchar(30),	@prod_company12		varchar(30),	@prod_company13		varchar(30),	@prod_company14		varchar(30),	@prod_company15		varchar(30),	@prod_company16		varchar(30),	@prod_company17		varchar(30),	@prod_company18		varchar(30),	@prod_company19		varchar(30),	@prod_company20		varchar(30),				--生产厂家
	@source_product_code11	varchar(40),	@source_product_code12	varchar(40),	@source_product_code13	varchar(40),	@source_product_code14	varchar(40),	@source_product_code15	varchar(40),	@source_product_code16	varchar(40),	@source_product_code17	varchar(40),	@source_product_code18	varchar(40),	@source_product_code19	varchar(40),	@source_product_code20	varchar(40),
	@source_company_no11	varchar(4),	@source_company_no12	varchar(4),	@source_company_no13	varchar(4),	@source_company_no14	varchar(4),	@source_company_no15	varchar(4),	@source_company_no16	varchar(4),	@source_company_no17	varchar(4),	@source_company_no18	varchar(4),	@source_company_no19	varchar(4),	@source_company_no20	varchar(4),	
	@pre_db_company_no11	varchar(4),	@pre_db_company_no12	varchar(4),	@pre_db_company_no13	varchar(4),	@pre_db_company_no14	varchar(4),	@pre_db_company_no15	varchar(4),	@pre_db_company_no16	varchar(4),	@pre_db_company_no17	varchar(4),	@pre_db_company_no18	varchar(4),	@pre_db_company_no19	varchar(4),	@pre_db_company_no20	varchar(4)

--set @hz_month = '201605'


declare @rowcnt7 int	, @rowcnt8 int	
declare @wk_dt	datetime

select  @wk_dt = dateadd(day,-1,getdate())  --服务器时间 -1天

DECLARE KC_TBCPKCHZS_C1 SCROLL CURSOR FOR

select cppm_no,cpgg_ply,cpgg_width,cpgg_length,quality_level,cpgg_add,cpph,weight,procedure_no,product_line,rk_date,
       framework_no,prod_workshop_no,'可销售品',--prod_team_no,
       cpjh,br,prod_company
  from kc_tbcpkchzs a(nolock)
 where sale_flag = '1'			--销售标记  1：可销售0：不可
--   and a.cpjh in( '16051520107')	--'16022824101',16020321604-
--   and a.data_id = '1'
--   and convert(varchar(08),a.create_datetime,112) = @wk_dt
--   and a.hz_month = '201605'
   and convert(varchar(08),a.rk_date,112) = convert(varchar(08),@wk_dt,112)

print @@rowcount
OPEN  KC_TBCPKCHZS_C1

FETCH NEXT FROM kc_tbcpkchzs_C1 INTO 	@cppm_no1, @cpgg_ply1, @cpgg_width1,@cpgg_length1,@quality_level1,@cpgg_add1,@cpph1,@weight1, @procedure_no1,@product_line1,@product_time1, @framework_no1, @prod_workshop_no1,@prod_team_no1,	@cpjh1,  @br1, 	@prod_company1

WHILE (@@FETCH_STATUS = 0)
BEGIN
	/*-------------KC_TBCPKCHZS_C2-----------------start-------------------------*/
	DECLARE KC_TBCPKCHZS_C2 SCROLL CURSOR FOR
	       select a.current_product_no,a.current_product_ply,a.current_product_width,a.current_product_length,a.current_product_level,a.current_product_add_no,a.cpph,a.current_product_weight,a.current_procedure_no,
		      a.product_line,a.create_datetime,a.current_company_no,a.current_workshop_no,a.current_team_no,a.current_product_code,a.source_trademark,a.source_prod_company,a.source_product_code,a.pre_db_company_no
		 from vwxbsc1006_xs_tbchange_lines a
	        where a.current_company_no = @framework_no1
	          and a.current_product_code = @cpjh1
	OPEN  KC_TBCPKCHZS_C2
	
	FETCH NEXT FROM kc_tbcpkchzs_C2 INTO  @cppm_no2, @cpgg_ply2, @cpgg_width2, @cpgg_length2,@quality_level2, @cpgg_add2, @cpph2,@weight2, @procedure_no2, @product_line2,@product_time2, @framework_no2,@prod_workshop_no2, @prod_team_no2,@cpjh2,  @br2, 	@prod_company2,@source_product_code2,@pre_db_company_no2
	
	IF @@FETCH_STATUS = -1   	--如果没有数据
	   insert into sc_tbcpjhqk (cppm_no1,cpgg_ply1,cpgg_width1,cpgg_length1,quality_level1,cpgg_add1,cpph1,weight1,procedure_no1,product_line1,product_time1,framework_no1,prod_workshop_no1,prod_team_no1,cpjh1,br1,prod_company1,
			 	    cppm_no20,cpgg_ply20,cpgg_width20,cpgg_length20,quality_level20,cpgg_add20,cpph20,weight20,procedure_no20,product_line20,product_time20,framework_no20,prod_workshop_no20,prod_team_no20,cpjh20,br20,prod_company20,
				    hz_month,create_datetime)
						
			values( @cppm_no1, @cpgg_ply1, @cpgg_width1,@cpgg_length1,@quality_level1,@cpgg_add1,@cpph1,@weight1, @procedure_no1,@product_line1,@product_time1, @framework_no1, @prod_workshop_no1,@prod_team_no1,	@cpjh1,  @br1, 	@prod_company1,		
				@cppm_no1, @cpgg_ply1, @cpgg_width1,@cpgg_length1,@quality_level1,@cpgg_add1,@cpph1,@weight1, @procedure_no1,@product_line1,@product_time1, @framework_no1, @prod_workshop_no1,@prod_team_no1,	@cpjh1,  @br1, 	@prod_company1,		--记录原料信息
				@hz_month,getdate()		
				)	

	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		print '222' + @source_product_code2
			/*-------------KC_TBCPKCHZS_C3-----------------start-------------------------*/
			DECLARE KC_TBCPKCHZS_C3 SCROLL CURSOR FOR
			       select a.current_product_no,a.current_product_ply,a.current_product_width,a.current_product_length,a.current_product_level,a.current_product_add_no,a.cpph,a.current_product_weight,a.current_procedure_no,
				      a.product_line,a.create_datetime,a.current_company_no,a.current_workshop_no,a.current_team_no,a.current_product_code,a.source_trademark,a.source_prod_company,a.source_product_code,a.pre_db_company_no
				 from vwxbsc1006_xs_tbchange_lines a
			        where a.current_company_no 	= @pre_db_company_no2
			          and a.current_product_code 	= @source_product_code2

			OPEN  KC_TBCPKCHZS_C3
			
			FETCH NEXT FROM kc_tbcpkchzs_C3 INTO  @cppm_no3, @cpgg_ply3, @cpgg_width3, @cpgg_length3,@quality_level3, @cpgg_add3, @cpph3,@weight3, @procedure_no3, @product_line3,@product_time3, @framework_no3,@prod_workshop_no3, @prod_team_no3,@cpjh3,  @br3, 	@prod_company3,@source_product_code3,@pre_db_company_no3

			IF @@FETCH_STATUS = -1   	--如果没有数据
			   insert into sc_tbcpjhqk (cppm_no1,cpgg_ply1,cpgg_width1,cpgg_length1,quality_level1,cpgg_add1,cpph1,weight1,procedure_no1,product_line1,	product_time1,framework_no1,prod_workshop_no1,prod_team_no1,cpjh1,br1,prod_company1,
						    cppm_no2,cpgg_ply2,cpgg_width2,cpgg_length2,quality_level2,cpgg_add2,cpph2,weight2,procedure_no2,product_line2,	product_time2,framework_no2,prod_workshop_no2,prod_team_no2,cpjh2,br2,prod_company2,
			 	    		    cppm_no20,cpgg_ply20,cpgg_width20,cpgg_length20,quality_level20,cpgg_add20,cpph20,weight20,procedure_no20,product_line20,product_time20,framework_no20,prod_workshop_no20,prod_team_no20,cpjh20,br20,prod_company20,
						    hz_month,create_datetime)
								
					values( @cppm_no1, @cpgg_ply1, @cpgg_width1,@cpgg_length1,@quality_level1,@cpgg_add1,@cpph1,@weight1, @procedure_no1,@product_line1,@product_time1, @framework_no1, @prod_workshop_no1,@prod_team_no1,	@cpjh1,  @br1, 	@prod_company1,		
						@cppm_no2, @cpgg_ply2, @cpgg_width2,@cpgg_length2,@quality_level2,@cpgg_add2,@cpph2,@weight2, @procedure_no2,@product_line2,@product_time2, @framework_no2, @prod_workshop_no2,@prod_team_no2,	@cpjh2,  @br2, 	@prod_company2,	
						@cppm_no2, @cpgg_ply2, @cpgg_width2,@cpgg_length2,@quality_level2,@cpgg_add2,@cpph2,@weight2, @procedure_no2,@product_line2,@product_time2, @framework_no2, @prod_workshop_no2,@prod_team_no2,	@cpjh2,  @br2, 	@prod_company2,	--记录原料信息
						@hz_month,getdate()		
						)	
			WHILE (@@FETCH_STATUS = 0)
			BEGIN
		print '333' + @source_product_code3
				/*-------------KC_TBCPKCHZS_C4-----------------start-------------------------*/
				DECLARE KC_TBCPKCHZS_C4 SCROLL CURSOR FOR
				       select a.current_product_no,a.current_product_ply,a.current_product_width,a.current_product_length,a.current_product_level,a.current_product_add_no,a.cpph,a.current_product_weight,a.current_procedure_no,
					      a.product_line,a.create_datetime,a.current_company_no,a.current_workshop_no,a.current_team_no,a.current_product_code,a.source_trademark,a.source_prod_company,a.source_product_code,a.pre_db_company_no
					 from vwxbsc1006_xs_tbchange_lines a
				        where a.current_company_no 	= @pre_db_company_no3
				          and a.current_product_code 	= @source_product_code3
		
				OPEN  KC_TBCPKCHZS_C4
		
				FETCH NEXT FROM kc_tbcpkchzs_C4 INTO  @cppm_no4, @cpgg_ply4, @cpgg_width4, @cpgg_length4,@quality_level4, @cpgg_add4, @cpph4,@weight4, @procedure_no4, @product_line4,@product_time4, @framework_no4,@prod_workshop_no4, @prod_team_no4,@cpjh4,  @br4, 	@prod_company4,@source_product_code4,@pre_db_company_no4
				
				IF @@FETCH_STATUS = -1   	--如果没有数据
				   insert into sc_tbcpjhqk (cppm_no1,cpgg_ply1,cpgg_width1,cpgg_length1,quality_level1,cpgg_add1,cpph1,weight1,procedure_no1,product_line1,	product_time1,framework_no1,prod_workshop_no1,prod_team_no1,cpjh1,br1,prod_company1,
							    cppm_no2,cpgg_ply2,cpgg_width2,cpgg_length2,quality_level2,cpgg_add2,cpph2,weight2,procedure_no2,product_line2,	product_time2,framework_no2,prod_workshop_no2,prod_team_no2,cpjh2,br2,prod_company2,
							    cppm_no3,cpgg_ply3,cpgg_width3,cpgg_length3,quality_level3,cpgg_add3,cpph3,weight3,procedure_no3,product_line3,	product_time3,framework_no3,prod_workshop_no3,prod_team_no3,cpjh3,br3,prod_company3,
							    cppm_no20,cpgg_ply20,cpgg_width20,cpgg_length20,quality_level20,cpgg_add20,cpph20,weight20,procedure_no20,product_line20,product_time20,framework_no20,prod_workshop_no20,prod_team_no20,cpjh20,br20,prod_company20,
							    hz_month,create_datetime)
									
						values( @cppm_no1, @cpgg_ply1, @cpgg_width1,@cpgg_length1,@quality_level1,@cpgg_add1,@cpph1,@weight1, @procedure_no1,@product_line1,@product_time1, @framework_no1, @prod_workshop_no1,@prod_team_no1,	@cpjh1,  @br1, 	@prod_company1,		
							@cppm_no2, @cpgg_ply2, @cpgg_width2,@cpgg_length2,@quality_level2,@cpgg_add2,@cpph2,@weight2, @procedure_no2,@product_line2,@product_time2, @framework_no2, @prod_workshop_no2,@prod_team_no2,	@cpjh2,  @br2, 	@prod_company2,	
							@cppm_no3, @cpgg_ply3, @cpgg_width3,@cpgg_length3,@quality_level3,@cpgg_add3,@cpph3,@weight3, @procedure_no3,@product_line3,@product_time3, @framework_no3, @prod_workshop_no3,@prod_team_no3,	@cpjh3,  @br3, 	@prod_company3,	
							@cppm_no3, @cpgg_ply3, @cpgg_width3,@cpgg_length3,@quality_level3,@cpgg_add3,@cpph3,@weight3, @procedure_no3,@product_line3,@product_time3, @framework_no3, @prod_workshop_no3,@prod_team_no3,	@cpjh3,  @br3, 	@prod_company3,	--记录原料信息
							@hz_month, getdate()		
							)	

				WHILE (@@FETCH_STATUS = 0)
				BEGIN
		print '444' + @source_product_code4
					/*-------------KC_TBCPKCHZS_C5-----------------start-------------------------*/
					DECLARE KC_TBCPKCHZS_C5 SCROLL CURSOR FOR
					       select a.current_product_no,a.current_product_ply,a.current_product_width,a.current_product_length,a.current_product_level,a.current_product_add_no,a.cpph,a.current_product_weight,a.current_procedure_no,
						      a.product_line,a.create_datetime,a.current_company_no,a.current_workshop_no,a.current_team_no,a.current_product_code,a.source_trademark,a.source_prod_company,a.source_product_code,a.pre_db_company_no
						 from vwxbsc1006_xs_tbchange_lines a
					        where a.current_company_no   = @pre_db_company_no4
					          and a.current_product_code = @source_product_code4
		
					OPEN  KC_TBCPKCHZS_C5
					
					FETCH NEXT FROM kc_tbcpkchzs_C5 INTO  @cppm_no5, @cpgg_ply5, @cpgg_width5, @cpgg_length5,@quality_level5, @cpgg_add5, @cpph5,@weight5, @procedure_no5, @product_line5,@product_time5, @framework_no5,@prod_workshop_no5, @prod_team_no5,@cpjh5,  @br5, 	@prod_company5,@source_product_code5,@pre_db_company_no5
					IF @@FETCH_STATUS = -1   	--如果没有数据
					   insert into sc_tbcpjhqk (cppm_no1,cpgg_ply1,cpgg_width1,cpgg_length1,quality_level1,cpgg_add1,cpph1,weight1,procedure_no1,product_line1,	product_time1,framework_no1,prod_workshop_no1,prod_team_no1,cpjh1,br1,prod_company1,
								    cppm_no2,cpgg_ply2,cpgg_width2,cpgg_length2,quality_level2,cpgg_add2,cpph2,weight2,procedure_no2,product_line2,	product_time2,framework_no2,prod_workshop_no2,prod_team_no2,cpjh2,br2,prod_company2,
								    cppm_no3,cpgg_ply3,cpgg_width3,cpgg_length3,quality_level3,cpgg_add3,cpph3,weight3,procedure_no3,product_line3,	product_time3,framework_no3,prod_workshop_no3,prod_team_no3,cpjh3,br3,prod_company3,
								    cppm_no4,cpgg_ply4,cpgg_width4,cpgg_length4,quality_level4,cpgg_add4,cpph4,weight4,procedure_no4,product_line4,	product_time4,framework_no4,prod_workshop_no4,prod_team_no4,cpjh4,br4,prod_company4,
								    cppm_no20,cpgg_ply20,cpgg_width20,cpgg_length20,quality_level20,cpgg_add20,cpph20,weight20,procedure_no20,product_line20,product_time20,framework_no20,prod_workshop_no20,prod_team_no20,cpjh20,br20,prod_company20,        --记录原料信息
								    hz_month,create_datetime)
										
							values( @cppm_no1, @cpgg_ply1, @cpgg_width1,@cpgg_length1,@quality_level1,@cpgg_add1,@cpph1,@weight1, @procedure_no1,@product_line1,@product_time1, @framework_no1, @prod_workshop_no1,@prod_team_no1,	@cpjh1,  @br1, 	@prod_company1,		
								@cppm_no2, @cpgg_ply2, @cpgg_width2,@cpgg_length2,@quality_level2,@cpgg_add2,@cpph2,@weight2, @procedure_no2,@product_line2,@product_time2, @framework_no2, @prod_workshop_no2,@prod_team_no2,	@cpjh2,  @br2, 	@prod_company2,	
								@cppm_no3, @cpgg_ply3, @cpgg_width3,@cpgg_length3,@quality_level3,@cpgg_add3,@cpph3,@weight3, @procedure_no3,@product_line3,@product_time3, @framework_no3, @prod_workshop_no3,@prod_team_no3,	@cpjh3,  @br3, 	@prod_company3,	
								@cppm_no4, @cpgg_ply4, @cpgg_width4,@cpgg_length4,@quality_level4,@cpgg_add4,@cpph4,@weight4, @procedure_no4,@product_line4,@product_time4, @framework_no4, @prod_workshop_no4,@prod_team_no4,	@cpjh4,  @br4, 	@prod_company4,	
								@cppm_no4, @cpgg_ply4, @cpgg_width4,@cpgg_length4,@quality_level4,@cpgg_add4,@cpph4,@weight4, @procedure_no4,@product_line4,@product_time4, @framework_no4, @prod_workshop_no4,@prod_team_no4,	@cpjh4,  @br4, 	@prod_company4,	--记录原料信息
								@hz_month, getdate()		
								)	

					WHILE (@@FETCH_STATUS = 0)
					BEGIN
		print '555' + @source_product_code5 + '|' + @pre_db_company_no5 
						/*-------------KC_TBCPKCHZS_C6-----------------start-------------------------*/
						DECLARE KC_TBCPKCHZS_C6 SCROLL CURSOR FOR
						       select a.current_product_no,a.current_product_ply,a.current_product_width,a.current_product_length,a.current_product_level,a.current_product_add_no,a.cpph,a.current_product_weight,a.current_procedure_no,
							      a.product_line,a.create_datetime,a.current_company_no,a.current_workshop_no,a.current_team_no,a.current_product_code,a.source_trademark,a.source_prod_company,a.source_product_code,a.pre_db_company_no
							 from vwxbsc1006_xs_tbchange_lines a
						        where a.current_company_no   = @pre_db_company_no5
						          and a.current_product_code = @source_product_code5
			
						OPEN  KC_TBCPKCHZS_C6
						
						FETCH NEXT FROM kc_tbcpkchzs_C6 INTO  @cppm_no6, @cpgg_ply6, @cpgg_width6, @cpgg_length6,@quality_level6, @cpgg_add6, @cpph6,@weight6, @procedure_no6, @product_line6,@product_time6, @framework_no6,@prod_workshop_no6, @prod_team_no6,@cpjh6,  @br6, 	@prod_company6,@source_product_code6,@pre_db_company_no6
						IF @@FETCH_STATUS = -1   	--如果没有数据
						   insert into sc_tbcpjhqk (cppm_no1,cpgg_ply1,cpgg_width1,cpgg_length1,quality_level1,cpgg_add1,cpph1,weight1,procedure_no1,product_line1,	product_time1,framework_no1,prod_workshop_no1,prod_team_no1,cpjh1,br1,prod_company1,
									    cppm_no2,cpgg_ply2,cpgg_width2,cpgg_length2,quality_level2,cpgg_add2,cpph2,weight2,procedure_no2,product_line2,	product_time2,framework_no2,prod_workshop_no2,prod_team_no2,cpjh2,br2,prod_company2,
									    cppm_no3,cpgg_ply3,cpgg_width3,cpgg_length3,quality_level3,cpgg_add3,cpph3,weight3,procedure_no3,product_line3,	product_time3,framework_no3,prod_workshop_no3,prod_team_no3,cpjh3,br3,prod_company3,
									    cppm_no4,cpgg_ply4,cpgg_width4,cpgg_length4,quality_level4,cpgg_add4,cpph4,weight4,procedure_no4,product_line4,	product_time4,framework_no4,prod_workshop_no4,prod_team_no4,cpjh4,br4,prod_company4,
									    cppm_no5,cpgg_ply5,cpgg_width5,cpgg_length5,quality_level5,cpgg_add5,cpph5,weight5,procedure_no5,product_line5,	product_time5,framework_no5,prod_workshop_no5,prod_team_no5,cpjh5,br5,prod_company5,
									    cppm_no20,cpgg_ply20,cpgg_width20,cpgg_length20,quality_level20,cpgg_add20,cpph20,weight20,procedure_no20,product_line20,product_time20,framework_no20,prod_workshop_no20,prod_team_no20,cpjh20,br20,prod_company20,        --记录原料信息
 									     hz_month,create_datetime)
											
								values( @cppm_no1, @cpgg_ply1, @cpgg_width1,@cpgg_length1,@quality_level1,@cpgg_add1,@cpph1,@weight1, @procedure_no1,@product_line1,@product_time1, @framework_no1, @prod_workshop_no1,@prod_team_no1,	@cpjh1,  @br1, 	@prod_company1,		
									@cppm_no2, @cpgg_ply2, @cpgg_width2,@cpgg_length2,@quality_level2,@cpgg_add2,@cpph2,@weight2, @procedure_no2,@product_line2,@product_time2, @framework_no2, @prod_workshop_no2,@prod_team_no2,	@cpjh2,  @br2, 	@prod_company2,	
									@cppm_no3, @cpgg_ply3, @cpgg_width3,@cpgg_length3,@quality_level3,@cpgg_add3,@cpph3,@weight3, @procedure_no3,@product_line3,@product_time3, @framework_no3, @prod_workshop_no3,@prod_team_no3,	@cpjh3,  @br3, 	@prod_company3,	
									@cppm_no4, @cpgg_ply4, @cpgg_width4,@cpgg_length4,@quality_level4,@cpgg_add4,@cpph4,@weight4, @procedure_no4,@product_line4,@product_time4, @framework_no4, @prod_workshop_no4,@prod_team_no4,	@cpjh4,  @br4, 	@prod_company4,	
									@cppm_no5, @cpgg_ply5, @cpgg_width5,@cpgg_length5,@quality_level5,@cpgg_add5,@cpph5,@weight5, @procedure_no5,@product_line5,@product_time5, @framework_no5, @prod_workshop_no5,@prod_team_no5,	@cpjh5,  @br5, 	@prod_company5,
									@cppm_no5, @cpgg_ply5, @cpgg_width5,@cpgg_length5,@quality_level5,@cpgg_add5,@cpph5,@weight5, @procedure_no5,@product_line5,@product_time5, @framework_no5, @prod_workshop_no5,@prod_team_no5,	@cpjh5,  @br5, 	@prod_company5,	--记录原料信息
									@hz_month,getdate()
									)	

						WHILE (@@FETCH_STATUS = 0)
						BEGIN	
		print '666' + @source_product_code6 + '|' + @pre_db_company_no6 
							/*-------------KC_TBCPKCHZS_C7-----------------start-------------------------*/
							DECLARE KC_TBCPKCHZS_C7 SCROLL CURSOR FOR
							       select a.current_product_no,a.current_product_ply,a.current_product_width,a.current_product_length,a.current_product_level,a.current_product_add_no,a.cpph,a.current_product_weight,a.current_procedure_no,
								      a.product_line,a.create_datetime,a.current_company_no,a.current_workshop_no,a.current_team_no,a.current_product_code,a.source_trademark,a.source_prod_company,a.source_product_code,a.pre_db_company_no
								 from vwxbsc1006_xs_tbchange_lines a
							        where a.current_company_no   = @pre_db_company_no6
							          and a.current_product_code = @source_product_code6
							OPEN  KC_TBCPKCHZS_C7
							
							FETCH NEXT FROM kc_tbcpkchzs_C7 INTO  @cppm_no7, @cpgg_ply7, @cpgg_width7, @cpgg_length7,@quality_level7, @cpgg_add7, @cpph7,@weight7, @procedure_no7, @product_line7,@product_time7, @framework_no7,@prod_workshop_no7, @prod_team_no7,@cpjh7,  @br7, 	@prod_company7,@source_product_code7,@pre_db_company_no7
							
							IF @@FETCH_STATUS = -1   	--如果没有数据

							   insert into sc_tbcpjhqk (cppm_no1,cpgg_ply1,cpgg_width1,cpgg_length1,quality_level1,cpgg_add1,cpph1,weight1,procedure_no1,product_line1,	product_time1,framework_no1,prod_workshop_no1,prod_team_no1,cpjh1,br1,prod_company1,
										    cppm_no2,cpgg_ply2,cpgg_width2,cpgg_length2,quality_level2,cpgg_add2,cpph2,weight2,procedure_no2,product_line2,	product_time2,framework_no2,prod_workshop_no2,prod_team_no2,cpjh2,br2,prod_company2,
										    cppm_no3,cpgg_ply3,cpgg_width3,cpgg_length3,quality_level3,cpgg_add3,cpph3,weight3,procedure_no3,product_line3,	product_time3,framework_no3,prod_workshop_no3,prod_team_no3,cpjh3,br3,prod_company3,
										    cppm_no4,cpgg_ply4,cpgg_width4,cpgg_length4,quality_level4,cpgg_add4,cpph4,weight4,procedure_no4,product_line4,	product_time4,framework_no4,prod_workshop_no4,prod_team_no4,cpjh4,br4,prod_company4,
										    cppm_no5,cpgg_ply5,cpgg_width5,cpgg_length5,quality_level5,cpgg_add5,cpph5,weight5,procedure_no5,product_line5,	product_time5,framework_no5,prod_workshop_no5,prod_team_no5,cpjh5,br5,prod_company5,
	 									    cppm_no6,cpgg_ply6,cpgg_width6,cpgg_length6,quality_level6,cpgg_add6,cpph6,weight6,procedure_no6,product_line6,	product_time6,framework_no6,prod_workshop_no6,prod_team_no6,cpjh6,br6,prod_company6,
										    cppm_no20,cpgg_ply20,cpgg_width20,cpgg_length20,quality_level20,cpgg_add20,cpph20,weight20,procedure_no20,product_line20,product_time20,framework_no20,prod_workshop_no20,prod_team_no20,cpjh20,br20,prod_company20,        --记录原料信息
										    hz_month,create_datetime)
												
									values( @cppm_no1, @cpgg_ply1, @cpgg_width1,@cpgg_length1,@quality_level1,@cpgg_add1,@cpph1,@weight1, @procedure_no1,@product_line1,@product_time1, @framework_no1, @prod_workshop_no1,@prod_team_no1,	@cpjh1,  @br1, 	@prod_company1,		
										@cppm_no2, @cpgg_ply2, @cpgg_width2,@cpgg_length2,@quality_level2,@cpgg_add2,@cpph2,@weight2, @procedure_no2,@product_line2,@product_time2, @framework_no2, @prod_workshop_no2,@prod_team_no2,	@cpjh2,  @br2, 	@prod_company2,	
										@cppm_no3, @cpgg_ply3, @cpgg_width3,@cpgg_length3,@quality_level3,@cpgg_add3,@cpph3,@weight3, @procedure_no3,@product_line3,@product_time3, @framework_no3, @prod_workshop_no3,@prod_team_no3,	@cpjh3,  @br3, 	@prod_company3,	
										@cppm_no4, @cpgg_ply4, @cpgg_width4,@cpgg_length4,@quality_level4,@cpgg_add4,@cpph4,@weight4, @procedure_no4,@product_line4,@product_time4, @framework_no4, @prod_workshop_no4,@prod_team_no4,	@cpjh4,  @br4, 	@prod_company4,	
										@cppm_no5, @cpgg_ply5, @cpgg_width5,@cpgg_length5,@quality_level5,@cpgg_add5,@cpph5,@weight5, @procedure_no5,@product_line5,@product_time5, @framework_no5, @prod_workshop_no5,@prod_team_no5,	@cpjh5,  @br5, 	@prod_company5,	
										@cppm_no6, @cpgg_ply6, @cpgg_width6,@cpgg_length6,@quality_level6,@cpgg_add6,@cpph6,@weight6, @procedure_no6,@product_line6,@product_time6, @framework_no6, @prod_workshop_no6,@prod_team_no6,	@cpjh6,  @br6, 	@prod_company6,	
										@cppm_no6, @cpgg_ply6, @cpgg_width6,@cpgg_length6,@quality_level6,@cpgg_add6,@cpph6,@weight6, @procedure_no6,@product_line6,@product_time6, @framework_no6, @prod_workshop_no6,@prod_team_no6,	@cpjh6,  @br6, 	@prod_company6,	--记录原料信息
										@hz_month,getdate()
										)		
		

							WHILE (@@FETCH_STATUS = 0)
							BEGIN
		print '777' + @source_product_code7+ '|' +@pre_db_company_no7
								/*-------------KC_TBCPKCHZS_C8-----------------start-------------------------*/
								DECLARE KC_TBCPKCHZS_C8 SCROLL CURSOR FOR
								       select a.current_product_no,a.current_product_ply,a.current_product_width,a.current_product_length,a.current_product_level,a.current_product_add_no,a.cpph,a.current_product_weight,a.current_procedure_no,
									      a.product_line,a.create_datetime,a.current_company_no,a.current_workshop_no,a.current_team_no,a.current_product_code,a.source_trademark,a.source_prod_company,a.source_product_code,a.pre_db_company_no
									 from vwxbsc1006_xs_tbchange_lines a
								        where a.current_company_no   = @pre_db_company_no7
								          and a.current_product_code = @source_product_code7
								OPEN  KC_TBCPKCHZS_C8
					
								FETCH NEXT FROM kc_tbcpkchzs_C8 INTO  @cppm_no8, @cpgg_ply8, @cpgg_width8, @cpgg_length8,@quality_level8, @cpgg_add8, @cpph8,@weight8, @procedure_no8, @product_line8,@product_time8, @framework_no8,@prod_workshop_no8, @prod_team_no8,@cpjh8,  @br8, 	@prod_company8,@source_product_code8,@pre_db_company_no8

								IF @@FETCH_STATUS = -1   	--如果没有数据
								   insert into sc_tbcpjhqk (cppm_no1,cpgg_ply1,cpgg_width1,cpgg_length1,quality_level1,cpgg_add1,cpph1,weight1,procedure_no1,product_line1,	product_time1,framework_no1,prod_workshop_no1,prod_team_no1,cpjh1,br1,prod_company1,
											    cppm_no2,cpgg_ply2,cpgg_width2,cpgg_length2,quality_level2,cpgg_add2,cpph2,weight2,procedure_no2,product_line2,	product_time2,framework_no2,prod_workshop_no2,prod_team_no2,cpjh2,br2,prod_company2,
											    cppm_no3,cpgg_ply3,cpgg_width3,cpgg_length3,quality_level3,cpgg_add3,cpph3,weight3,procedure_no3,product_line3,	product_time3,framework_no3,prod_workshop_no3,prod_team_no3,cpjh3,br3,prod_company3,
											    cppm_no4,cpgg_ply4,cpgg_width4,cpgg_length4,quality_level4,cpgg_add4,cpph4,weight4,procedure_no4,product_line4,	product_time4,framework_no4,prod_workshop_no4,prod_team_no4,cpjh4,br4,prod_company4,
											    cppm_no5,cpgg_ply5,cpgg_width5,cpgg_length5,quality_level5,cpgg_add5,cpph5,weight5,procedure_no5,product_line5,	product_time5,framework_no5,prod_workshop_no5,prod_team_no5,cpjh5,br5,prod_company5,
		 									    cppm_no6,cpgg_ply6,cpgg_width6,cpgg_length6,quality_level6,cpgg_add6,cpph6,weight6,procedure_no6,product_line6,	product_time6,framework_no6,prod_workshop_no6,prod_team_no6,cpjh6,br6,prod_company6,
											    cppm_no7,cpgg_ply7,cpgg_width7,cpgg_length7,quality_level7,cpgg_add7,cpph7,weight7,procedure_no7,product_line7,	product_time7,framework_no7,prod_workshop_no7,prod_team_no7,cpjh7,br7,prod_company7,
											    cppm_no20,cpgg_ply20,cpgg_width20,cpgg_length20,quality_level20,cpgg_add20,cpph20,weight20,procedure_no20,product_line20,product_time20,framework_no20,prod_workshop_no20,prod_team_no20,cpjh20,br20,prod_company20,        --记录原料信息
											    hz_month,create_datetime)
													
										values( @cppm_no1, @cpgg_ply1, @cpgg_width1,@cpgg_length1,@quality_level1,@cpgg_add1,@cpph1,@weight1, @procedure_no1,@product_line1,@product_time1, @framework_no1, @prod_workshop_no1,@prod_team_no1,	@cpjh1,  @br1, 	@prod_company1,		
											@cppm_no2, @cpgg_ply2, @cpgg_width2,@cpgg_length2,@quality_level2,@cpgg_add2,@cpph2,@weight2, @procedure_no2,@product_line2,@product_time2, @framework_no2, @prod_workshop_no2,@prod_team_no2,	@cpjh2,  @br2, 	@prod_company2,	
											@cppm_no3, @cpgg_ply3, @cpgg_width3,@cpgg_length3,@quality_level3,@cpgg_add3,@cpph3,@weight3, @procedure_no3,@product_line3,@product_time3, @framework_no3, @prod_workshop_no3,@prod_team_no3,	@cpjh3,  @br3, 	@prod_company3,	
											@cppm_no4, @cpgg_ply4, @cpgg_width4,@cpgg_length4,@quality_level4,@cpgg_add4,@cpph4,@weight4, @procedure_no4,@product_line4,@product_time4, @framework_no4, @prod_workshop_no4,@prod_team_no4,	@cpjh4,  @br4, 	@prod_company4,	
											@cppm_no5, @cpgg_ply5, @cpgg_width5,@cpgg_length5,@quality_level5,@cpgg_add5,@cpph5,@weight5, @procedure_no5,@product_line5,@product_time5, @framework_no5, @prod_workshop_no5,@prod_team_no5,	@cpjh5,  @br5, 	@prod_company5,	
											@cppm_no6, @cpgg_ply6, @cpgg_width6,@cpgg_length6,@quality_level6,@cpgg_add6,@cpph6,@weight6, @procedure_no6,@product_line6,@product_time6, @framework_no6, @prod_workshop_no6,@prod_team_no6,	@cpjh6,  @br6, 	@prod_company6,	
											@cppm_no7, @cpgg_ply7, @cpgg_width7,@cpgg_length7,@quality_level7,@cpgg_add7,@cpph7,@weight7, @procedure_no7,@product_line7,@product_time7, @framework_no7, @prod_workshop_no7,@prod_team_no7,	@cpjh7,  @br7, 	@prod_company7,	
											@cppm_no7, @cpgg_ply7, @cpgg_width7,@cpgg_length7,@quality_level7,@cpgg_add7,@cpph7,@weight7, @procedure_no7,@product_line7,@product_time7, @framework_no7, @prod_workshop_no7,@prod_team_no7,	@cpjh7,  @br7, 	@prod_company7,	--记录原料信息
											@hz_month,getdate()
											)	
								
								WHILE (@@FETCH_STATUS = 0)	--有数据
								BEGIN
		print '888' + @source_product_code8+ '|' +@pre_db_company_no8
									 /*-------------KC_TBCPKCHZS_C9-----------------start-------------------------*/
									DECLARE KC_TBCPKCHZS_C9 SCROLL CURSOR FOR
									       select a.current_product_no,a.current_product_ply,a.current_product_width,a.current_product_length,a.current_product_level,a.current_product_add_no,a.cpph,a.current_product_weight,a.current_procedure_no,
										      a.product_line,a.create_datetime,a.current_company_no,a.current_workshop_no,a.current_team_no,a.current_product_code,a.source_trademark,a.source_prod_company,a.source_product_code,a.pre_db_company_no
										 from vwxbsc1006_xs_tbchange_lines a
									        where a.current_company_no   = @pre_db_company_no8
									          and a.current_product_code = @source_product_code8
									OPEN  KC_TBCPKCHZS_C9
						
									FETCH NEXT FROM kc_tbcpkchzs_C9 INTO  @cppm_no9, @cpgg_ply9, @cpgg_width9, @cpgg_length9,@quality_level9, @cpgg_add9, @cpph9,@weight9, @procedure_no9, @product_line9,@product_time9, @framework_no9,@prod_workshop_no9, @prod_team_no9,@cpjh9,  @br9, 	@prod_company9,@source_product_code9,@pre_db_company_no9
	
									IF @@FETCH_STATUS = -1   	--如果没有数据
									   insert into sc_tbcpjhqk (cppm_no1,cpgg_ply1,cpgg_width1,cpgg_length1,quality_level1,cpgg_add1,cpph1,weight1,procedure_no1,product_line1,	product_time1,framework_no1,prod_workshop_no1,prod_team_no1,cpjh1,br1,prod_company1,
												    cppm_no2,cpgg_ply2,cpgg_width2,cpgg_length2,quality_level2,cpgg_add2,cpph2,weight2,procedure_no2,product_line2,	product_time2,framework_no2,prod_workshop_no2,prod_team_no2,cpjh2,br2,prod_company2,
												    cppm_no3,cpgg_ply3,cpgg_width3,cpgg_length3,quality_level3,cpgg_add3,cpph3,weight3,procedure_no3,product_line3,	product_time3,framework_no3,prod_workshop_no3,prod_team_no3,cpjh3,br3,prod_company3,
												    cppm_no4,cpgg_ply4,cpgg_width4,cpgg_length4,quality_level4,cpgg_add4,cpph4,weight4,procedure_no4,product_line4,	product_time4,framework_no4,prod_workshop_no4,prod_team_no4,cpjh4,br4,prod_company4,
												    cppm_no5,cpgg_ply5,cpgg_width5,cpgg_length5,quality_level5,cpgg_add5,cpph5,weight5,procedure_no5,product_line5,	product_time5,framework_no5,prod_workshop_no5,prod_team_no5,cpjh5,br5,prod_company5,
			 									    cppm_no6,cpgg_ply6,cpgg_width6,cpgg_length6,quality_level6,cpgg_add6,cpph6,weight6,procedure_no6,product_line6,	product_time6,framework_no6,prod_workshop_no6,prod_team_no6,cpjh6,br6,prod_company6,
												    cppm_no7,cpgg_ply7,cpgg_width7,cpgg_length7,quality_level7,cpgg_add7,cpph7,weight7,procedure_no7,product_line7,	product_time7,framework_no7,prod_workshop_no7,prod_team_no7,cpjh7,br7,prod_company7,
 												    cppm_no8,cpgg_ply8,cpgg_width8,cpgg_length8,quality_level8,cpgg_add8,cpph8,weight8,procedure_no8,product_line8,	product_time8,framework_no8,prod_workshop_no8,prod_team_no8,cpjh8,br8,prod_company8,
												    cppm_no20,cpgg_ply20,cpgg_width20,cpgg_length20,quality_level20,cpgg_add20,cpph20,weight20,procedure_no20,product_line20,product_time20,framework_no20,prod_workshop_no20,prod_team_no20,cpjh20,br20,prod_company20,        --记录原料信息
												    hz_month,create_datetime)
														
											values( @cppm_no1, @cpgg_ply1, @cpgg_width1,@cpgg_length1,@quality_level1,@cpgg_add1,@cpph1,@weight1, @procedure_no1,@product_line1,@product_time1, @framework_no1, @prod_workshop_no1,@prod_team_no1,	@cpjh1,  @br1, 	@prod_company1,		
												@cppm_no2, @cpgg_ply2, @cpgg_width2,@cpgg_length2,@quality_level2,@cpgg_add2,@cpph2,@weight2, @procedure_no2,@product_line2,@product_time2, @framework_no2, @prod_workshop_no2,@prod_team_no2,	@cpjh2,  @br2, 	@prod_company2,	
												@cppm_no3, @cpgg_ply3, @cpgg_width3,@cpgg_length3,@quality_level3,@cpgg_add3,@cpph3,@weight3, @procedure_no3,@product_line3,@product_time3, @framework_no3, @prod_workshop_no3,@prod_team_no3,	@cpjh3,  @br3, 	@prod_company3,	
												@cppm_no4, @cpgg_ply4, @cpgg_width4,@cpgg_length4,@quality_level4,@cpgg_add4,@cpph4,@weight4, @procedure_no4,@product_line4,@product_time4, @framework_no4, @prod_workshop_no4,@prod_team_no4,	@cpjh4,  @br4, 	@prod_company4,	
												@cppm_no5, @cpgg_ply5, @cpgg_width5,@cpgg_length5,@quality_level5,@cpgg_add5,@cpph5,@weight5, @procedure_no5,@product_line5,@product_time5, @framework_no5, @prod_workshop_no5,@prod_team_no5,	@cpjh5,  @br5, 	@prod_company5,	
												@cppm_no6, @cpgg_ply6, @cpgg_width6,@cpgg_length6,@quality_level6,@cpgg_add6,@cpph6,@weight6, @procedure_no6,@product_line6,@product_time6, @framework_no6, @prod_workshop_no6,@prod_team_no6,	@cpjh6,  @br6, 	@prod_company6,	
												@cppm_no7, @cpgg_ply7, @cpgg_width7,@cpgg_length7,@quality_level7,@cpgg_add7,@cpph7,@weight7, @procedure_no7,@product_line7,@product_time7, @framework_no7, @prod_workshop_no7,@prod_team_no7,	@cpjh7,  @br7, 	@prod_company7,	
												@cppm_no8, @cpgg_ply8, @cpgg_width8,@cpgg_length8,@quality_level8,@cpgg_add8,@cpph8,@weight8, @procedure_no8,@product_line8,@product_time8, @framework_no8, @prod_workshop_no8,@prod_team_no8,	@cpjh8,  @br8, 	@prod_company8,	
												@cppm_no8, @cpgg_ply8, @cpgg_width8,@cpgg_length8,@quality_level8,@cpgg_add8,@cpph8,@weight8, @procedure_no8,@product_line8,@product_time8, @framework_no8, @prod_workshop_no8,@prod_team_no8,	@cpjh8,  @br8, 	@prod_company8,	--记录原料信息
												@hz_month,getdate()
												)	
									
									WHILE (@@FETCH_STATUS = 0)	--有数据
									BEGIN
			print '999' + @source_product_code9+ '|' +@pre_db_company_no9
										/*-------------KC_TBCPKCHZS_C10-----------------start-------------------------*/
										DECLARE KC_TBCPKCHZS_C10 SCROLL CURSOR FOR
										       select a.current_product_no,a.current_product_ply,a.current_product_width,a.current_product_length,a.current_product_level,a.current_product_add_no,a.cpph,a.current_product_weight,a.current_procedure_no,
											      a.product_line,a.create_datetime,a.current_company_no,a.current_workshop_no,a.current_team_no,a.current_product_code,a.source_trademark,a.source_prod_company,a.source_product_code,a.pre_db_company_no
											 from vwxbsc1006_xs_tbchange_lines a
										        where a.current_company_no   = @pre_db_company_no9
										          and a.current_product_code = @source_product_code9
										OPEN  KC_TBCPKCHZS_C10
							
										FETCH NEXT FROM kc_tbcpkchzs_C10 INTO  @cppm_no10, @cpgg_ply10, @cpgg_width10, @cpgg_length10,@quality_level10, @cpgg_add10, @cpph10,@weight10, @procedure_no10, @product_line10,@product_time10, @framework_no10,@prod_workshop_no10, @prod_team_no10,@cpjh10,  @br10, 	@prod_company10,@source_product_code10,@pre_db_company_no10
		
										IF @@FETCH_STATUS = -1   	--如果没有数据
										   insert into sc_tbcpjhqk (cppm_no1,cpgg_ply1,cpgg_width1,cpgg_length1,quality_level1,cpgg_add1,cpph1,weight1,procedure_no1,product_line1,	product_time1,framework_no1,prod_workshop_no1,prod_team_no1,cpjh1,br1,prod_company1,
													    cppm_no2,cpgg_ply2,cpgg_width2,cpgg_length2,quality_level2,cpgg_add2,cpph2,weight2,procedure_no2,product_line2,	product_time2,framework_no2,prod_workshop_no2,prod_team_no2,cpjh2,br2,prod_company2,
													    cppm_no3,cpgg_ply3,cpgg_width3,cpgg_length3,quality_level3,cpgg_add3,cpph3,weight3,procedure_no3,product_line3,	product_time3,framework_no3,prod_workshop_no3,prod_team_no3,cpjh3,br3,prod_company3,
													    cppm_no4,cpgg_ply4,cpgg_width4,cpgg_length4,quality_level4,cpgg_add4,cpph4,weight4,procedure_no4,product_line4,	product_time4,framework_no4,prod_workshop_no4,prod_team_no4,cpjh4,br4,prod_company4,
													    cppm_no5,cpgg_ply5,cpgg_width5,cpgg_length5,quality_level5,cpgg_add5,cpph5,weight5,procedure_no5,product_line5,	product_time5,framework_no5,prod_workshop_no5,prod_team_no5,cpjh5,br5,prod_company5,
				 									    cppm_no6,cpgg_ply6,cpgg_width6,cpgg_length6,quality_level6,cpgg_add6,cpph6,weight6,procedure_no6,product_line6,	product_time6,framework_no6,prod_workshop_no6,prod_team_no6,cpjh6,br6,prod_company6,
													    cppm_no7,cpgg_ply7,cpgg_width7,cpgg_length7,quality_level7,cpgg_add7,cpph7,weight7,procedure_no7,product_line7,	product_time7,framework_no7,prod_workshop_no7,prod_team_no7,cpjh7,br7,prod_company7,
	 												    cppm_no8,cpgg_ply8,cpgg_width8,cpgg_length8,quality_level8,cpgg_add8,cpph8,weight8,procedure_no8,product_line8,	product_time8,framework_no8,prod_workshop_no8,prod_team_no8,cpjh8,br8,prod_company8,
													    cppm_no9,cpgg_ply9,cpgg_width9,cpgg_length9,quality_level9,cpgg_add9,cpph9,weight9,procedure_no9,product_line9,	product_time9,framework_no9,prod_workshop_no9,prod_team_no9,cpjh9,br9,prod_company9,
													    cppm_no20,cpgg_ply20,cpgg_width20,cpgg_length20,quality_level20,cpgg_add20,cpph20,weight20,procedure_no20,product_line20,product_time20,framework_no20,prod_workshop_no20,prod_team_no20,cpjh20,br20,prod_company20,        --记录原料信息
													    hz_month,create_datetime)
															
												values( @cppm_no1, @cpgg_ply1, @cpgg_width1,@cpgg_length1,@quality_level1,@cpgg_add1,@cpph1,@weight1, @procedure_no1,@product_line1,@product_time1, @framework_no1, @prod_workshop_no1,@prod_team_no1,	@cpjh1,  @br1, 	@prod_company1,		
													@cppm_no2, @cpgg_ply2, @cpgg_width2,@cpgg_length2,@quality_level2,@cpgg_add2,@cpph2,@weight2, @procedure_no2,@product_line2,@product_time2, @framework_no2, @prod_workshop_no2,@prod_team_no2,	@cpjh2,  @br2, 	@prod_company2,	
													@cppm_no3, @cpgg_ply3, @cpgg_width3,@cpgg_length3,@quality_level3,@cpgg_add3,@cpph3,@weight3, @procedure_no3,@product_line3,@product_time3, @framework_no3, @prod_workshop_no3,@prod_team_no3,	@cpjh3,  @br3, 	@prod_company3,	
													@cppm_no4, @cpgg_ply4, @cpgg_width4,@cpgg_length4,@quality_level4,@cpgg_add4,@cpph4,@weight4, @procedure_no4,@product_line4,@product_time4, @framework_no4, @prod_workshop_no4,@prod_team_no4,	@cpjh4,  @br4, 	@prod_company4,	
													@cppm_no5, @cpgg_ply5, @cpgg_width5,@cpgg_length5,@quality_level5,@cpgg_add5,@cpph5,@weight5, @procedure_no5,@product_line5,@product_time5, @framework_no5, @prod_workshop_no5,@prod_team_no5,	@cpjh5,  @br5, 	@prod_company5,	
													@cppm_no6, @cpgg_ply6, @cpgg_width6,@cpgg_length6,@quality_level6,@cpgg_add6,@cpph6,@weight6, @procedure_no6,@product_line6,@product_time6, @framework_no6, @prod_workshop_no6,@prod_team_no6,	@cpjh6,  @br6, 	@prod_company6,	
													@cppm_no7, @cpgg_ply7, @cpgg_width7,@cpgg_length7,@quality_level7,@cpgg_add7,@cpph7,@weight7, @procedure_no7,@product_line7,@product_time7, @framework_no7, @prod_workshop_no7,@prod_team_no7,	@cpjh7,  @br7, 	@prod_company7,	
													@cppm_no8, @cpgg_ply8, @cpgg_width8,@cpgg_length8,@quality_level8,@cpgg_add8,@cpph8,@weight8, @procedure_no8,@product_line8,@product_time8, @framework_no8, @prod_workshop_no8,@prod_team_no8,	@cpjh8,  @br8, 	@prod_company8,	
													@cppm_no9, @cpgg_ply9, @cpgg_width9,@cpgg_length9,@quality_level9,@cpgg_add9,@cpph9,@weight9, @procedure_no9,@product_line9,@product_time9, @framework_no9, @prod_workshop_no9,@prod_team_no9,	@cpjh9,  @br9, 	@prod_company9,	
													@cppm_no9, @cpgg_ply9, @cpgg_width9,@cpgg_length9,@quality_level9,@cpgg_add9,@cpph9,@weight9, @procedure_no9,@product_line9,@product_time9, @framework_no9, @prod_workshop_no9,@prod_team_no9,	@cpjh9,  @br9, 	@prod_company9,--记录原料信息														
													@hz_month,getdate()
													)	
										
										WHILE (@@FETCH_STATUS = 0)	--有数据
										BEGIN
		
											/*-------------KC_TBCPKCHZS_C11-----------------start-------------------------*/
											DECLARE KC_TBCPKCHZS_C11 SCROLL CURSOR FOR
											       select a.current_product_no,a.current_product_ply,a.current_product_width,a.current_product_length,a.current_product_level,a.current_product_add_no,a.cpph,a.current_product_weight,a.current_procedure_no,
												      a.product_line,a.create_datetime,a.current_company_no,a.current_workshop_no,a.current_team_no,a.current_product_code,a.source_trademark,a.source_prod_company,a.source_product_code,a.pre_db_company_no
												 from vwxbsc1006_xs_tbchange_lines a
											        where a.current_company_no   = @pre_db_company_no10
											          and a.current_product_code = @source_product_code10
											OPEN  KC_TBCPKCHZS_C11
								
											FETCH NEXT FROM kc_tbcpkchzs_C11 INTO  @cppm_no11, @cpgg_ply11, @cpgg_width11, @cpgg_length11,@quality_level11, @cpgg_add11, @cpph11,@weight11, @procedure_no11, @product_line11,@product_time11, @framework_no11,@prod_workshop_no11, @prod_team_no11,@cpjh11,  @br11, @prod_company11,@source_product_code11,@pre_db_company_no11
			
											IF @@FETCH_STATUS = -1   	--如果没有数据
											   insert into sc_tbcpjhqk (cppm_no1,cpgg_ply1,cpgg_width1,cpgg_length1,quality_level1,cpgg_add1,cpph1,weight1,procedure_no1,product_line1,	product_time1,framework_no1,prod_workshop_no1,prod_team_no1,cpjh1,br1,prod_company1,
														    cppm_no2,cpgg_ply2,cpgg_width2,cpgg_length2,quality_level2,cpgg_add2,cpph2,weight2,procedure_no2,product_line2,	product_time2,framework_no2,prod_workshop_no2,prod_team_no2,cpjh2,br2,prod_company2,
														    cppm_no3,cpgg_ply3,cpgg_width3,cpgg_length3,quality_level3,cpgg_add3,cpph3,weight3,procedure_no3,product_line3,	product_time3,framework_no3,prod_workshop_no3,prod_team_no3,cpjh3,br3,prod_company3,
														    cppm_no4,cpgg_ply4,cpgg_width4,cpgg_length4,quality_level4,cpgg_add4,cpph4,weight4,procedure_no4,product_line4,	product_time4,framework_no4,prod_workshop_no4,prod_team_no4,cpjh4,br4,prod_company4,
														    cppm_no5,cpgg_ply5,cpgg_width5,cpgg_length5,quality_level5,cpgg_add5,cpph5,weight5,procedure_no5,product_line5,	product_time5,framework_no5,prod_workshop_no5,prod_team_no5,cpjh5,br5,prod_company5,
					 									    cppm_no6,cpgg_ply6,cpgg_width6,cpgg_length6,quality_level6,cpgg_add6,cpph6,weight6,procedure_no6,product_line6,	product_time6,framework_no6,prod_workshop_no6,prod_team_no6,cpjh6,br6,prod_company6,
														    cppm_no7,cpgg_ply7,cpgg_width7,cpgg_length7,quality_level7,cpgg_add7,cpph7,weight7,procedure_no7,product_line7,	product_time7,framework_no7,prod_workshop_no7,prod_team_no7,cpjh7,br7,prod_company7,
		 												    cppm_no8,cpgg_ply8,cpgg_width8,cpgg_length8,quality_level8,cpgg_add8,cpph8,weight8,procedure_no8,product_line8,	product_time8,framework_no8,prod_workshop_no8,prod_team_no8,cpjh8,br8,prod_company8,
														    cppm_no9,cpgg_ply9,cpgg_width9,cpgg_length9,quality_level9,cpgg_add9,cpph9,weight9,procedure_no9,product_line9,	product_time9,framework_no9,prod_workshop_no9,prod_team_no9,cpjh9,br9,prod_company9,
														    cppm_no10,cpgg_ply10,cpgg_width10,cpgg_length10,quality_level10,cpgg_add10,cpph10,weight10,procedure_no10,product_line10,	product_time10,framework_no10,prod_workshop_no10,prod_team_no10,cpjh10,br10,prod_company10,	
														    cppm_no20,cpgg_ply20,cpgg_width20,cpgg_length20,quality_level20,cpgg_add20,cpph20,weight20,procedure_no20,product_line20,product_time20,framework_no20,prod_workshop_no20,prod_team_no20,cpjh20,br20,prod_company20,        --记录原料信息
														    hz_month,create_datetime)
																
													values( @cppm_no1, @cpgg_ply1, @cpgg_width1,@cpgg_length1,@quality_level1,@cpgg_add1,@cpph1,@weight1, @procedure_no1,@product_line1,@product_time1, @framework_no1, @prod_workshop_no1,@prod_team_no1,	@cpjh1,  @br1, 	@prod_company1,		
														@cppm_no2, @cpgg_ply2, @cpgg_width2,@cpgg_length2,@quality_level2,@cpgg_add2,@cpph2,@weight2, @procedure_no2,@product_line2,@product_time2, @framework_no2, @prod_workshop_no2,@prod_team_no2,	@cpjh2,  @br2, 	@prod_company2,	
														@cppm_no3, @cpgg_ply3, @cpgg_width3,@cpgg_length3,@quality_level3,@cpgg_add3,@cpph3,@weight3, @procedure_no3,@product_line3,@product_time3, @framework_no3, @prod_workshop_no3,@prod_team_no3,	@cpjh3,  @br3, 	@prod_company3,	
														@cppm_no4, @cpgg_ply4, @cpgg_width4,@cpgg_length4,@quality_level4,@cpgg_add4,@cpph4,@weight4, @procedure_no4,@product_line4,@product_time4, @framework_no4, @prod_workshop_no4,@prod_team_no4,	@cpjh4,  @br4, 	@prod_company4,	
														@cppm_no5, @cpgg_ply5, @cpgg_width5,@cpgg_length5,@quality_level5,@cpgg_add5,@cpph5,@weight5, @procedure_no5,@product_line5,@product_time5, @framework_no5, @prod_workshop_no5,@prod_team_no5,	@cpjh5,  @br5, 	@prod_company5,	
														@cppm_no6, @cpgg_ply6, @cpgg_width6,@cpgg_length6,@quality_level6,@cpgg_add6,@cpph6,@weight6, @procedure_no6,@product_line6,@product_time6, @framework_no6, @prod_workshop_no6,@prod_team_no6,	@cpjh6,  @br6, 	@prod_company6,	
														@cppm_no7, @cpgg_ply7, @cpgg_width7,@cpgg_length7,@quality_level7,@cpgg_add7,@cpph7,@weight7, @procedure_no7,@product_line7,@product_time7, @framework_no7, @prod_workshop_no7,@prod_team_no7,	@cpjh7,  @br7, 	@prod_company7,	
														@cppm_no8, @cpgg_ply8, @cpgg_width8,@cpgg_length8,@quality_level8,@cpgg_add8,@cpph8,@weight8, @procedure_no8,@product_line8,@product_time8, @framework_no8, @prod_workshop_no8,@prod_team_no8,	@cpjh8,  @br8, 	@prod_company8,	
														@cppm_no9, @cpgg_ply9, @cpgg_width9,@cpgg_length9,@quality_level9,@cpgg_add9,@cpph9,@weight9, @procedure_no9,@product_line9,@product_time9, @framework_no9, @prod_workshop_no9,@prod_team_no9,	@cpjh9,  @br9, 	@prod_company9,	
														@cppm_no10, @cpgg_ply10, @cpgg_width10,@cpgg_length10,@quality_level10,@cpgg_add10,@cpph10,@weight10, @procedure_no10,@product_line10,@product_time10, @framework_no10, @prod_workshop_no10,@prod_team_no10,@cpjh10, @br10, @prod_company10,	
														@cppm_no10, @cpgg_ply10, @cpgg_width10,@cpgg_length10,@quality_level10,@cpgg_add10,@cpph10,@weight10, @procedure_no10,@product_line10,@product_time10, @framework_no10, @prod_workshop_no10,@prod_team_no10,@cpjh10, @br10, @prod_company10,	--记录原料信息
														@hz_month,getdate()
														)	
											
											WHILE (@@FETCH_STATUS = 0)	--有数据
											BEGIN
		
												/*-------------KC_TBCPKCHZS_C12-----------------start-------------------------*/
												DECLARE KC_TBCPKCHZS_C12 SCROLL CURSOR FOR
												       select a.current_product_no,a.current_product_ply,a.current_product_width,a.current_product_length,a.current_product_level,a.current_product_add_no,a.cpph,a.current_product_weight,a.current_procedure_no,
													      a.product_line,a.create_datetime,a.current_company_no,a.current_workshop_no,a.current_team_no,a.current_product_code,a.source_trademark,a.source_prod_company,a.source_product_code,a.pre_db_company_no
													 from vwxbsc1006_xs_tbchange_lines a
												        where a.current_company_no   = @pre_db_company_no11
												          and a.current_product_code = @source_product_code11
												OPEN  KC_TBCPKCHZS_C12
									
												FETCH NEXT FROM KC_TBCPKCHZS_C12 INTO  @cppm_no12, @cpgg_ply12, @cpgg_width12, @cpgg_length12,@quality_level12, @cpgg_add12, @cpph12,@weight12, @procedure_no12, @product_line12,@product_time12, @framework_no12,@prod_workshop_no12, @prod_team_no12,@cpjh12,  @br12, @prod_company12,@source_product_code12,@pre_db_company_no12
				
												IF @@FETCH_STATUS = -1   	--如果没有数据
												   insert into sc_tbcpjhqk (cppm_no1,cpgg_ply1,cpgg_width1,cpgg_length1,quality_level1,cpgg_add1,cpph1,weight1,procedure_no1,product_line1,	product_time1,framework_no1,prod_workshop_no1,prod_team_no1,cpjh1,br1,prod_company1,
															    cppm_no2,cpgg_ply2,cpgg_width2,cpgg_length2,quality_level2,cpgg_add2,cpph2,weight2,procedure_no2,product_line2,	product_time2,framework_no2,prod_workshop_no2,prod_team_no2,cpjh2,br2,prod_company2,
															    cppm_no3,cpgg_ply3,cpgg_width3,cpgg_length3,quality_level3,cpgg_add3,cpph3,weight3,procedure_no3,product_line3,	product_time3,framework_no3,prod_workshop_no3,prod_team_no3,cpjh3,br3,prod_company3,
															    cppm_no4,cpgg_ply4,cpgg_width4,cpgg_length4,quality_level4,cpgg_add4,cpph4,weight4,procedure_no4,product_line4,	product_time4,framework_no4,prod_workshop_no4,prod_team_no4,cpjh4,br4,prod_company4,
															    cppm_no5,cpgg_ply5,cpgg_width5,cpgg_length5,quality_level5,cpgg_add5,cpph5,weight5,procedure_no5,product_line5,	product_time5,framework_no5,prod_workshop_no5,prod_team_no5,cpjh5,br5,prod_company5,
						 									    cppm_no6,cpgg_ply6,cpgg_width6,cpgg_length6,quality_level6,cpgg_add6,cpph6,weight6,procedure_no6,product_line6,	product_time6,framework_no6,prod_workshop_no6,prod_team_no6,cpjh6,br6,prod_company6,
															    cppm_no7,cpgg_ply7,cpgg_width7,cpgg_length7,quality_level7,cpgg_add7,cpph7,weight7,procedure_no7,product_line7,	product_time7,framework_no7,prod_workshop_no7,prod_team_no7,cpjh7,br7,prod_company7,
			 												    cppm_no8,cpgg_ply8,cpgg_width8,cpgg_length8,quality_level8,cpgg_add8,cpph8,weight8,procedure_no8,product_line8,	product_time8,framework_no8,prod_workshop_no8,prod_team_no8,cpjh8,br8,prod_company8,
															    cppm_no9,cpgg_ply9,cpgg_width9,cpgg_length9,quality_level9,cpgg_add9,cpph9,weight9,procedure_no9,product_line9,	product_time9,framework_no9,prod_workshop_no9,prod_team_no9,cpjh9,br9,prod_company9,
															    cppm_no10,cpgg_ply10,cpgg_width10,cpgg_length10,quality_level10,cpgg_add10,cpph10,weight10,procedure_no10,product_line10,	product_time10,framework_no10,prod_workshop_no10,prod_team_no10,cpjh10,br10,prod_company10,	
															    cppm_no11,cpgg_ply11,cpgg_width11,cpgg_length11,quality_level11,cpgg_add11,cpph11,weight11,procedure_no11,product_line11,product_time11,framework_no11,prod_workshop_no11,prod_team_no11,cpjh11,br11,prod_company11,	
															    cppm_no20,cpgg_ply20,cpgg_width20,cpgg_length20,quality_level20,cpgg_add20,cpph20,weight20,procedure_no20,product_line20,product_time20,framework_no20,prod_workshop_no20,prod_team_no20,cpjh20,br20,prod_company20,        --记录原料信息
															    hz_month,create_datetime)
																	
														values( @cppm_no1, @cpgg_ply1, @cpgg_width1,@cpgg_length1,@quality_level1,@cpgg_add1,@cpph1,@weight1, @procedure_no1,@product_line1,@product_time1, @framework_no1, @prod_workshop_no1,@prod_team_no1,	@cpjh1,  @br1, 	@prod_company1,		
															@cppm_no2, @cpgg_ply2, @cpgg_width2,@cpgg_length2,@quality_level2,@cpgg_add2,@cpph2,@weight2, @procedure_no2,@product_line2,@product_time2, @framework_no2, @prod_workshop_no2,@prod_team_no2,	@cpjh2,  @br2, 	@prod_company2,	
															@cppm_no3, @cpgg_ply3, @cpgg_width3,@cpgg_length3,@quality_level3,@cpgg_add3,@cpph3,@weight3, @procedure_no3,@product_line3,@product_time3, @framework_no3, @prod_workshop_no3,@prod_team_no3,	@cpjh3,  @br3, 	@prod_company3,	
															@cppm_no4, @cpgg_ply4, @cpgg_width4,@cpgg_length4,@quality_level4,@cpgg_add4,@cpph4,@weight4, @procedure_no4,@product_line4,@product_time4, @framework_no4, @prod_workshop_no4,@prod_team_no4,	@cpjh4,  @br4, 	@prod_company4,	
															@cppm_no5, @cpgg_ply5, @cpgg_width5,@cpgg_length5,@quality_level5,@cpgg_add5,@cpph5,@weight5, @procedure_no5,@product_line5,@product_time5, @framework_no5, @prod_workshop_no5,@prod_team_no5,	@cpjh5,  @br5, 	@prod_company5,	
															@cppm_no6, @cpgg_ply6, @cpgg_width6,@cpgg_length6,@quality_level6,@cpgg_add6,@cpph6,@weight6, @procedure_no6,@product_line6,@product_time6, @framework_no6, @prod_workshop_no6,@prod_team_no6,	@cpjh6,  @br6, 	@prod_company6,	
															@cppm_no7, @cpgg_ply7, @cpgg_width7,@cpgg_length7,@quality_level7,@cpgg_add7,@cpph7,@weight7, @procedure_no7,@product_line7,@product_time7, @framework_no7, @prod_workshop_no7,@prod_team_no7,	@cpjh7,  @br7, 	@prod_company7,	
															@cppm_no8, @cpgg_ply8, @cpgg_width8,@cpgg_length8,@quality_level8,@cpgg_add8,@cpph8,@weight8, @procedure_no8,@product_line8,@product_time8, @framework_no8, @prod_workshop_no8,@prod_team_no8,	@cpjh8,  @br8, 	@prod_company8,	
															@cppm_no9, @cpgg_ply9, @cpgg_width9,@cpgg_length9,@quality_level9,@cpgg_add9,@cpph9,@weight9, @procedure_no9,@product_line9,@product_time9, @framework_no9, @prod_workshop_no9,@prod_team_no9,	@cpjh9,  @br9, 	@prod_company9,	
															@cppm_no10,@cpgg_ply10,@cpgg_width10,@cpgg_length10,@quality_level10,@cpgg_add10,@cpph10,@weight10,@procedure_no10,@product_line10,@product_time10,@framework_no10,@prod_workshop_no10,@prod_team_no10,@cpjh10, @br10, @prod_company10,	
															@cppm_no11,@cpgg_ply11,@cpgg_width11,@cpgg_length11,@quality_level11,@cpgg_add11,@cpph11,@weight11,@procedure_no11,@product_line11,@product_time11,@framework_no11,@prod_workshop_no11,@prod_team_no11,@cpjh11,@br11,@prod_company11,	
															@cppm_no11,@cpgg_ply11,@cpgg_width11,@cpgg_length11,@quality_level11,@cpgg_add11,@cpph11,@weight11,@procedure_no11,@product_line11,@product_time11,@framework_no11,@prod_workshop_no11,@prod_team_no11,@cpjh11,@br11,@prod_company11,	--记录原料信息
															@hz_month,getdate()
															)	
												
												WHILE (@@FETCH_STATUS = 0)	--有数据
												BEGIN
				
													/*-------------KC_TBCPKCHZS_C13-----------------start-------------------------*/
													DECLARE KC_TBCPKCHZS_C13 SCROLL CURSOR FOR
													       select a.current_product_no,a.current_product_ply,a.current_product_width,a.current_product_length,a.current_product_level,a.current_product_add_no,a.cpph,a.current_product_weight,a.current_procedure_no,
														      a.product_line,a.create_datetime,a.current_company_no,a.current_workshop_no,a.current_team_no,a.current_product_code,a.source_trademark,a.source_prod_company,a.source_product_code,a.pre_db_company_no
														 from vwxbsc1006_xs_tbchange_lines a
													        where a.current_company_no   = @pre_db_company_no12
													          and a.current_product_code = @source_product_code12
													OPEN  KC_TBCPKCHZS_C13
										
													FETCH NEXT FROM KC_TBCPKCHZS_C13 INTO  @cppm_no13, @cpgg_ply13, @cpgg_width13, @cpgg_length13,@quality_level13, @cpgg_add13, @cpph13,@weight13, @procedure_no13, @product_line13,@product_time13, @framework_no13,@prod_workshop_no13, @prod_team_no13,@cpjh13,  @br13, @prod_company13,@source_product_code13,@pre_db_company_no13
					
													IF @@FETCH_STATUS = -1   	--如果没有数据
													   insert into sc_tbcpjhqk (cppm_no1,cpgg_ply1,cpgg_width1,cpgg_length1,quality_level1,cpgg_add1,cpph1,weight1,procedure_no1,product_line1,	product_time1,framework_no1,prod_workshop_no1,prod_team_no1,cpjh1,br1,prod_company1,
																    cppm_no2,cpgg_ply2,cpgg_width2,cpgg_length2,quality_level2,cpgg_add2,cpph2,weight2,procedure_no2,product_line2,	product_time2,framework_no2,prod_workshop_no2,prod_team_no2,cpjh2,br2,prod_company2,
																    cppm_no3,cpgg_ply3,cpgg_width3,cpgg_length3,quality_level3,cpgg_add3,cpph3,weight3,procedure_no3,product_line3,	product_time3,framework_no3,prod_workshop_no3,prod_team_no3,cpjh3,br3,prod_company3,
																    cppm_no4,cpgg_ply4,cpgg_width4,cpgg_length4,quality_level4,cpgg_add4,cpph4,weight4,procedure_no4,product_line4,	product_time4,framework_no4,prod_workshop_no4,prod_team_no4,cpjh4,br4,prod_company4,
																    cppm_no5,cpgg_ply5,cpgg_width5,cpgg_length5,quality_level5,cpgg_add5,cpph5,weight5,procedure_no5,product_line5,	product_time5,framework_no5,prod_workshop_no5,prod_team_no5,cpjh5,br5,prod_company5,
							 									    cppm_no6,cpgg_ply6,cpgg_width6,cpgg_length6,quality_level6,cpgg_add6,cpph6,weight6,procedure_no6,product_line6,	product_time6,framework_no6,prod_workshop_no6,prod_team_no6,cpjh6,br6,prod_company6,
																    cppm_no7,cpgg_ply7,cpgg_width7,cpgg_length7,quality_level7,cpgg_add7,cpph7,weight7,procedure_no7,product_line7,	product_time7,framework_no7,prod_workshop_no7,prod_team_no7,cpjh7,br7,prod_company7,
				 												    cppm_no8,cpgg_ply8,cpgg_width8,cpgg_length8,quality_level8,cpgg_add8,cpph8,weight8,procedure_no8,product_line8,	product_time8,framework_no8,prod_workshop_no8,prod_team_no8,cpjh8,br8,prod_company8,
																    cppm_no9,cpgg_ply9,cpgg_width9,cpgg_length9,quality_level9,cpgg_add9,cpph9,weight9,procedure_no9,product_line9,	product_time9,framework_no9,prod_workshop_no9,prod_team_no9,cpjh9,br9,prod_company9,
																    cppm_no10,cpgg_ply10,cpgg_width10,cpgg_length10,quality_level10,cpgg_add10,cpph10,weight10,procedure_no10,product_line10,	product_time10,framework_no10,prod_workshop_no10,prod_team_no10,cpjh10,br10,prod_company10,	
																    cppm_no11,cpgg_ply11,cpgg_width11,cpgg_length11,quality_level11,cpgg_add11,cpph11,weight11,procedure_no11,product_line11,product_time11,framework_no11,prod_workshop_no11,prod_team_no11,cpjh11,br11,prod_company11,	
																    cppm_no12,cpgg_ply12,cpgg_width12,cpgg_length12,quality_level12,cpgg_add12,cpph12,weight12,procedure_no12,product_line12,product_time12,framework_no12,prod_workshop_no12,prod_team_no12,cpjh12,br12,prod_company12,	
																    cppm_no20,cpgg_ply20,cpgg_width20,cpgg_length20,quality_level20,cpgg_add20,cpph20,weight20,procedure_no20,product_line20,product_time20,framework_no20,prod_workshop_no20,prod_team_no20,cpjh20,br20,prod_company20,        --记录原料信息
																    hz_month,create_datetime)
																		
															values( @cppm_no1, @cpgg_ply1, @cpgg_width1,@cpgg_length1,@quality_level1,@cpgg_add1,@cpph1,@weight1, @procedure_no1,@product_line1,@product_time1, @framework_no1, @prod_workshop_no1,@prod_team_no1,	@cpjh1,  @br1, 	@prod_company1,		
																@cppm_no2, @cpgg_ply2, @cpgg_width2,@cpgg_length2,@quality_level2,@cpgg_add2,@cpph2,@weight2, @procedure_no2,@product_line2,@product_time2, @framework_no2, @prod_workshop_no2,@prod_team_no2,	@cpjh2,  @br2, 	@prod_company2,	
																@cppm_no3, @cpgg_ply3, @cpgg_width3,@cpgg_length3,@quality_level3,@cpgg_add3,@cpph3,@weight3, @procedure_no3,@product_line3,@product_time3, @framework_no3, @prod_workshop_no3,@prod_team_no3,	@cpjh3,  @br3, 	@prod_company3,	
																@cppm_no4, @cpgg_ply4, @cpgg_width4,@cpgg_length4,@quality_level4,@cpgg_add4,@cpph4,@weight4, @procedure_no4,@product_line4,@product_time4, @framework_no4, @prod_workshop_no4,@prod_team_no4,	@cpjh4,  @br4, 	@prod_company4,	
																@cppm_no5, @cpgg_ply5, @cpgg_width5,@cpgg_length5,@quality_level5,@cpgg_add5,@cpph5,@weight5, @procedure_no5,@product_line5,@product_time5, @framework_no5, @prod_workshop_no5,@prod_team_no5,	@cpjh5,  @br5, 	@prod_company5,	
																@cppm_no6, @cpgg_ply6, @cpgg_width6,@cpgg_length6,@quality_level6,@cpgg_add6,@cpph6,@weight6, @procedure_no6,@product_line6,@product_time6, @framework_no6, @prod_workshop_no6,@prod_team_no6,	@cpjh6,  @br6, 	@prod_company6,	
																@cppm_no7, @cpgg_ply7, @cpgg_width7,@cpgg_length7,@quality_level7,@cpgg_add7,@cpph7,@weight7, @procedure_no7,@product_line7,@product_time7, @framework_no7, @prod_workshop_no7,@prod_team_no7,	@cpjh7,  @br7, 	@prod_company7,	
																@cppm_no8, @cpgg_ply8, @cpgg_width8,@cpgg_length8,@quality_level8,@cpgg_add8,@cpph8,@weight8, @procedure_no8,@product_line8,@product_time8, @framework_no8, @prod_workshop_no8,@prod_team_no8,	@cpjh8,  @br8, 	@prod_company8,	
																@cppm_no9, @cpgg_ply9, @cpgg_width9,@cpgg_length9,@quality_level9,@cpgg_add9,@cpph9,@weight9, @procedure_no9,@product_line9,@product_time9, @framework_no9, @prod_workshop_no9,@prod_team_no9,	@cpjh9,  @br9, 	@prod_company9,	
																@cppm_no10,@cpgg_ply10,@cpgg_width10,@cpgg_length10,@quality_level10,@cpgg_add10,@cpph10,@weight10,@procedure_no10,@product_line10,@product_time10,@framework_no10,@prod_workshop_no10,@prod_team_no10,@cpjh10, @br10, @prod_company10,	
																@cppm_no11,@cpgg_ply11,@cpgg_width11,@cpgg_length11,@quality_level11,@cpgg_add11,@cpph11,@weight11,@procedure_no11,@product_line11,@product_time11,@framework_no11,@prod_workshop_no11,@prod_team_no11,@cpjh11,@br11,@prod_company11,
																@cppm_no12,@cpgg_ply12,@cpgg_width12,@cpgg_length12,@quality_level12,@cpgg_add12,@cpph12,@weight12,@procedure_no12,@product_line12,@product_time12,@framework_no12,@prod_workshop_no12,@prod_team_no12,@cpjh12,@br12,@prod_company12,	
																@cppm_no12,@cpgg_ply12,@cpgg_width12,@cpgg_length12,@quality_level12,@cpgg_add12,@cpph12,@weight12,@procedure_no12,@product_line12,@product_time12,@framework_no12,@prod_workshop_no12,@prod_team_no12,@cpjh12,@br12,@prod_company12,		--记录原料信息
																@hz_month,getdate()
																)	
													
													WHILE (@@FETCH_STATUS = 0)	--有数据
													BEGIN
					
														/*-------------KC_TBCPKCHZS_C14-----------------start-------------------------*/
														DECLARE KC_TBCPKCHZS_C14 SCROLL CURSOR FOR
														       select a.current_product_no,a.current_product_ply,a.current_product_width,a.current_product_length,a.current_product_level,a.current_product_add_no,a.cpph,a.current_product_weight,a.current_procedure_no,
															      a.product_line,a.create_datetime,a.current_company_no,a.current_workshop_no,a.current_team_no,a.current_product_code,a.source_trademark,a.source_prod_company,a.source_product_code,a.pre_db_company_no
															 from vwxbsc1006_xs_tbchange_lines a
														        where a.current_company_no   = @pre_db_company_no13
														          and a.current_product_code = @source_product_code13
														OPEN  KC_TBCPKCHZS_C14
											
														FETCH NEXT FROM KC_TBCPKCHZS_C14 INTO  @cppm_no14, @cpgg_ply14, @cpgg_width14, @cpgg_length14,@quality_level14, @cpgg_add14, @cpph14,@weight14, @procedure_no14, @product_line14,@product_time14, @framework_no14,@prod_workshop_no14, @prod_team_no14,@cpjh14,  @br14, @prod_company14,@source_product_code14,@pre_db_company_no14
						
														IF @@FETCH_STATUS = -1   	--如果没有数据
														   insert into sc_tbcpjhqk (cppm_no1,cpgg_ply1,cpgg_width1,cpgg_length1,quality_level1,cpgg_add1,cpph1,weight1,procedure_no1,product_line1,	product_time1,framework_no1,prod_workshop_no1,prod_team_no1,cpjh1,br1,prod_company1,
																	    cppm_no2,cpgg_ply2,cpgg_width2,cpgg_length2,quality_level2,cpgg_add2,cpph2,weight2,procedure_no2,product_line2,	product_time2,framework_no2,prod_workshop_no2,prod_team_no2,cpjh2,br2,prod_company2,
																	    cppm_no3,cpgg_ply3,cpgg_width3,cpgg_length3,quality_level3,cpgg_add3,cpph3,weight3,procedure_no3,product_line3,	product_time3,framework_no3,prod_workshop_no3,prod_team_no3,cpjh3,br3,prod_company3,
																	    cppm_no4,cpgg_ply4,cpgg_width4,cpgg_length4,quality_level4,cpgg_add4,cpph4,weight4,procedure_no4,product_line4,	product_time4,framework_no4,prod_workshop_no4,prod_team_no4,cpjh4,br4,prod_company4,
																	    cppm_no5,cpgg_ply5,cpgg_width5,cpgg_length5,quality_level5,cpgg_add5,cpph5,weight5,procedure_no5,product_line5,	product_time5,framework_no5,prod_workshop_no5,prod_team_no5,cpjh5,br5,prod_company5,
								 									    cppm_no6,cpgg_ply6,cpgg_width6,cpgg_length6,quality_level6,cpgg_add6,cpph6,weight6,procedure_no6,product_line6,	product_time6,framework_no6,prod_workshop_no6,prod_team_no6,cpjh6,br6,prod_company6,
																	    cppm_no7,cpgg_ply7,cpgg_width7,cpgg_length7,quality_level7,cpgg_add7,cpph7,weight7,procedure_no7,product_line7,	product_time7,framework_no7,prod_workshop_no7,prod_team_no7,cpjh7,br7,prod_company7,
					 												    cppm_no8,cpgg_ply8,cpgg_width8,cpgg_length8,quality_level8,cpgg_add8,cpph8,weight8,procedure_no8,product_line8,	product_time8,framework_no8,prod_workshop_no8,prod_team_no8,cpjh8,br8,prod_company8,
																	    cppm_no9,cpgg_ply9,cpgg_width9,cpgg_length9,quality_level9,cpgg_add9,cpph9,weight9,procedure_no9,product_line9,	product_time9,framework_no9,prod_workshop_no9,prod_team_no9,cpjh9,br9,prod_company9,
																	    cppm_no10,cpgg_ply10,cpgg_width10,cpgg_length10,quality_level10,cpgg_add10,cpph10,weight10,procedure_no10,product_line10,	product_time10,framework_no10,prod_workshop_no10,prod_team_no10,cpjh10,br10,prod_company10,	
																	    cppm_no11,cpgg_ply11,cpgg_width11,cpgg_length11,quality_level11,cpgg_add11,cpph11,weight11,procedure_no11,product_line11,product_time11,framework_no11,prod_workshop_no11,prod_team_no11,cpjh11,br11,prod_company11,	
																	    cppm_no12,cpgg_ply12,cpgg_width12,cpgg_length12,quality_level12,cpgg_add12,cpph12,weight12,procedure_no12,product_line12,product_time12,framework_no12,prod_workshop_no12,prod_team_no12,cpjh12,br12,prod_company12,	
																	    cppm_no13,cpgg_ply13,cpgg_width13,cpgg_length13,quality_level13,cpgg_add13,cpph13,weight13,procedure_no13,product_line13,product_time13,framework_no13,prod_workshop_no13,prod_team_no13,cpjh13,br13,prod_company13,	
																	    cppm_no20,cpgg_ply20,cpgg_width20,cpgg_length20,quality_level20,cpgg_add20,cpph20,weight20,procedure_no20,product_line20,product_time20,framework_no20,prod_workshop_no20,prod_team_no20,cpjh20,br20,prod_company20,        --记录原料信息
																	    hz_month,create_datetime)
																			
																values( @cppm_no1, @cpgg_ply1, @cpgg_width1,@cpgg_length1,@quality_level1,@cpgg_add1,@cpph1,@weight1, @procedure_no1,@product_line1,@product_time1, @framework_no1, @prod_workshop_no1,@prod_team_no1,	@cpjh1,  @br1, 	@prod_company1,		
																	@cppm_no2, @cpgg_ply2, @cpgg_width2,@cpgg_length2,@quality_level2,@cpgg_add2,@cpph2,@weight2, @procedure_no2,@product_line2,@product_time2, @framework_no2, @prod_workshop_no2,@prod_team_no2,	@cpjh2,  @br2, 	@prod_company2,	
																	@cppm_no3, @cpgg_ply3, @cpgg_width3,@cpgg_length3,@quality_level3,@cpgg_add3,@cpph3,@weight3, @procedure_no3,@product_line3,@product_time3, @framework_no3, @prod_workshop_no3,@prod_team_no3,	@cpjh3,  @br3, 	@prod_company3,	
																	@cppm_no4, @cpgg_ply4, @cpgg_width4,@cpgg_length4,@quality_level4,@cpgg_add4,@cpph4,@weight4, @procedure_no4,@product_line4,@product_time4, @framework_no4, @prod_workshop_no4,@prod_team_no4,	@cpjh4,  @br4, 	@prod_company4,	
																	@cppm_no5, @cpgg_ply5, @cpgg_width5,@cpgg_length5,@quality_level5,@cpgg_add5,@cpph5,@weight5, @procedure_no5,@product_line5,@product_time5, @framework_no5, @prod_workshop_no5,@prod_team_no5,	@cpjh5,  @br5, 	@prod_company5,	
																	@cppm_no6, @cpgg_ply6, @cpgg_width6,@cpgg_length6,@quality_level6,@cpgg_add6,@cpph6,@weight6, @procedure_no6,@product_line6,@product_time6, @framework_no6, @prod_workshop_no6,@prod_team_no6,	@cpjh6,  @br6, 	@prod_company6,	
																	@cppm_no7, @cpgg_ply7, @cpgg_width7,@cpgg_length7,@quality_level7,@cpgg_add7,@cpph7,@weight7, @procedure_no7,@product_line7,@product_time7, @framework_no7, @prod_workshop_no7,@prod_team_no7,	@cpjh7,  @br7, 	@prod_company7,	
																	@cppm_no8, @cpgg_ply8, @cpgg_width8,@cpgg_length8,@quality_level8,@cpgg_add8,@cpph8,@weight8, @procedure_no8,@product_line8,@product_time8, @framework_no8, @prod_workshop_no8,@prod_team_no8,	@cpjh8,  @br8, 	@prod_company8,	
																	@cppm_no9, @cpgg_ply9, @cpgg_width9,@cpgg_length9,@quality_level9,@cpgg_add9,@cpph9,@weight9, @procedure_no9,@product_line9,@product_time9, @framework_no9, @prod_workshop_no9,@prod_team_no9,	@cpjh9,  @br9, 	@prod_company9,	
																	@cppm_no10,@cpgg_ply10,@cpgg_width10,@cpgg_length10,@quality_level10,@cpgg_add10,@cpph10,@weight10,@procedure_no10,@product_line10,@product_time10,@framework_no10,@prod_workshop_no10,@prod_team_no10,@cpjh10, @br10, @prod_company10,	
																	@cppm_no11,@cpgg_ply11,@cpgg_width11,@cpgg_length11,@quality_level11,@cpgg_add11,@cpph11,@weight11,@procedure_no11,@product_line11,@product_time11,@framework_no11,@prod_workshop_no11,@prod_team_no11,@cpjh11,@br11,@prod_company11,
																	@cppm_no12,@cpgg_ply12,@cpgg_width12,@cpgg_length12,@quality_level12,@cpgg_add12,@cpph12,@weight12,@procedure_no12,@product_line12,@product_time12,@framework_no12,@prod_workshop_no12,@prod_team_no12,@cpjh12,@br12,@prod_company12,	
																	@cppm_no13,@cpgg_ply13,@cpgg_width13,@cpgg_length13,@quality_level13,@cpgg_add13,@cpph13,@weight13,@procedure_no13,@product_line13,@product_time13,@framework_no13,@prod_workshop_no13,@prod_team_no13,@cpjh13,@br13,@prod_company13,	
																	@cppm_no13,@cpgg_ply13,@cpgg_width13,@cpgg_length13,@quality_level13,@cpgg_add13,@cpph13,@weight13,@procedure_no13,@product_line13,@product_time13,@framework_no13,@prod_workshop_no13,@prod_team_no13,@cpjh13,@br13,@prod_company13,	--记录原料信息
																	@hz_month,getdate()
																	)	
														
														WHILE (@@FETCH_STATUS = 0)	--有数据
														BEGIN
						
															/*-------------KC_TBCPKCHZS_C15-----------------start-------------------------*/
															DECLARE KC_TBCPKCHZS_C15 SCROLL CURSOR FOR
															       select a.current_product_no,a.current_product_ply,a.current_product_width,a.current_product_length,a.current_product_level,a.current_product_add_no,a.cpph,a.current_product_weight,a.current_procedure_no,
																      a.product_line,a.create_datetime,a.current_company_no,a.current_workshop_no,a.current_team_no,a.current_product_code,a.source_trademark,a.source_prod_company,a.source_product_code,a.pre_db_company_no
																 from vwxbsc1006_xs_tbchange_lines a
															        where a.current_company_no   = @pre_db_company_no14
															          and a.current_product_code = @source_product_code14
															OPEN  KC_TBCPKCHZS_C15
												
															FETCH NEXT FROM KC_TBCPKCHZS_C15 INTO  @cppm_no15, @cpgg_ply15, @cpgg_width15, @cpgg_length15,@quality_level15, @cpgg_add15, @cpph15,@weight15, @procedure_no15, @product_line15,@product_time15, @framework_no15,@prod_workshop_no15, @prod_team_no15,@cpjh15,  @br15, @prod_company15,@source_product_code15,@pre_db_company_no15
							
															IF @@FETCH_STATUS = -1   	--如果没有数据
															   insert into sc_tbcpjhqk (cppm_no1,cpgg_ply1,cpgg_width1,cpgg_length1,quality_level1,cpgg_add1,cpph1,weight1,procedure_no1,product_line1,	product_time1,framework_no1,prod_workshop_no1,prod_team_no1,cpjh1,br1,prod_company1,
																		    cppm_no2,cpgg_ply2,cpgg_width2,cpgg_length2,quality_level2,cpgg_add2,cpph2,weight2,procedure_no2,product_line2,	product_time2,framework_no2,prod_workshop_no2,prod_team_no2,cpjh2,br2,prod_company2,
																		    cppm_no3,cpgg_ply3,cpgg_width3,cpgg_length3,quality_level3,cpgg_add3,cpph3,weight3,procedure_no3,product_line3,	product_time3,framework_no3,prod_workshop_no3,prod_team_no3,cpjh3,br3,prod_company3,
																		    cppm_no4,cpgg_ply4,cpgg_width4,cpgg_length4,quality_level4,cpgg_add4,cpph4,weight4,procedure_no4,product_line4,	product_time4,framework_no4,prod_workshop_no4,prod_team_no4,cpjh4,br4,prod_company4,
																		    cppm_no5,cpgg_ply5,cpgg_width5,cpgg_length5,quality_level5,cpgg_add5,cpph5,weight5,procedure_no5,product_line5,	product_time5,framework_no5,prod_workshop_no5,prod_team_no5,cpjh5,br5,prod_company5,
									 									    cppm_no6,cpgg_ply6,cpgg_width6,cpgg_length6,quality_level6,cpgg_add6,cpph6,weight6,procedure_no6,product_line6,	product_time6,framework_no6,prod_workshop_no6,prod_team_no6,cpjh6,br6,prod_company6,
																		    cppm_no7,cpgg_ply7,cpgg_width7,cpgg_length7,quality_level7,cpgg_add7,cpph7,weight7,procedure_no7,product_line7,	product_time7,framework_no7,prod_workshop_no7,prod_team_no7,cpjh7,br7,prod_company7,
						 												    cppm_no8,cpgg_ply8,cpgg_width8,cpgg_length8,quality_level8,cpgg_add8,cpph8,weight8,procedure_no8,product_line8,	product_time8,framework_no8,prod_workshop_no8,prod_team_no8,cpjh8,br8,prod_company8,
																		    cppm_no9,cpgg_ply9,cpgg_width9,cpgg_length9,quality_level9,cpgg_add9,cpph9,weight9,procedure_no9,product_line9,	product_time9,framework_no9,prod_workshop_no9,prod_team_no9,cpjh9,br9,prod_company9,
																		    cppm_no10,cpgg_ply10,cpgg_width10,cpgg_length10,quality_level10,cpgg_add10,cpph10,weight10,procedure_no10,product_line10,	product_time10,framework_no10,prod_workshop_no10,prod_team_no10,cpjh10,br10,prod_company10,	
																		    cppm_no11,cpgg_ply11,cpgg_width11,cpgg_length11,quality_level11,cpgg_add11,cpph11,weight11,procedure_no11,product_line11,product_time11,framework_no11,prod_workshop_no11,prod_team_no11,cpjh11,br11,prod_company11,	
																		    cppm_no12,cpgg_ply12,cpgg_width12,cpgg_length12,quality_level12,cpgg_add12,cpph12,weight12,procedure_no12,product_line12,product_time12,framework_no12,prod_workshop_no12,prod_team_no12,cpjh12,br12,prod_company12,	
																		    cppm_no13,cpgg_ply13,cpgg_width13,cpgg_length13,quality_level13,cpgg_add13,cpph13,weight13,procedure_no13,product_line13,product_time13,framework_no13,prod_workshop_no13,prod_team_no13,cpjh13,br13,prod_company13,	
																		    cppm_no14,cpgg_ply14,cpgg_width14,cpgg_length14,quality_level14,cpgg_add14,cpph14,weight14,procedure_no14,product_line14,product_time14,framework_no14,prod_workshop_no14,prod_team_no14,cpjh14,br14,prod_company14,	
																		    cppm_no20,cpgg_ply20,cpgg_width20,cpgg_length20,quality_level20,cpgg_add20,cpph20,weight20,procedure_no20,product_line20,product_time20,framework_no20,prod_workshop_no20,prod_team_no20,cpjh20,br20,prod_company20,        --记录原料信息
																		    hz_month,create_datetime)
																				
																	values( @cppm_no1, @cpgg_ply1, @cpgg_width1,@cpgg_length1,@quality_level1,@cpgg_add1,@cpph1,@weight1, @procedure_no1,@product_line1,@product_time1, @framework_no1, @prod_workshop_no1,@prod_team_no1,	@cpjh1,  @br1, 	@prod_company1,		
																		@cppm_no2, @cpgg_ply2, @cpgg_width2,@cpgg_length2,@quality_level2,@cpgg_add2,@cpph2,@weight2, @procedure_no2,@product_line2,@product_time2, @framework_no2, @prod_workshop_no2,@prod_team_no2,	@cpjh2,  @br2, 	@prod_company2,	
																		@cppm_no3, @cpgg_ply3, @cpgg_width3,@cpgg_length3,@quality_level3,@cpgg_add3,@cpph3,@weight3, @procedure_no3,@product_line3,@product_time3, @framework_no3, @prod_workshop_no3,@prod_team_no3,	@cpjh3,  @br3, 	@prod_company3,	
																		@cppm_no4, @cpgg_ply4, @cpgg_width4,@cpgg_length4,@quality_level4,@cpgg_add4,@cpph4,@weight4, @procedure_no4,@product_line4,@product_time4, @framework_no4, @prod_workshop_no4,@prod_team_no4,	@cpjh4,  @br4, 	@prod_company4,	
																		@cppm_no5, @cpgg_ply5, @cpgg_width5,@cpgg_length5,@quality_level5,@cpgg_add5,@cpph5,@weight5, @procedure_no5,@product_line5,@product_time5, @framework_no5, @prod_workshop_no5,@prod_team_no5,	@cpjh5,  @br5, 	@prod_company5,	
																		@cppm_no6, @cpgg_ply6, @cpgg_width6,@cpgg_length6,@quality_level6,@cpgg_add6,@cpph6,@weight6, @procedure_no6,@product_line6,@product_time6, @framework_no6, @prod_workshop_no6,@prod_team_no6,	@cpjh6,  @br6, 	@prod_company6,	
																		@cppm_no7, @cpgg_ply7, @cpgg_width7,@cpgg_length7,@quality_level7,@cpgg_add7,@cpph7,@weight7, @procedure_no7,@product_line7,@product_time7, @framework_no7, @prod_workshop_no7,@prod_team_no7,	@cpjh7,  @br7, 	@prod_company7,	
																		@cppm_no8, @cpgg_ply8, @cpgg_width8,@cpgg_length8,@quality_level8,@cpgg_add8,@cpph8,@weight8, @procedure_no8,@product_line8,@product_time8, @framework_no8, @prod_workshop_no8,@prod_team_no8,	@cpjh8,  @br8, 	@prod_company8,	
																		@cppm_no9, @cpgg_ply9, @cpgg_width9,@cpgg_length9,@quality_level9,@cpgg_add9,@cpph9,@weight9, @procedure_no9,@product_line9,@product_time9, @framework_no9, @prod_workshop_no9,@prod_team_no9,	@cpjh9,  @br9, 	@prod_company9,	
																		@cppm_no10,@cpgg_ply10,@cpgg_width10,@cpgg_length10,@quality_level10,@cpgg_add10,@cpph10,@weight10,@procedure_no10,@product_line10,@product_time10,@framework_no10,@prod_workshop_no10,@prod_team_no10,@cpjh10, @br10, @prod_company10,	
																		@cppm_no11,@cpgg_ply11,@cpgg_width11,@cpgg_length11,@quality_level11,@cpgg_add11,@cpph11,@weight11,@procedure_no11,@product_line11,@product_time11,@framework_no11,@prod_workshop_no11,@prod_team_no11,@cpjh11,@br11,@prod_company11,
																		@cppm_no12,@cpgg_ply12,@cpgg_width12,@cpgg_length12,@quality_level12,@cpgg_add12,@cpph12,@weight12,@procedure_no12,@product_line12,@product_time12,@framework_no12,@prod_workshop_no12,@prod_team_no12,@cpjh12,@br12,@prod_company12,	
																		@cppm_no13,@cpgg_ply13,@cpgg_width13,@cpgg_length13,@quality_level13,@cpgg_add13,@cpph13,@weight13,@procedure_no13,@product_line13,@product_time13,@framework_no13,@prod_workshop_no13,@prod_team_no13,@cpjh13,@br13,@prod_company13,	
																		@cppm_no14,@cpgg_ply14,@cpgg_width14,@cpgg_length14,@quality_level14,@cpgg_add14,@cpph14,@weight14,@procedure_no14,@product_line14,@product_time14,@framework_no14,@prod_workshop_no14,@prod_team_no14,@cpjh14,@br14,@prod_company14,
																		@cppm_no14,@cpgg_ply14,@cpgg_width14,@cpgg_length14,@quality_level14,@cpgg_add14,@cpph14,@weight14,@procedure_no14,@product_line14,@product_time14,@framework_no14,@prod_workshop_no14,@prod_team_no14,@cpjh14,@br14,@prod_company14,	--记录原料信息
																		@hz_month,getdate()
																		)	
															
															WHILE (@@FETCH_STATUS = 0)	--有数据
															BEGIN
							
															   insert into sc_tbcpjhqk (cppm_no1,cpgg_ply1,cpgg_width1,cpgg_length1,quality_level1,cpgg_add1,cpph1,weight1,procedure_no1,product_line1,product_time1,framework_no1,prod_workshop_no1,prod_team_no1,cpjh1,br1,prod_company1,
																		    cppm_no2,cpgg_ply2,cpgg_width2,cpgg_length2,quality_level2,cpgg_add2,cpph2,weight2,procedure_no2,product_line2,product_time2,framework_no2,prod_workshop_no2,prod_team_no2,cpjh2,br2,prod_company2,
																		    cppm_no3,cpgg_ply3,cpgg_width3,cpgg_length3,quality_level3,cpgg_add3,cpph3,weight3,procedure_no3,product_line3,product_time3,framework_no3,prod_workshop_no3,prod_team_no3,cpjh3,br3,prod_company3,
																		    cppm_no4,cpgg_ply4,cpgg_width4,cpgg_length4,quality_level4,cpgg_add4,cpph4,weight4,procedure_no4,product_line4,product_time4,framework_no4,prod_workshop_no4,prod_team_no4,cpjh4,br4,prod_company4,
																		    cppm_no5,cpgg_ply5,cpgg_width5,cpgg_length5,quality_level5,cpgg_add5,cpph5,weight5,procedure_no5,product_line5,product_time5,framework_no5,prod_workshop_no5,prod_team_no5,cpjh5,br5,prod_company5,
									 									    cppm_no6,cpgg_ply6,cpgg_width6,cpgg_length6,quality_level6,cpgg_add6,cpph6,weight6,procedure_no6,product_line6,product_time6,framework_no6,prod_workshop_no6,prod_team_no6,cpjh6,br6,prod_company6,
																		    cppm_no7,cpgg_ply7,cpgg_width7,cpgg_length7,quality_level7,cpgg_add7,cpph7,weight7,procedure_no7,product_line7,product_time7,framework_no7,prod_workshop_no7,prod_team_no7,cpjh7,br7,prod_company7,
																		    cppm_no8,cpgg_ply8,cpgg_width8,cpgg_length8,quality_level8,cpgg_add8,cpph8,weight8,procedure_no8,product_line8,product_time8,framework_no8,prod_workshop_no8,prod_team_no8,cpjh8,br8,prod_company8,
																		    cppm_no9,cpgg_ply9,cpgg_width9,cpgg_length9,quality_level9,cpgg_add9,cpph9,weight9,procedure_no9,product_line9,product_time9,framework_no9,prod_workshop_no9,prod_team_no9,cpjh9,br9,prod_company9,
																		    cppm_no10,cpgg_ply10,cpgg_width10,cpgg_length10,quality_level10,cpgg_add10,cpph10,weight10,procedure_no10,product_line10,product_time10,framework_no10,prod_workshop_no10,prod_team_no10,cpjh10,br10,prod_company10,	
																		    cppm_no11,cpgg_ply11,cpgg_width11,cpgg_length11,quality_level11,cpgg_add11,cpph11,weight11,procedure_no11,product_line11,product_time11,framework_no11,prod_workshop_no11,prod_team_no11,cpjh11,br11,prod_company11,	
																		    cppm_no12,cpgg_ply12,cpgg_width12,cpgg_length12,quality_level12,cpgg_add12,cpph12,weight12,procedure_no12,product_line12,product_time12,framework_no12,prod_workshop_no12,prod_team_no12,cpjh12,br12,prod_company12,	
																		    cppm_no13,cpgg_ply13,cpgg_width13,cpgg_length13,quality_level13,cpgg_add13,cpph13,weight13,procedure_no13,product_line13,product_time13,framework_no13,prod_workshop_no13,prod_team_no13,cpjh13,br13,prod_company13,	
																		    cppm_no14,cpgg_ply14,cpgg_width14,cpgg_length14,quality_level14,cpgg_add14,cpph14,weight14,procedure_no14,product_line14,product_time14,framework_no14,prod_workshop_no14,prod_team_no14,cpjh14,br14,prod_company14,	
																		    cppm_no15,cpgg_ply15,cpgg_width15,cpgg_length15,quality_level15,cpgg_add15,cpph15,weight15,procedure_no15,product_line15,product_time15,framework_no15,prod_workshop_no15,prod_team_no15,cpjh15,br15,prod_company15,	
																		    cppm_no20,cpgg_ply20,cpgg_width20,cpgg_length20,quality_level20,cpgg_add20,cpph20,weight20,procedure_no20,product_line20,product_time20,framework_no20,prod_workshop_no20,prod_team_no20,cpjh20,br20,prod_company20,        --记录原料信息
																		    hz_month,create_datetime)
																			
																	values( @cppm_no1, @cpgg_ply1, @cpgg_width1,@cpgg_length1,@quality_level1,@cpgg_add1,@cpph1,@weight1, @procedure_no1,@product_line1,@product_time1, @framework_no1, @prod_workshop_no1,@prod_team_no1,	@cpjh1,  @br1, 	@prod_company1,		
																		@cppm_no2, @cpgg_ply2, @cpgg_width2,@cpgg_length2,@quality_level2,@cpgg_add2,@cpph2,@weight2, @procedure_no2,@product_line2,@product_time2, @framework_no2, @prod_workshop_no2,@prod_team_no2,	@cpjh2,  @br2, 	@prod_company2,	
																		@cppm_no3, @cpgg_ply3, @cpgg_width3,@cpgg_length3,@quality_level3,@cpgg_add3,@cpph3,@weight3, @procedure_no3,@product_line3,@product_time3, @framework_no3, @prod_workshop_no3,@prod_team_no3,	@cpjh3,  @br3, 	@prod_company3,	
																		@cppm_no4, @cpgg_ply4, @cpgg_width4,@cpgg_length4,@quality_level4,@cpgg_add4,@cpph4,@weight4, @procedure_no4,@product_line4,@product_time4, @framework_no4, @prod_workshop_no4,@prod_team_no4,	@cpjh4,  @br4, 	@prod_company4,	
																		@cppm_no5, @cpgg_ply5, @cpgg_width5,@cpgg_length5,@quality_level5,@cpgg_add5,@cpph5,@weight5, @procedure_no5,@product_line5,@product_time5, @framework_no5, @prod_workshop_no5,@prod_team_no5,	@cpjh5,  @br5, 	@prod_company5,	
																		@cppm_no6, @cpgg_ply6, @cpgg_width6,@cpgg_length6,@quality_level6,@cpgg_add6,@cpph6,@weight6, @procedure_no6,@product_line6,@product_time6, @framework_no6, @prod_workshop_no6,@prod_team_no6,	@cpjh6,  @br6, 	@prod_company6,	
																		@cppm_no7, @cpgg_ply7, @cpgg_width7,@cpgg_length7,@quality_level7,@cpgg_add7,@cpph7,@weight7, @procedure_no7,@product_line7,@product_time7, @framework_no7, @prod_workshop_no7,@prod_team_no7,	@cpjh7,  @br7, 	@prod_company7,	
																		@cppm_no8, @cpgg_ply8, @cpgg_width8,@cpgg_length8,@quality_level8,@cpgg_add8,@cpph8,@weight8, @procedure_no8,@product_line8,@product_time8, @framework_no8, @prod_workshop_no8,@prod_team_no8,	@cpjh8,  @br8, 	@prod_company8,	
																		@cppm_no9, @cpgg_ply9, @cpgg_width9,@cpgg_length9,@quality_level9,@cpgg_add9,@cpph9,@weight9, @procedure_no9,@product_line9,@product_time9, @framework_no9, @prod_workshop_no9,@prod_team_no9,	@cpjh9,  @br9, 	@prod_company9,	
																		@cppm_no10,@cpgg_ply10,@cpgg_width10,@cpgg_length10,@quality_level10,@cpgg_add10,@cpph10,@weight10,@procedure_no10,@product_line10,@product_time10,@framework_no10,@prod_workshop_no10,@prod_team_no10,@cpjh10,@br10,@prod_company10,	
																		@cppm_no11,@cpgg_ply11,@cpgg_width11,@cpgg_length11,@quality_level11,@cpgg_add11,@cpph11,@weight11,@procedure_no11,@product_line11,@product_time11,@framework_no11,@prod_workshop_no11,@prod_team_no11,@cpjh11,@br11,@prod_company11,	
																		@cppm_no12,@cpgg_ply12,@cpgg_width12,@cpgg_length12,@quality_level12,@cpgg_add12,@cpph12,@weight12,@procedure_no12,@product_line12,@product_time12,@framework_no12,@prod_workshop_no12,@prod_team_no12,@cpjh12,@br12,@prod_company12,	
																		@cppm_no13,@cpgg_ply13,@cpgg_width13,@cpgg_length13,@quality_level13,@cpgg_add13,@cpph13,@weight13,@procedure_no13,@product_line13,@product_time13,@framework_no13,@prod_workshop_no13,@prod_team_no13,@cpjh13,@br13,@prod_company13,
																		@cppm_no14,@cpgg_ply14,@cpgg_width14,@cpgg_length14,@quality_level14,@cpgg_add14,@cpph14,@weight14,@procedure_no14,@product_line14,@product_time14,@framework_no14,@prod_workshop_no14,@prod_team_no14,@cpjh14,@br14,@prod_company14,
																		@cppm_no15,@cpgg_ply15,@cpgg_width15,@cpgg_length15,@quality_level15,@cpgg_add15,@cpph15,@weight15,@procedure_no15,@product_line15,@product_time15,@framework_no15,@prod_workshop_no15,@prod_team_no15,@cpjh15,@br15,@prod_company15,
																		@cppm_no15,@cpgg_ply15,@cpgg_width15,@cpgg_length15,@quality_level15,@cpgg_add15,@cpph15,@weight15,@procedure_no15,@product_line15,@product_time15,@framework_no15,@prod_workshop_no15,@prod_team_no15,@cpjh15,@br15,@prod_company15,--记录原料信息			
																		@hz_month,getdate()
																		)
																FETCH NEXT FROM KC_TBCPKCHZS_C15 INTO 	@cppm_no15, @cpgg_ply15, @cpgg_width15, @cpgg_length15,@quality_level15, @cpgg_add15, @cpph15,@weight15, @procedure_no15, @product_line15,@product_time15, @framework_no15,@prod_workshop_no15, @prod_team_no15,@cpjh15,  @br15, @prod_company15,@source_product_code15,@pre_db_company_no15
														
															END
															CLOSE KC_TBCPKCHZS_C15
															DEALLOCATE KC_TBCPKCHZS_C15
															/*-------------KC_TBCPKCHZS_C15-----------------end-------------------------*/
															FETCH NEXT FROM KC_TBCPKCHZS_C14 INTO 	@cppm_no14, @cpgg_ply14, @cpgg_width14, @cpgg_length14,@quality_level14, @cpgg_add14, @cpph14,@weight14, @procedure_no14, @product_line14,@product_time14, @framework_no14,@prod_workshop_no14, @prod_team_no14,@cpjh14,  @br14, @prod_company14,@source_product_code14,@pre_db_company_no14
													
														END
														CLOSE KC_TBCPKCHZS_C14
														DEALLOCATE KC_TBCPKCHZS_C14
														/*-------------KC_TBCPKCHZS_C14-----------------end-------------------------*/
														FETCH NEXT FROM KC_TBCPKCHZS_C13 INTO 	@cppm_no13, @cpgg_ply13, @cpgg_width13, @cpgg_length13,@quality_level13, @cpgg_add13, @cpph13,@weight13, @procedure_no13, @product_line13,@product_time13, @framework_no13,@prod_workshop_no13, @prod_team_no13,@cpjh13,  @br13, @prod_company13,@source_product_code13,@pre_db_company_no13
												
													END
													CLOSE KC_TBCPKCHZS_C13
													DEALLOCATE KC_TBCPKCHZS_C13
													/*-------------KC_TBCPKCHZS_C13-----------------end-------------------------*/
													FETCH NEXT FROM KC_TBCPKCHZS_C12 INTO 	@cppm_no12, @cpgg_ply12, @cpgg_width12, @cpgg_length12,@quality_level12, @cpgg_add12, @cpph12,@weight12, @procedure_no12, @product_line12,@product_time12, @framework_no12,@prod_workshop_no12, @prod_team_no12,@cpjh12,  @br12, @prod_company12,@source_product_code12,@pre_db_company_no12
											
												END
												CLOSE KC_TBCPKCHZS_C12
												DEALLOCATE KC_TBCPKCHZS_C12
												/*-------------KC_TBCPKCHZS_C12-----------------end-------------------------*/
												FETCH NEXT FROM KC_TBCPKCHZS_C11 INTO 	@cppm_no11, @cpgg_ply11, @cpgg_width11, @cpgg_length11,@quality_level11, @cpgg_add11, @cpph11,@weight11, @procedure_no11, @product_line11,@product_time11, @framework_no11,@prod_workshop_no11, @prod_team_no11,@cpjh11,  @br11, @prod_company11,@source_product_code11,@pre_db_company_no11
										
											END
											CLOSE KC_TBCPKCHZS_C11
											DEALLOCATE KC_TBCPKCHZS_C11
											/*-------------KC_TBCPKCHZS_C11-----------------end-------------------------*/
											FETCH NEXT FROM KC_TBCPKCHZS_C10 INTO 	@cppm_no10, @cpgg_ply10, @cpgg_width10, @cpgg_length10,@quality_level10, @cpgg_add10, @cpph10,@weight10, @procedure_no10, @product_line10,@product_time10, @framework_no10,@prod_workshop_no10, @prod_team_no10,@cpjh10,  @br10, @prod_company10,@source_product_code10,@pre_db_company_no10
									
										END
										CLOSE KC_TBCPKCHZS_C10
										DEALLOCATE KC_TBCPKCHZS_C10
										/*-------------KC_TBCPKCHZS_C10-----------------end-------------------------*/
										FETCH NEXT FROM KC_TBCPKCHZS_C9 INTO 	@cppm_no9, @cpgg_ply9, @cpgg_width9, @cpgg_length9,@quality_level9, @cpgg_add9, @cpph9,@weight9, @procedure_no9, @product_line9,@product_time9, @framework_no9,@prod_workshop_no9, @prod_team_no9,@cpjh9,  @br9, @prod_company9,@source_product_code9,@pre_db_company_no9
								
									END
									CLOSE KC_TBCPKCHZS_C9
									DEALLOCATE KC_TBCPKCHZS_C9
									/*-------------KC_TBCPKCHZS_C9-----------------end-------------------------*/
									FETCH NEXT FROM KC_TBCPKCHZS_C8 INTO 	@cppm_no8, @cpgg_ply8, @cpgg_width8, @cpgg_length8,@quality_level8, @cpgg_add8, @cpph8,@weight8, @procedure_no8, @product_line8,@product_time8, @framework_no8,@prod_workshop_no8, @prod_team_no8,@cpjh8,  @br8, @prod_company8,@source_product_code8,@pre_db_company_no8
							
								END
								CLOSE KC_TBCPKCHZS_C8
								DEALLOCATE KC_TBCPKCHZS_C8
								/*-------------KC_TBCPKCHZS_C8-----------------end-------------------------*/
								FETCH NEXT FROM KC_TBCPKCHZS_C7 INTO 	@cppm_no7, @cpgg_ply7, @cpgg_width7, @cpgg_length7,@quality_level7, @cpgg_add7, @cpph7,@weight7, @procedure_no7, @product_line7,@product_time7, @framework_no7,@prod_workshop_no7, @prod_team_no7,@cpjh7,  @br7, @prod_company7,@source_product_code7,@pre_db_company_no7
						
							END
							CLOSE KC_TBCPKCHZS_C7
							DEALLOCATE KC_TBCPKCHZS_C7
							/*-------------KC_TBCPKCHZS_C7-----------------end-------------------------*/
							FETCH NEXT FROM KC_TBCPKCHZS_C6 INTO 	@cppm_no6, @cpgg_ply6, @cpgg_width6, @cpgg_length6,@quality_level6, @cpgg_add6, @cpph6,@weight6, @procedure_no6, @product_line6,@product_time6, @framework_no6,@prod_workshop_no6, @prod_team_no6,@cpjh6,  @br6, @prod_company6,@source_product_code6,@pre_db_company_no6
					
						END
						CLOSE KC_TBCPKCHZS_C6
						DEALLOCATE KC_TBCPKCHZS_C6
						/*-------------KC_TBCPKCHZS_C6-----------------end-------------------------*/
						FETCH NEXT FROM KC_TBCPKCHZS_C5 INTO 	@cppm_no5, @cpgg_ply5, @cpgg_width5, @cpgg_length5,@quality_level5, @cpgg_add5, @cpph5,@weight5, @procedure_no5, @product_line5,@product_time5, @framework_no5,@prod_workshop_no5, @prod_team_no5,@cpjh5,  @br5, @prod_company5,@source_product_code5,@pre_db_company_no5
					END
					CLOSE KC_TBCPKCHZS_C5
					DEALLOCATE KC_TBCPKCHZS_C5
					/*-------------KC_TBCPKCHZS_C5-----------------end-------------------------*/
					FETCH NEXT FROM KC_TBCPKCHZS_C4 INTO 	@cppm_no4, @cpgg_ply4, @cpgg_width4, @cpgg_length4,@quality_level4, @cpgg_add4, @cpph4,@weight4, @procedure_no4, @product_line4,@product_time4, @framework_no4,@prod_workshop_no4, @prod_team_no4,@cpjh4,  @br4, @prod_company4,@source_product_code4,@pre_db_company_no4
			
				END
				CLOSE KC_TBCPKCHZS_C4
				DEALLOCATE KC_TBCPKCHZS_C4
				/*-------------KC_TBCPKCHZS_C4-----------------end-------------------------*/	

				FETCH NEXT FROM KC_TBCPKCHZS_C3 INTO 	@cppm_no3, @cpgg_ply3, @cpgg_width3, @cpgg_length3,@quality_level3, @cpgg_add3, @cpph3,@weight3, @procedure_no3, @product_line3,@product_time3, @framework_no3,@prod_workshop_no3, @prod_team_no3,@cpjh3,  @br3, @prod_company3,@source_product_code3,@pre_db_company_no3
		
			END
			CLOSE KC_TBCPKCHZS_C3
			DEALLOCATE KC_TBCPKCHZS_C3
			/*-------------KC_TBCPKCHZS_C3-----------------end-------------------------*/

		FETCH NEXT FROM KC_TBCPKCHZS_C2 INTO 	@cppm_no2, @cpgg_ply2, @cpgg_width2,@cpgg_length2,@quality_level2,@cpgg_add2,@cpph2,@weight2, @procedure_no2,@product_line2,@product_time2, @framework_no2, @prod_workshop_no2,@prod_team_no2,	@cpjh2,  @br2, 	@prod_company2,@source_product_code2,@pre_db_company_no2

	END
	CLOSE KC_TBCPKCHZS_C2
	DEALLOCATE KC_TBCPKCHZS_C2
	/*-------------KC_TBCPKCHZS_C2-----------------end-------------------------*/


--        insert into sc_tbcpjhqk (cppm_no1,cpgg_ply1,cpgg_width1,cpgg_length1,quality_level1,cpgg_add1,cpph1,weight1,procedure_no1,product_line1,	product_time1,framework_no1,prod_workshop_no1,prod_team_no1,cpjh1,br1,prod_company1,
-- 				cppm_no2,cpgg_ply2,cpgg_width2,cpgg_length2,quality_level2,cpgg_add2,cpph2,weight2,procedure_no2,product_line2,	product_time2,framework_no2,prod_workshop_no2,prod_team_no2,cpjh1,br1,prod_company2,
-- 				create_datetime)
-- 				
-- 		values(
-- 				@cppm_no1, @cpgg_ply1, @cpgg_width1,@cpgg_length1,@quality_level1,@cpgg_add1,@cpph1,@weight1, @procedure_no1,@product_line1,@product_time1, @framework_no1, @prod_workshop_no1,@prod_team_no1,	@cpjh1,  @br1, 	@prod_company1,		
-- 				@cppm_no2, @cpgg_ply2, @cpgg_width2,@cpgg_length2,@quality_level2,@cpgg_add2,@cpph2,@weight2, @procedure_no2,@product_line2,@product_time2, @framework_no2, @prod_workshop_no2,@prod_team_no2,	@cpjh2,  @br2, 	@prod_company2,	
-- 				getdate()
-- 			)



	FETCH NEXT FROM KC_TBCPKCHZS_C1 INTO 	@cppm_no1, @cpgg_ply1, @cpgg_width1,@cpgg_length1,@quality_level1,@cpgg_add1,@cpph1,@weight1, @procedure_no1,@product_line1,@product_time1, @framework_no1, @prod_workshop_no1,@prod_team_no1,	@cpjh1,  @br1, 	@prod_company1


END /* WHILE kc_tbcpkchzs_c1 END */

CLOSE KC_TBCPKCHZS_C1
DEALLOCATE KC_TBCPKCHZS_C1


/*
CLOSE KC_TBCPKCHZS_C10
DEALLOCATE KC_TBCPKCHZS_C10

CLOSE KC_TBCPKCHZS_C09
DEALLOCATE KC_TBCPKCHZS_C09

CLOSE KC_TBCPKCHZS_C08
DEALLOCATE KC_TBCPKCHZS_C08

CLOSE KC_TBCPKCHZS_C07
DEALLOCATE KC_TBCPKCHZS_C07

CLOSE KC_TBCPKCHZS_C06
DEALLOCATE KC_TBCPKCHZS_C06

CLOSE KC_TBCPKCHZS_C05
DEALLOCATE KC_TBCPKCHZS_C05

CLOSE KC_TBCPKCHZS_C04
DEALLOCATE KC_TBCPKCHZS_C04

CLOSE KC_TBCPKCHZS_C03
DEALLOCATE KC_TBCPKCHZS_C03

CLOSE KC_TBCPKCHZS_C02
DEALLOCATE KC_TBCPKCHZS_C02

CLOSE KC_TBCPKCHZS_C01
DEALLOCATE KC_TBCPKCHZS_C01
*/

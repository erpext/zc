



CREATE VIEW dbo.xs_vwxsckd_lines_2
AS
SELECT *
FROM dbo.xs_tbxsckd_lines
UNION
SELECT *
FROM dbo.xs_tbxsckd_lines_level2






CREATE VIEW dbo.kc_vwCpckd_lines_3
AS
SELECT *
FROM dbo.kc_tbCpckd_lines
UNION
SELECT *
FROM dbo.kc_tbCpckd_lines_level2
UNION
SELECT *
FROM dbo.kc_tbCpckd_lines_level3



CREATE VIEW dbo.xs_vwxsfhjsds_2
AS
SELECT *
FROM dbo.xs_tbxsfhjsds
UNION ALL
SELECT *
FROM dbo.xs_tbxsfhjsds_level2

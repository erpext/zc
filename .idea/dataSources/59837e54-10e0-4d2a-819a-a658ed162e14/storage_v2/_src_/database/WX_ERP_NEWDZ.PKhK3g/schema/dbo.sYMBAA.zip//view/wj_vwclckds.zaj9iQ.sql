

--view 修改
CREATE    VIEW dbo.wj_vwclckds
AS
SELECT dbo.wj_tbClckds.ll_date, dbo.wj_tbClckds.workshop_no, 
      dbo.wj_tbClckds.Company_id, dbo.wj_tbClckds.ll_type, dbo.wj_tbClckd_lines.cl_id, 
      dbo.wj_tbClckd_lines.cl_name, dbo.wj_tbClckd_lines.clsldw1_no, 
      dbo.wj_tbClckd_lines.clsldw2_no, dbo.wj_tbClckd_lines.cl_num1, 
      dbo.wj_tbClckd_lines.cl_num2, dbo.wj_tbClckd_lines.ckd_money, 
      dbo.wj_tbClckd_lines.txbl, dbo.wj_tbClckd_lines.unit_no, dbo.wj_tbClckd_lines.note, 
      dbo.wj_tbClckd_lines.rk_company_id, dbo.wj_tbClckds.Clckd_no, 
      dbo.wj_tbClckds.llr_name, dbo.wj_tbClckd_lines.create_datetime, 
      dbo.wj_tbClckd_lines.clckd_line_id, dbo.wj_tbClckd_lines.ckdd_no, 
      dbo.wj_clb.clfl1_name, dbo.wj_clb.clfl2_name, dbo.wj_clb.clfl3_name, 
      dbo.wj_clb.clfl4_name, dbo.wj_clb.clfl5_name, dbo.wj_clb.clfl6_name, 
      dbo.wj_clb.clfl7_name, dbo.wj_clb.clfl8_name, dbo.wj_clb.clfl9_name, 
      dbo.wj_clb.clfl_lvl, dbo.wj_clb.price, dbo.wj_tbClckds.sh_flag, dbo.wj_tbClckds.jbr, 
      dbo.wj_tbClckds.Create_user_no, dbo.wj_tbClckds.Create_datetime AS Expr1, 
      dbo.wj_tbClckds.clckd_id, dbo.wj_clb.clfl1_id, dbo.wj_clb.clfl2_id, dbo.wj_clb.clfl3_id, 
      dbo.wj_clb.clfl4_id, dbo.wj_clb.clfl5_id, dbo.wj_clb.clfl6_id, dbo.wj_clb.clfl7_id, 
      dbo.wj_clb.clfl8_id, dbo.wj_clb.clfl9_id, dbo.wj_tbClckds.shr, 
      dbo.wj_tbClckds.ll_unite_type,dbo.wj_tbClckds.hy_type,dbo.wj_tbClckds.cw_sh_flag		--sy耗用类型添加
FROM dbo.wj_tbClckds INNER JOIN
      dbo.wj_tbClckd_lines ON 
      dbo.wj_tbClckds.clckd_id = dbo.wj_tbClckd_lines.clckd_id INNER JOIN
      dbo.wj_clb ON dbo.wj_tbClckd_lines.cl_id = dbo.wj_clb.cl_id


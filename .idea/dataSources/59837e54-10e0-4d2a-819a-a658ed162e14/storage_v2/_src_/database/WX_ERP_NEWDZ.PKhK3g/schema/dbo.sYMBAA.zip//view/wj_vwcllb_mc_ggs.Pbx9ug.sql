CREATE VIEW dbo.wj_vwcllb_mc_ggs
AS
SELECT dbo.wj_tbCllbs.cllb_no, dbo.wj_tbCllbs.cllb_name, dbo.wj_tbClmcs.clmc_no, 
      dbo.wj_tbClmcs.clmc_name, dbo.wj_tbClggs.clgg_no, 
      dbo.wj_tbClggs.clgg_name
FROM dbo.wj_tbCllbs INNER JOIN
      dbo.wj_tbClmcs ON dbo.wj_tbCllbs.cllb_id = dbo.wj_tbClmcs.cllb_id INNER JOIN
      dbo.wj_tbClggs ON dbo.wj_tbClmcs.clmc_id = dbo.wj_tbClggs.clmc_id

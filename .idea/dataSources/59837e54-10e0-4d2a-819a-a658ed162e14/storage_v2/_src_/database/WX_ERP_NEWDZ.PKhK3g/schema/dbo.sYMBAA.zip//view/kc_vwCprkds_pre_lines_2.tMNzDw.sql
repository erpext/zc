
CREATE VIEW dbo.kc_vwCprkds_pre_lines_2
AS
SELECT *
FROM dbo.kc_tbCprkds_pre_lines
UNION
SELECT *
FROM dbo.kc_tbCprkds_pre_lines_level2


CREATE VIEW dbo.kc_vwcpkchzs
AS
SELECT cppm_no, cpgg, cpgg_ply_t, cpjh, sldw, weight, framework_no, ckdd, cpgg_ply, 
      cpgg_width, cpgg_length, cpgg_color, '' AS Expr1
FROM dbo.kc_tbCpkchzs

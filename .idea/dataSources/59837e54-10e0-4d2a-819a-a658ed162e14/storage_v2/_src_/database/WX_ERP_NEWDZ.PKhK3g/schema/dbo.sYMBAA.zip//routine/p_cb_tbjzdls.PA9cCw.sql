








--select * from  cb_tbjzdlhzs   
--delete from cb_tbjzdlhzs
--exec p_cb_tbjzdls '999','201709','0027','admin',1
CREATE           procedure p_cb_tbjzdls (@spid		int,
					@wk_yymm 	varchar(6),
					@line_no	varchar(4),
					@user_no	varchar(12),
					@backuplevel	int)
as
BEGIN
     
 declare @wk_yy		varchar(4),
	 @wk_mm		varchar(2),
	 @wk_last_yy	varchar(4),
 	 @wlmc_no1	varchar(4),
 	 @wlmc_no2	varchar(4),
 	 @wlmc_no3	varchar(4),
 	 @wlmc_name1	varchar(50),
 	 @wlmc_name2	varchar(50),
 	 @wlmc_name3	varchar(50),
 	 @weight	numeric(18,6),
 	 @weight_cl	numeric(18,6),	--产量
 	 @je		numeric(18,6),
	 @je_hj		numeric(18,6),
	 @dj		numeric(18,6),
	 @sql		varchar(6000),
	 @cpgg_width	numeric(18,8)
--set @wk_yymm = '201611'
--set @line_no = '0026'
set @wk_yy  	= substring(@wk_yymm,1,4)
set @wk_mm   	= cast(cast(substring(@wk_yymm,5,2) as int) as varchar(2))
set @wk_last_yy	= convert(varchar(04),dateadd(year,-1,@wk_yymm+'01'),112)

if @backuplevel = 1 
begin 
	insert into cb_tbjzdlhzs (wk_yymm,line_no,SOURCE_PRODUCT_NO,SOURCE_PRODUCT_PLY,SOURCE_PRODUCT_WIDTH,SOURCE_PRODUCT_SPEC,SOURCE_PRODUCT_LEVEL,SOURCE_PRODUCT_WEIGHT,CURRENT_PRODUCT_NO,
				  CURRENT_PRODUCT_PLY,CURRENT_PRODUCT_WIDTH,CURRENT_PRODUCT_SPEC,CURRENT_PRODUCT_LEVEL,CURRENT_PRODUCT_WEIGHT,PRODUCE_WEIGHT,product_source_weight,current_product_weight_a,
				  data_id ,company_id ,create_user_no ,create_datetime 
				  )
		  select @wk_yymm,
			 xbsc1005.product_line,
			 xbsc1006.source_product_no, 
		         xbsc1006.source_product_ply,   
		         xbsc1006.source_product_width,
		         xbsc1006.source_product_spec,
		         xbsc1006.source_product_level,   
		         sum(xbsc1006.source_product_weight) as source_product_weight,
			 xbsc1006.current_product_no,    
		         xbsc1006.current_product_ply,   
		         xbsc1006.current_product_width,   
		         xbsc1006.current_product_spec,   
		         xbsc1006.current_product_level,   
		         sum(case when xbsc1006.product_flag='1' then xbsc1006.current_product_weight else 0 end) as current_product_weight,
			 sum(case when xbsc1006.product_flag='1' then xbsc1006.produce_weight else xbsc1006.produce_weight-xbsc1006.current_product_weight end) as produce_weight,
			 sum(case when xbsc1006.product_flag='1' then xbsc1006.product_source_weight else xbsc1006.product_source_weight-xbsc1006.current_product_weight end) as product_source_weight,
			 sum(case when xbsc1006.product_flag='1' and current_product_level like 'a%' then xbsc1006.current_product_weight else 0 end) as current_product_weight_a,
			 0,0,@user_no,getdate()
		    from xbsc1005,   
		         xbsc1006  
		   where xbsc1005.id = xbsc1006.master_id
			 and convert(varchar(06),xbsc1006.create_datetime,112)=@wk_yymm
			 and (xbsc1006.product_adjust is null or xbsc1006.product_adjust <> '1') 
	                 and xbsc1005.product_line=@line_no
	
	        group by xbsc1005.product_line,
			 xbsc1006.source_product_no, 
		         xbsc1006.source_product_ply,   
		         xbsc1006.source_product_width,
		         xbsc1006.source_product_spec,   
		         xbsc1006.source_product_level,
		         xbsc1006.current_product_no,    
		         xbsc1006.current_product_ply,   
		         xbsc1006.current_product_width,   
		         xbsc1006.current_product_spec,  
		         xbsc1006.current_product_level
		    IF  @@ERROR <> 0 
		    BEGIN
		        RAISERROR('cb_tbjzdlhzs INSERT ERROR-1',16,-1)
			CLOSE HR_C1
			DEALLOCATE HR_C1
		        RETURN -1
		    END  
end

IF @backuplevel = 2 
BEGIN 
insert into cb_tbjzdlhzs (wk_yymm,line_no,SOURCE_PRODUCT_NO,SOURCE_PRODUCT_PLY,SOURCE_PRODUCT_WIDTH,SOURCE_PRODUCT_SPEC,SOURCE_PRODUCT_LEVEL,SOURCE_PRODUCT_WEIGHT,CURRENT_PRODUCT_NO,
				  CURRENT_PRODUCT_PLY,CURRENT_PRODUCT_WIDTH,CURRENT_PRODUCT_SPEC,CURRENT_PRODUCT_LEVEL,CURRENT_PRODUCT_WEIGHT,PRODUCE_WEIGHT,product_source_weight,current_product_weight_a
				)
		  select @wk_yymm,
			 vwxbsc1005_2.product_line,
			 vwxbsc1006_2.source_product_no, 
		         vwxbsc1006_2.source_product_ply,   
		         vwxbsc1006_2.source_product_width,
		         vwxbsc1006_2.source_product_spec,
		         vwxbsc1006_2.source_product_level,   
		         sum(vwxbsc1006_2.source_product_weight) as source_product_weight,
			 vwxbsc1006_2.current_product_no,    
		         vwxbsc1006_2.current_product_ply,   
		         vwxbsc1006_2.current_product_width,   
		         vwxbsc1006_2.current_product_spec,   
		         vwxbsc1006_2.current_product_level,   
		         sum(case when vwxbsc1006_2.product_flag='1' then vwxbsc1006_2.current_product_weight else 0 end) as current_product_weight,
			 sum(case when vwxbsc1006_2.product_flag='1' then vwxbsc1006_2.produce_weight else vwxbsc1006_2.produce_weight-vwxbsc1006_2.current_product_weight end) as produce_weight,
			 sum(case when vwxbsc1006_2.product_flag='1' then vwxbsc1006_2.product_source_weight else vwxbsc1006_2.product_source_weight-vwxbsc1006_2.current_product_weight end) as product_source_weight,
			 sum(case when vwxbsc1006_2.product_flag='1' and current_product_level like 'a%' then vwxbsc1006_2.current_product_weight else 0 end) as current_product_weight_a
		    from vwxbsc1005_2,   
		         vwxbsc1006_2  
		   where vwxbsc1005_2.id = vwxbsc1006_2.master_id
			 and convert(varchar(06),vwxbsc1006_2.create_datetime,112)=@wk_yymm
			 and (vwxbsc1006_2.product_adjust is null or vwxbsc1006_2.product_adjust <> '1') 
	                 and vwxbsc1005_2.product_line=@line_no
	
	        group by vwxbsc1005_2.product_line,
			 vwxbsc1006_2.source_product_no, 
		         vwxbsc1006_2.source_product_ply,   
		         vwxbsc1006_2.source_product_width,
		         vwxbsc1006_2.source_product_spec,   
		         vwxbsc1006_2.source_product_level,
		         vwxbsc1006_2.current_product_no,    
		         vwxbsc1006_2.current_product_ply,   
		         vwxbsc1006_2.current_product_width,   
		         vwxbsc1006_2.current_product_spec,  
		         vwxbsc1006_2.current_product_level
		    IF  @@ERROR <> 0 
		    BEGIN
		        RAISERROR('cb_tbjzdlhzs INSERT ERROR-2',16,-1)
			CLOSE HR_C1
			DEALLOCATE HR_C1
		        RETURN -1
		    END  
END

IF @backuplevel = 3 
BEGIN 
insert into cb_tbjzdlhzs (wk_yymm,line_no,SOURCE_PRODUCT_NO,SOURCE_PRODUCT_PLY,SOURCE_PRODUCT_WIDTH,SOURCE_PRODUCT_SPEC,SOURCE_PRODUCT_LEVEL,SOURCE_PRODUCT_WEIGHT,CURRENT_PRODUCT_NO,
				  CURRENT_PRODUCT_PLY,CURRENT_PRODUCT_WIDTH,CURRENT_PRODUCT_SPEC,CURRENT_PRODUCT_LEVEL,CURRENT_PRODUCT_WEIGHT,PRODUCE_WEIGHT,product_source_weight,current_product_weight_a
				)
		  select @wk_yymm,
			 vwxbsc1005_3.product_line,
			 vwxbsc1006_3.source_product_no, 
		         vwxbsc1006_3.source_product_ply,   
		         vwxbsc1006_3.source_product_width,
		         vwxbsc1006_3.source_product_spec,
		         vwxbsc1006_3.source_product_level,   
		         sum(vwxbsc1006_3.source_product_weight) as source_product_weight,
					vwxbsc1006_3.current_product_no,    
		         vwxbsc1006_3.current_product_ply,   
		         vwxbsc1006_3.current_product_width,   
		         vwxbsc1006_3.current_product_spec,   
		         vwxbsc1006_3.current_product_level,   
		         sum(case when vwxbsc1006_3.product_flag='1' then vwxbsc1006_3.current_product_weight else 0 end) as current_product_weight,
			 sum(case when vwxbsc1006_3.product_flag='1' then vwxbsc1006_3.produce_weight else vwxbsc1006_3.produce_weight-vwxbsc1006_3.current_product_weight end) as produce_weight,
			 sum(case when vwxbsc1006_3.product_flag='1' then vwxbsc1006_3.product_source_weight else vwxbsc1006_3.product_source_weight-vwxbsc1006_3.current_product_weight end) as product_source_weight,
			 sum(case when vwxbsc1006_3.product_flag='1' and current_product_level like 'a%' then vwxbsc1006_3.current_product_weight else 0 end) as current_product_weight_a
		    from vwxbsc1005_3,   
		         vwxbsc1006_3  
		   where vwxbsc1005_3.id = vwxbsc1006_3.master_id
			 and convert(varchar(06),vwxbsc1006_3.create_datetime,112)=@wk_yymm
			 and (vwxbsc1006_3.product_adjust is null or vwxbsc1006_3.product_adjust <> '1') 
	                 and vwxbsc1005_3.product_line=@line_no
	
	        group by vwxbsc1005_3.product_line,
			 vwxbsc1006_3.source_product_no, 
		         vwxbsc1006_3.source_product_ply,   
		         vwxbsc1006_3.source_product_width,
		         vwxbsc1006_3.source_product_spec,   
		         vwxbsc1006_3.source_product_level,
		         vwxbsc1006_3.current_product_no,    
		         vwxbsc1006_3.current_product_ply,   
		         vwxbsc1006_3.current_product_width,   
		         vwxbsc1006_3.current_product_spec,  
		         vwxbsc1006_3.current_product_level
		    IF  @@ERROR <> 0 --OR @@ROWCOUNT = 0
		    BEGIN
		        RAISERROR('cb_tbjzdlhzs INSERT ERROR-3',16,-1)
			CLOSE HR_C1
			DEALLOCATE HR_C1
		        RETURN -1
		    END  
END

select @cpgg_width = cpgg_width
  from cb_tbjzdls
 where line_no = @line_no
   and wk_yymm = @wk_yymm
IF  @@ERROR <> 0 OR @@ROWCOUNT = 0
BEGIN
	RAISERROR('%s生产线标准宽度未登记！',16,-1,@line_no)
	RETURN -1
END  

update cb_tbjzdlhzs
   set product_ply_chayi   = source_product_ply - current_product_ply ,
       product_ply_xishu   =(source_product_ply - current_product_ply)/ source_product_ply,
       product_width_xishu =(source_product_width / @cpgg_width),
       product_weight_xishu=((source_product_ply - current_product_ply)/ source_product_ply) * (source_product_width / @cpgg_width),
       current_product_weight_biaozhun = round(current_product_weight * ((source_product_ply - current_product_ply)/ source_product_ply) * (source_product_width / @cpgg_width),2),
       current_product_weight_kuandu   = round(current_product_weight * (source_product_width / @cpgg_width),2)
 where line_no = @line_no
   and wk_yymm = @wk_yymm



END





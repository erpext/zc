create VIEW dbo.iw_vwEmployee_functions
AS
SELECT dbo.iw_tbEmployees.employee_id, dbo.iw_tbEmployees.employee_no, 
      dbo.iw_tbEmployees.employee_name, dbo.iw_tbEmployees.dept_id, 
      dbo.iw_tbEmployees.company_id, dbo.iw_tbemployee_functions.job_hardware, 
      dbo.iw_tbemployee_functions.job_product, 
      dbo.iw_tbemployee_functions.job_material, dbo.iw_tbemployee_functions.job_sell, 
      dbo.iw_tbemployee_functions.job_stock, 
      dbo.iw_tbemployee_functions.job_hardware_stock, 
      dbo.iw_tbemployee_functions.job_check, dbo.iw_tbemployee_functions.note
FROM dbo.iw_tbEmployees INNER JOIN
      dbo.iw_tbemployee_functions ON 
      dbo.iw_tbEmployees.employee_id = dbo.iw_tbemployee_functions.employee_id

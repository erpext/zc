
create view ht_vwghs_yfzk
as 
select c.ghs_id as ghs_id,
       c.yfzk as yfzk,
       count( ab.ghs_id ) as flag0,
       0 as flag1,
       sum(ab.rkd_money) as rkd_money,
       0                 as rkfp_money,
       0 as sjfp_money
from (select b.* from wj_tbclrkds a join wj_tbclrkd_lines b on a.clrkd_id = b.clrkd_id and a.sh_flag = 1) as ab right outer join wj_tbghss c 
     on ab.ghs_id = c.ghs_id and ab.fp_flag = 0 
group by c.ghs_id,c.yfzk
union 
select c.ghs_id ghs_id,
       0 as yfzk,
       0 as flag0,
       count( ab.ghs_id ) as flag1,
       sum(ab.rkd_money)  as rkd_money,
       sum(ab.fp_money)      as rkfp_money,
       0 as sjfp_money
from (select b.* from wj_tbclrkds a join wj_tbclrkd_lines b on a.clrkd_id = b.clrkd_id and a.sh_flag = 1) as ab right outer join wj_tbghss c 
     on ab.ghs_id = c.ghs_id and ab.fp_flag = 1 
group by c.ghs_id,c.yfzk
union
select b.ghs_id as ghs_id,
       0 as yfzk,
       0 as flag0,
       0 as flag1,
       0 as rkd_money,
       0 as rkfp_money,
       sum(a.fp_money) as sjfp_money
from wj_clfp a right outer join wj_tbghss b on a.ghs_id = b.ghs_id
group by b.ghs_id



create view wj_vwclkchzs 
as
SELECT wj_vwclrkds_kchzs.company_id,   
         wj_vwclrkds_kchzs.ckdd_no,   
         wj_vwclrkds_kchzs.cl_id,   
         wj_vwclrkds_kchzs.hz_month,
         wj_vwclrkds_kchzs.sh_flag,
         sum(wj_vwclrkds_kchzs.kc_num) as kc_num,   
         sum(wj_vwclrkds_kchzs.kc_num2) as kc_num2,   
         sum(wj_vwclrkds_kchzs.kc_money) as kc_money,
         sum(wj_vwclrkds_kchzs.rejust_money) as rejust_money,
         sum(wj_vwclrkds_kchzs.bq_rknum) as bq_rknum,   
         sum(wj_vwclrkds_kchzs.bq_rkmoney) as bq_rkmoney,   
         sum(wj_vwclrkds_kchzs.bq_cknum) as bq_cknum,   
         sum(wj_vwclrkds_kchzs.bq_ckmoney) as bq_ckmoney,   
         sum(wj_vwclrkds_kchzs.sqkc_num) as sqkc_num,   
         sum(wj_vwclrkds_kchzs.sqkc_money) as sqkc_money,
         case sum(wj_vwclrkds_kchzs.kc_num) when 0 then 0 else (sum(wj_vwclrkds_kchzs.kc_money) + sum(wj_vwclrkds_kchzs.rejust_money)) /sum(wj_vwclrkds_kchzs.kc_num) end as kc_price
    FROM wj_vwclrkds_kchzs
   WHERE 1 = 1
GROUP BY wj_vwclrkds_kchzs.company_id,wj_vwclrkds_kchzs.ckdd_no,wj_vwclrkds_kchzs.hz_month,wj_vwclrkds_kchzs.cl_id,wj_vwclrkds_kchzs.sh_flag


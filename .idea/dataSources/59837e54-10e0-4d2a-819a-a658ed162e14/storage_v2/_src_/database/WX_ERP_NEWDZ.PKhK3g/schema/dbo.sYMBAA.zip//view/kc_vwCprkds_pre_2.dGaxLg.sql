
CREATE VIEW dbo.kc_vwCprkds_pre_2
AS
SELECT *
FROM dbo.kc_tbCprkds_pre
UNION
SELECT *
FROM dbo.kc_tbCprkds_pre_level2


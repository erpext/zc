
CREATE VIEW [dbo].[VWXBSC1015_Technology_Config]
AS
SELECT     STR(dbo.XBSC1015_Technology_Config.Procedure_Sort) + '_' + dbo.hr_tbworking_proceduer.working_proceduer_name AS proceduer_name, dbo.hr_tbworking_proceduer.working_proceduer_name, 
                      STR(dbo.XBSC1015_Technology_Config.Sort) + '' + dbo.XBSC1012_Parameter.Name AS name, dbo.XBSC1015_Technology_Config.ID, dbo.XBSC1015_Technology_Config.Config_No, 
                      dbo.XBSC1015_Technology_Config.Procedure_no, dbo.XBSC1015_Technology_Config.Procedure_Sort, dbo.XBSC1015_Technology_Config.Para_ID, 
                      dbo.XBSC1015_Technology_Config.Para_Default, dbo.XBSC1015_Technology_Config.Sort, dbo.XBSC1015_Technology_Config.Note, dbo.XBSC1015_Technology_Config.create_user_no, 
                      dbo.XBSC1015_Technology_Config.create_datetime, dbo.XBSC1015_Technology_Config.update_user_no, dbo.XBSC1015_Technology_Config.update_datetime
FROM         dbo.XBSC1015_Technology_Config INNER JOIN
                      dbo.XBSC1012_Parameter ON dbo.XBSC1015_Technology_Config.Para_ID = dbo.XBSC1012_Parameter.id INNER JOIN
                      dbo.hr_tbworking_proceduer ON dbo.XBSC1015_Technology_Config.Procedure_no = dbo.hr_tbworking_proceduer.working_proceduer_no



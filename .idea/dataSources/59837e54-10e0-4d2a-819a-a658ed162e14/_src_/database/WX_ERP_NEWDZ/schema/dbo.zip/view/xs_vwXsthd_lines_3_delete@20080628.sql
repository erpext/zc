

CREATE VIEW dbo.xs_vwXsthd_lines_3
AS
SELECT *
FROM dbo.xs_tbXsthd_lines
UNION ALL
SELECT *
FROM dbo.xs_tbXsthd_lines_level2
UNION ALL
SELECT *
FROM dbo.xs_tbXsthd_lines_level3





CREATE VIEW dbo.wj_vwclkchzs_month
AS
SELECT company_id, ckdd_no, cl_id, kc_num AS kc0, 0 AS kc1, 0 AS kc2, 0 AS kc3, 
      0 AS kc4, 0 AS kc5, 0 AS kc6, 0 AS kc7, 0 AS kc8, 0 AS kc9, 0 AS kc10, 0 AS kc11, 
      0 AS kc12
FROM wj_tbclkchzs
WHERE hz_month = ltrim(STR(DATEPART(YYYY, GETDATE()) - 1)) + '12'
UNION ALL
SELECT company_id, ckdd_no, cl_id, 0 AS kc0, kc_num AS kc1, 0 AS kc2, 0 AS kc3, 
      0 AS kc4, 0 AS kc5, 0 AS kc6, 0 AS kc7, 0 AS kc8, 0 AS kc9, 0 AS kc10, 0 AS kc11, 
      0 AS kc12
FROM wj_tbclkchzs
WHERE hz_month = ltrim(STR(DATEPART(YYYY, GETDATE()))) + '01'
UNION ALL
SELECT company_id, ckdd_no, cl_id, 0 AS kc0, 0 AS kc1, kc_num AS kc2, 0 AS kc3, 
      0 AS kc4, 0 AS kc5, 0 AS kc6, 0 AS kc7, 0 AS kc8, 0 AS kc9, 0 AS kc10, 0 AS kc11, 
      0 AS kc12
FROM wj_tbclkchzs
WHERE hz_month = ltrim(STR(DATEPART(YYYY, GETDATE()))) + '02'
UNION ALL
SELECT company_id, ckdd_no, cl_id, 0 AS kc0, 0 AS kc1, 0 AS kc2, kc_num AS kc3, 
      0 AS kc4, 0 AS kc5, 0 AS kc6, 0 AS kc7, 0 AS kc8, 0 AS kc9, 0 AS kc10, 0 AS kc11, 
      0 AS kc12
FROM wj_tbclkchzs
WHERE hz_month = ltrim(STR(DATEPART(YYYY, GETDATE()))) + '03'
UNION ALL
SELECT company_id, ckdd_no, cl_id, 0 AS kc0, 0 AS kc1, 0 AS kc2, 0 AS kc3, 
      kc_num AS kc4, 0 AS kc5, 0 AS kc6, 0 AS kc7, 0 AS kc8, 0 AS kc9, 0 AS kc10, 
      0 AS kc11, 0 AS kc12
FROM wj_tbclkchzs
WHERE hz_month = ltrim(STR(DATEPART(YYYY, GETDATE()))) + '04'
UNION ALL
SELECT company_id, ckdd_no, cl_id, 0 AS kc0, 0 AS kc1, 0 AS kc2, 0 AS kc3, 0 AS kc4, 
      kc_num AS kc5, 0 AS kc6, 0 AS kc7, 0 AS kc8, 0 AS kc9, 0 AS kc10, 0 AS kc11, 
      0 AS kc12
FROM wj_tbclkchzs
WHERE hz_month = ltrim(STR(DATEPART(YYYY, GETDATE()))) + '05'
UNION ALL
SELECT company_id, ckdd_no, cl_id, 0 AS kc0, 0 AS kc1, 0 AS kc2, 0 AS kc3, 0 AS kc4, 
      0 AS kc5, kc_num AS kc6, 0 AS kc7, 0 AS kc8, 0 AS kc9, 0 AS kc10, 0 AS kc11, 
      0 AS kc12
FROM wj_tbclkchzs
WHERE hz_month = ltrim(STR(DATEPART(YYYY, GETDATE()))) + '06'
UNION ALL
SELECT company_id, ckdd_no, cl_id, 0 AS kc0, 0 AS kc1, 0 AS kc2, 0 AS kc3, 0 AS kc4, 
      0 AS kc5, 0 AS kc6, kc_num AS kc7, 0 AS kc8, 0 AS kc9, 0 AS kc10, 0 AS kc11, 
      0 AS kc12
FROM wj_tbclkchzs
WHERE hz_month = ltrim(STR(DATEPART(YYYY, GETDATE()))) + '07'
UNION ALL
SELECT company_id, ckdd_no, cl_id, 0 AS kc0, 0 AS kc1, 0 AS kc2, 0 AS kc3, 0 AS kc4, 
      0 AS kc5, 0 AS kc6, 0 AS kc7, kc_num AS kc8, 0 AS kc9, 0 AS kc10, 0 AS kc11, 
      0 AS kc12
FROM wj_tbclkchzs
WHERE hz_month = ltrim(STR(DATEPART(YYYY, GETDATE()))) + '08'
UNION ALL
SELECT company_id, ckdd_no, cl_id, 0 AS kc0, 0 AS kc1, 0 AS kc2, 0 AS kc3, 0 AS kc4, 
      0 AS kc5, 0 AS kc6, 0 AS kc7, 0 AS kc8, kc_num AS kc9, 0 AS kc10, 0 AS kc11, 
      0 AS kc12
FROM wj_tbclkchzs
WHERE hz_month = ltrim(STR(DATEPART(YYYY, GETDATE()))) + '09'
UNION ALL
SELECT company_id, ckdd_no, cl_id, 0 AS kc0, 0 AS kc1, 0 AS kc2, 0 AS kc3, 0 AS kc4, 
      0 AS kc5, 0 AS kc6, 0 AS kc7, 0 AS kc8, 0 AS kc9, kc_num AS kc10, 0 AS kc11, 
      0 AS kc12
FROM wj_tbclkchzs
WHERE hz_month = ltrim(STR(DATEPART(YYYY, GETDATE()))) + '10'
UNION ALL
SELECT company_id, ckdd_no, cl_id, 0 AS kc0, 0 AS kc1, 0 AS kc2, 0 AS kc3, 0 AS kc4, 
      0 AS kc5, 0 AS kc6, 0 AS kc7, 0 AS kc8, 0 AS kc9, 0 AS kc10, kc_num AS kc11, 
      0 AS kc12
FROM wj_tbclkchzs
WHERE hz_month = ltrim(STR(DATEPART(YYYY, GETDATE()))) + '11'
UNION ALL
SELECT company_id, ckdd_no, cl_id, 0 AS kc0, 0 AS kc1, 0 AS kc2, 0 AS kc3, 0 AS kc4, 
      0 AS kc5, 0 AS kc6, 0 AS kc7, 0 AS kc8, 0 AS kc9, 0 AS kc10, 0 AS kc11, 
      kc_num AS kc12
FROM wj_tbclkchzs
WHERE hz_month = ltrim(STR(DATEPART(YYYY, GETDATE()))) + '12'



CREATE VIEW kc_vwCpckd_lines_3 AS SELECT * FROM kc_tbcpckd_lines UNION SELECT * FROM kc_tbCpckd_lines_level2 UNION SELECT * FROM kc_tbCpckd_lines_level3

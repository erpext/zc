
CREATE VIEW dbo.kc_vwCprkds_pre_lines_3
AS
SELECT *
FROM dbo.kc_tbCprkds_pre_lines
UNION
SELECT *
FROM dbo.kc_tbCprkds_pre_lines_level2
UNION
SELECT *
FROM dbo.kc_tbCprkds_pre_lines_level3



create view wj_vwclrkds_kchzs
as
select ab.company_id,
       ab.ckdd_no,
       ab.cl_id,
       ab.hz_month,
       sum(ab.kc_num) kc_num,
       sum(ab.kc_num2) kc_num2,
       sum(ab.kc_money) kc_money,
       sum(ab.rejust_money) rejust_money,
       avg(ab.kc_price) kc_price,
       0 as sh_flag,
       sum(ab.bq_rknum)   as bq_rknum,
       sum(ab.bq_rknum2)  as bq_rknum2,
       sum(ab.bq_rkmoney) as bq_rkmoney,
       sum(ab.bq_cknum)   as bq_cknum,
       sum(ab.bq_cknum2)  as bq_cknum2,
       sum(ab.bq_ckmoney) as bq_ckmoney,
       0 as sqkc_num, 0 as sqkc_num2,0 as sqkc_money
from (
select b.company_id , 
       b.ckdd_no , 
       b.cl_id ,
       substring(convert(char(10),dj_date,101),7,4) + 
       substring(convert(char(10),dj_date,101),1,2) hz_month,
       sum(fkd_synum) kc_num , 
       sum(fkd_synum2) kc_num2 , 
       sum(rkd_money) kc_money ,
       case sum(fkd_synum) when 0 then 0 else sum(rkd_money) / sum(fkd_synum) end as kc_price,
       0 as rejust_money,
       sum(fkd_synum) as bq_rknum,
       sum(fkd_synum2) as bq_rknum2,
       sum(rkd_money) as bq_rkmoney,
       0 as bq_cknum,
       0 as bq_cknum2,
       0 as bq_ckmoney
from wj_tbclrkds a , wj_tbclrkd_lines b 
where a.clrkd_id = b.clrkd_id and a.sh_flag = 0
group by b.company_id , b.ckdd_no , b.cl_id,substring(convert(char(10),dj_date,101),7,4) + substring(convert(char(10),dj_date,101),1,2)
union all
select b.rk_company_id company_id, 
       b.ckdd_no , 
       b.cl_id ,
       substring(convert(char(10),ll_date,101),7,4) + 
       substring(convert(char(10),ll_date,101),1,2) hz_month,
       0 - sum(cl_num1) kc_num  , 
       0 - sum(cl_num2) kc_num2 , 
       0 - sum(ckd_money) kc_money ,
       0 as kc_price,
       0 as rejust_money,
       0 as bq_rknum,
       0 as bq_rknum2,
       0 as bq_rkmoney,
       sum(cl_num1) as bq_cknum,
       sum(cl_num2) as bq_cknum2,
       sum(ckd_money) as bq_ckmoney
from wj_tbclckds a , wj_tbclckd_lines b 
where a.clckd_id = b.clckd_id and a.sh_flag = 0
group by b.rk_company_id , b.ckdd_no , b.cl_id,substring(convert(char(10),ll_date,101),7,4) + substring(convert(char(10),ll_date,101),1,2)
) as ab
group by ab.company_id,ab.ckdd_no,ab.cl_id,ab.hz_month
union all
select company_id , ckdd_no , cl_id , hz_month , kc_num ,kc_num2 ,kc_money , rejust_money ,
case kc_num when 0 then 0 else (kc_money + rejust_money) / kc_num end as kc_price,
1 as sh_flag,
bq_rknum,bq_rknum2,bq_rkmoney,
bq_cknum,bq_cknum2,bq_ckmoney,
sqkc_num,sqkc_num2,sqkc_money 
from  wj_tbclkchzs


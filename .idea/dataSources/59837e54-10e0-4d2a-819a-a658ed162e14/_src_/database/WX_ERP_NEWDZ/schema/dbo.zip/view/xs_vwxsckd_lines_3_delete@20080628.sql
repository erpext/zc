

CREATE VIEW dbo.xs_vwxsckd_lines_3
AS
SELECT *
FROM dbo.xs_tbxsckd_lines
UNION ALL
SELECT *
FROM dbo.xs_tbxsckd_lines_level2
UNION ALL
SELECT *
FROM dbo.xs_tbxsckd_lines_level3



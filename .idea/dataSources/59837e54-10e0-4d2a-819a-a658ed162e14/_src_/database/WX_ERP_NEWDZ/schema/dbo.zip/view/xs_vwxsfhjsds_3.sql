
CREATE VIEW dbo.xs_vwxsfhjsds_3
AS
SELECT *
FROM dbo.xs_tbxsfhjsds
UNION ALL
SELECT *
FROM dbo.xs_tbxsfhjsds_level2
UNION ALL
SELECT *
FROM dbo.xs_tbxsfhjsds_level3


CREATE VIEW dbo.xs_vwXsthds_3
AS
SELECT *
FROM dbo.xs_tbXsthds
UNION ALL
SELECT *
FROM dbo.xs_tbXsthds_level2
UNION ALL
SELECT *
FROM dbo.xs_tbXsthds_level3

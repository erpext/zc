
CREATE VIEW dbo.kc_vwCpckds_2
AS
SELECT *
FROM dbo.kc_tbCpckds
UNION
SELECT *
FROM dbo.kc_tbCpckds_level2




CREATE VIEW dbo.wk_vwhzkc_company
AS
SELECT DISTINCT 
      hz.cl_name, dbo.wj_clb.cl_id, dbo.wj_clb.clfl_lvl, SUM(hz.kc_num) AS kc_num, 
      SUM(hz.kc_num2) AS kc_num2, SUM(hz.bq_cknum) AS bq_cknum, hz.hz_month, 
      hz.company_id, dbo.wj_clb.clfl1_id, dbo.wj_clb.clfl1_name, dbo.wj_clb.clfl2_id, 
      dbo.wj_clb.clfl2_name, dbo.wj_clb.clfl3_id, dbo.wj_clb.clfl3_name, dbo.wj_clb.clfl4_id, 
      dbo.wj_clb.clfl4_name, dbo.wj_clb.clfl5_id, dbo.wj_clb.clfl5_name, dbo.wj_clb.clfl6_id, 
      dbo.wj_clb.clfl6_name, dbo.wj_clb.clfl7_id, dbo.wj_clb.clfl7_name, dbo.wj_clb.clfl8_id, 
      dbo.wj_clb.clfl8_name, dbo.wj_clb.clfl9_id, dbo.wj_clb.clfl9_name, 
      dbo.wj_clb.clsldw1_no, dbo.wj_clb.clsldw2_no
FROM dbo.wj_tbClkchzs hz INNER JOIN
      dbo.wj_clb ON hz.cl_id = dbo.wj_clb.cl_id
GROUP BY hz.cl_name, dbo.wj_clb.cl_id, dbo.wj_clb.clfl_lvl, hz.hz_month, hz.company_id, 
      dbo.wj_clb.clfl1_name, dbo.wj_clb.clfl2_name, dbo.wj_clb.clfl3_name, 
      dbo.wj_clb.clfl4_name, dbo.wj_clb.clfl5_name, dbo.wj_clb.clfl6_name, 
      dbo.wj_clb.clfl7_name, dbo.wj_clb.clfl8_name, dbo.wj_clb.clfl9_name, 
      dbo.wj_clb.clsldw1_no, dbo.wj_clb.clsldw2_no, dbo.wj_clb.clfl1_id, 
      dbo.wj_clb.clfl2_id, dbo.wj_clb.clfl3_id, dbo.wj_clb.clfl4_id, dbo.wj_clb.clfl5_id, 
      dbo.wj_clb.clfl6_id, dbo.wj_clb.clfl7_id, dbo.wj_clb.clfl8_id, dbo.wj_clb.clfl9_id



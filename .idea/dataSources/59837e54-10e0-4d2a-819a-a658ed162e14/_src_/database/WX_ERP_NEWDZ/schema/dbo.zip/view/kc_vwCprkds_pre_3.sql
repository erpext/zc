
CREATE VIEW dbo.kc_vwCprkds_pre_3
AS
SELECT *
FROM dbo.kc_tbCprkds_pre
UNION
SELECT *
FROM dbo.kc_tbCprkds_pre_level2
UNION
SELECT *
FROM dbo.kc_tbCprkds_pre_level3


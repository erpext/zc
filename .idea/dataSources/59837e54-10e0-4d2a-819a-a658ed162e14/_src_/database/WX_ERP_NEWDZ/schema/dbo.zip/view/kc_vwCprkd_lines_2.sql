CREATE VIEW kc_vwCprkd_lines_2 AS SELECT * FROM kc_tbCprkd_lines UNION SELECT * FROM kc_tbCprkd_lines_level2

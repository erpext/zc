CREATE VIEW dbo.sc_vproduce_datas
AS
SELECT dbo.sc_tbproduce_datas.framework_no, dbo.sc_tbproduce_datas.workshop, 
      dbo.sc_tbproduce_datas.team_no, dbo.sc_tbproduce_data_lines.wrap_flag, 
      dbo.sc_tbproduce_data_lines.wrap, dbo.sc_tbproduce_data_lines.spec, 
      dbo.sc_tbproduce_data_lines.weight, dbo.sc_tbproduce_data_lines.rigidity, 
      dbo.sc_tbproduce_data_lines.quality_data, dbo.sc_tbproduce_data_lines.note, 
      dbo.sc_tbproduce_data_lines.produce_data_line_id, 
      dbo.sc_tbproduce_data_lines.produce_data_id, 
      dbo.sc_tbproduce_data_lines.ylghdw_no, dbo.sc_tbproduce_data_lines.spec_ply, 
      dbo.sc_tbproduce_data_lines.spec_width, dbo.sc_tbproduce_data_lines.spec_length, 
      dbo.sc_tbproduce_data_lines.pre_flag_id, dbo.sc_tbproduce_data_lines.flag_id, 
      dbo.sc_tbproduce_datas.produce_data_no, 
      dbo.sc_tbproduce_datas.produce_data_id AS Expr1, 
      dbo.sc_tbproduce_datas.team_manager, 
      dbo.sc_tbproduce_datas.produce_datetime_b, 
      dbo.sc_tbproduce_datas.produce_datetime_e, 
      dbo.sc_tbproduce_datas.enrol_datetime, dbo.sc_tbproduce_datas.enrol_man, 
      dbo.sc_tbproduce_datas.note AS Expr2, dbo.sc_tbproduce_data_lines.pre_wrap, 
      dbo.sc_tbproduce_data_lines.pre_procedure_no, 
      dbo.sc_tbproduce_data_lines.pre_workshop_no, 
      dbo.sc_tbproduce_data_lines.pre_spec, dbo.sc_tbproduce_data_lines.trademark, 
      dbo.sc_tbproduce_data_lines.pre_flag, dbo.sc_tbproduce_data_lines.pre_weight, 
      dbo.sc_tbproduce_data_lines.ll_method, dbo.sc_tbproduce_data_lines.quality_level, 
      dbo.sc_tbproduce_data_lines.spec_color, dbo.sc_tbproduce_data_lines.finish_flag, 
      dbo.sc_tbproduce_data_lines.sldw, dbo.sc_tbproduce_data_lines.tbYlkchzs_id, 
      dbo.sc_tbproduce_data_lines.ylrkd_line_id, 
      dbo.sc_tbproduce_data_lines.quality_flag
FROM dbo.sc_tbproduce_datas INNER JOIN
      dbo.sc_tbproduce_data_lines ON 
      dbo.sc_tbproduce_datas.produce_data_id = dbo.sc_tbproduce_data_lines.produce_data_id

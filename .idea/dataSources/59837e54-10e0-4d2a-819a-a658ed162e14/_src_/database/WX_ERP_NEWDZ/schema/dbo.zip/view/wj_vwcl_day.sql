


CREATE VIEW dbo.wj_vwcl_day
AS
SELECT t .cl_id, t .diff, CASE WHEN diff > 90 AND 
      diff <= 180 THEN 'A：90天以上' WHEN diff > 180 AND 
      diff <= 270 THEN 'B：180天以上' WHEN diff > 270 AND 
      diff <= 365 THEN 'C：270天以上' ELSE 'D：365天以上' END AS difftype
FROM (SELECT wj_tbClckd_lines.cl_id, MIN(datediff(day, create_datetime, getdate())) 
              AS diff
        FROM wj_tbClckd_lines
        WHERE wj_tbClckd_lines.cl_num1 > 0
        GROUP BY wj_tbClckd_lines.cl_id) t
WHERE t .diff > 90
UNION ALL
SELECT t2.cl_id, t2.diff, t2.difftype
FROM (SELECT wj_vwclrkds_kchzs.cl_id, 999 AS diff, 'D：365天以上' AS difftype
        FROM wj_vwclrkds_kchzs
        WHERE hz_month =
                  (SELECT MAX(a.hz_month)
                 FROM wj_vwclrkds_kchzs a) AND cl_id NOT IN
                  (SELECT cl_id
                 FROM wj_tbClckd_lines
                 WHERE wj_tbClckd_lines.cl_num1 > 0) AND cl_id NOT IN
                  (SELECT t1.cl_id
                 FROM (SELECT wj_tbClrkd_lines.cl_id, 
                               MIN(wj_tbClrkd_lines.create_datetime) AS rk_min_date
                         FROM wj_tbClrkd_lines
                         GROUP BY wj_tbClrkd_lines.cl_id) t1
                 WHERE datediff(day, t1.rk_min_date, getdate()) <= 90)
        GROUP BY wj_vwclrkds_kchzs.cl_id) t2




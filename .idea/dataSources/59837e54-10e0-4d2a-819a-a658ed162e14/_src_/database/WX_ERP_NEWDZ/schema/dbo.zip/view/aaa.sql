
CREATE VIEW dbo.aaa
AS
SELECT TOP 10 cppm_no, cpgg, cpgg_add, cpjh, weight, '1上期库存' AS product_line
FROM kc_tbCpkchzs kc LEFT OUTER JOIN
      iw_tbProductLine ld1 ON kc.product_line = ld1.line_no
WHERE (hz_month = '201310') AND (product_line = '0019')
UNION
SELECT TOP 10 cppm_no, cpgg, cpgg_add, cpjh, rk_weight AS weight, 
      '2-本期入库-' + ld1.line_name AS product_line
FROM kc_tbCpkchzs kc LEFT OUTER JOIN
      iw_tbProductLine ld1 ON kc.product_line_from = ld1.line_no
WHERE (hz_month = '201310' OR
      hz_month = '201311') AND (product_line = '0019') AND 
      kc.rk_date >= '2013-10-31 15:30:00' AND kc.rk_date < '2013-11-30 15:30:00'
UNION
SELECT TOP 10 cppm_no, cpgg, cpgg_add, cpjh, ck_weight AS weight, 
      '3-本期出库-' + ld1.line_name AS product_line
FROM kc_tbCpkchzs kc LEFT OUTER JOIN
      iw_tbProductLine ld1 ON kc.product_line_to = ld1.line_no
WHERE (hz_month = '201311' OR
      hz_month = '201310') AND (product_line = '0019') AND 
      kc.ck_date >= '2013-10-31 15:30:00' AND kc.ck_date < '2013-11-30 15:30:00'
UNION
SELECT TOP 10 cppm_no, cpgg, cpgg_add, cpjh, weight, 
      '3-本期库存' + ld1.line_name AS product_line
FROM kc_tbCpkchzs kc LEFT OUTER JOIN
      iw_tbProductLine ld1 ON kc.product_line = ld1.line_no
WHERE (hz_month = '201311') AND (product_line = '0019')


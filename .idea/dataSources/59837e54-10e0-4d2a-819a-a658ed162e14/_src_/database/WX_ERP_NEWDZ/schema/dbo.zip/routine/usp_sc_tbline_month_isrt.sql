







-- exec usp_sc_tbline_month_isrt '999','201607'
-- select * from sc_tbline_month where wk_yymm = '201607' and spid = 999

--delete from sc_tbline_month where wk_yymm = '201607'
-- sp_help sc_tbline_month
-- sp_help iw_tbProductLine

/*----------------------sy+20160501统计生产超时卷及未拍班计划-----------------------------------------*/
CREATE       PROCEDURE usp_sc_tbline_month_isrt  (	
						@spid			int,
						@wk_yymm 		varchar(6)						
						)

as

declare @line_no		varchar(10),
	@current_team_no	varchar(12),
	@create_user_no		varchar(24),
	@line_name		varchar(100),
	@product_end_time	datetime,
	@wk_type		varchar(10),
	@cnt_in_time		int,
	@cnt_out_time		int,
	@cnt_tot		int,
	@date_b			datetime,	--开始日期
	@date_e			datetime,	--结束日期
	@date			datetime,
	@date_sb		varchar(20),
	@cnt_days		int,
	@current_product_weight numeric(18,6)	--产量

--set @wk_yymm = '201606'
set @date    = cast((@wk_yymm + '01') as datetime)
set @date_b = DATEADD(DAY,-1,DATEADD(MONTH,DATEDIFF(MONTH,0,@Date),0)) + ' 23:31:00.000' 
set @date_e = DATEADD(MONTH,DATEDIFF(MONTH,-1,@Date),-1) + ' 23:30:00.000'
-- print @date_b
-- print @date_e
set @cnt_days = cast(substring(convert(varchar(08),@date_e,112),7,2) as int)
delete from sc_tbline_month where wk_yymm = @wk_yymm and spid = @spid

/*---------------------------------step1.表头插入按照都为排班插入------------------------------------------------------*/

insert into sc_tbline_month(spid,wk_yymm,company_no,line_no,line_name,wk_type,d1,d2,d3,d4,d5,d6,d7,d8,d9,d10,d11,d12,d13,d14,d15,d16,d17,d18,d19,d20,d21,d22,d23,d24,d25,d26,d27,d28,d29,d30,d31,CREATE_USER_NO,CREATE_DATETIME)
select	@spid,@wk_yymm,iw_tbcompanys.company_no,VWXBSC1005_3.PRODUCT_LINE as line_no,iw_tbProductLine.line_name,
	(case when VWXBSC1005_3.work_type = '01' then '夜'
	      when VWXBSC1005_3.work_type = '02' then '日'
	      when VWXBSC1005_3.work_type = '03' then '中'
	 end) as wk_type,
	0 d1,0 d2,0 d3,0 d4,0 d5,0 d6,0 d7,0 d8,0 d9,0 d10,0 d11,0 d12,0 d13,0 d14,0 d15,
	0 d16,0 d17,0 d18,0 d19,0 d20,0 d21,0 d22,0 d23,0 d24,0 d25,0 d26,0 d27,0  d28,
	case when @cnt_days >= 29 then 0 else NULL end d29,
	case when @cnt_days >= 30 then 0 else NULL end d30,
	case when @cnt_days >= 31 then 0 else NULL end d31,'admin',getdate()
from VWXBSC1005_3,VWXBSC1006_3,iw_tbProductLine,iw_tbcompanys
where VWXBSC1005_3.id=VWXBSC1006_3.master_id
and VWXBSC1005_3.PRODUCT_LINE=iw_tbProductLine.line_no
and iw_tbProductLine.company_no = iw_tbcompanys.company_id
--and VWXBSC1005_3.PRODUCT_END_TIME < VWXBSC1006_3.CREATE_DATETIME
-- and VWXBSC1005_3.PRODUCT_END_TIME <= @date_e	
-- and VWXBSC1005_3.PRODUCT_END_TIME >= @date_b
and convert(varchar(08),VWXBSC1005_3.PRODUCT_day,112) between convert(varchar(08),@date_b,112) and convert(varchar(08),@date_e,112)
group by iw_tbcompanys.company_no,VWXBSC1005_3.PRODUCT_LINE,iw_tbProductLine.line_name,
	(case when VWXBSC1005_3.work_type = '01' then '夜'
	      when VWXBSC1005_3.work_type = '02' then '日'
	      when VWXBSC1005_3.work_type = '03' then '中'
	 end) ,isnull(iw_tbProductLine.sort_num ,999)
order by isnull(iw_tbProductLine.sort_num ,999),
	(case when VWXBSC1005_3.work_type = '01' then '夜'
	      when VWXBSC1005_3.work_type = '02' then '日'
	      when VWXBSC1005_3.work_type = '03' then '中'
	 end) 


/*---------------------------------step2.update------------------------------------------------------*/
DECLARE KC_TBCPKCHZS_C1 SCROLL CURSOR FOR
     select PRODUCT_LINE,CURRENT_TEAM_NO,CREATE_USER_NO,line_name,PRODUCT_day,wk_type,sum(cnt_in_time) cnt_in_time,sum(cnt_out_time) cnt_out_time,sum(cnt_in_time)+sum(cnt_out_time) cnt_tot,sum(current_product_weight)
       from (
	     select VWXBSC1005_3.PRODUCT_LINE ,VWXBSC1005_3.CURRENT_TEAM_NO,VWXBSC1005_3.CREATE_USER_NO,iw_tbProductLine.line_name,VWXBSC1005_3.PRODUCT_day,--VWXBSC1005_3.product_end_time,
		    (case when VWXBSC1005_3.work_type = '01' then '夜'
		          when VWXBSC1005_3.work_type = '02' then '日'
		          when VWXBSC1005_3.work_type = '03' then '中'
		     end) wk_type,
	 	    isnull(CASE WHEN VWXBSC1005_3.PRODUCT_END_TIME > VWXBSC1006_3.CREATE_DATETIME THEN  COUNT(*) END,0) as cnt_in_time,
	 	    isnull(CASE WHEN VWXBSC1005_3.PRODUCT_END_TIME < VWXBSC1006_3.CREATE_DATETIME THEN  COUNT(*) END,0) as cnt_out_time,
		    sum(VWXBSC1006_3.current_product_weight) as current_product_weight--,
		   --VWXBSC1006_3.current_product_code
	       from VWXBSC1005_3,VWXBSC1006_3,iw_tbProductLine
	      where VWXBSC1005_3.id=VWXBSC1006_3.master_id
		and VWXBSC1005_3.PRODUCT_LINE=iw_tbProductLine.line_no
		--and VWXBSC1005_3.PRODUCT_END_TIME < VWXBSC1006_3.CREATE_DATETIME
-- 	        and VWXBSC1005_3.PRODUCT_END_TIME <= @date_e 
-- 		and VWXBSC1005_3.PRODUCT_END_TIME >= @date_b 
		and convert(varchar(08),VWXBSC1005_3.PRODUCT_day,112) between convert(varchar(08),@date_b,112) and convert(varchar(08),@date_e,112)
		and  VWXBSC1006_3.PRODUCT_FLAG='1'							--1..记产量 0..不计产量
		and (VWXBSC1006_3.product_adjust is null or VWXBSC1006_3.product_adjust <> '1') 	--
	        --and VWXBSC1006_3.current_product_code = '1606024001'   --'16062421810' 两班倒卷
	      group by VWXBSC1005_3.PRODUCT_LINE ,VWXBSC1005_3.CURRENT_TEAM_NO,VWXBSC1005_3.CREATE_USER_NO,iw_tbProductLine.line_name,VWXBSC1005_3.PRODUCT_day,VWXBSC1005_3.product_end_time,
	   	    (case when VWXBSC1005_3.work_type = '01' then '夜'
		          when VWXBSC1005_3.work_type = '02' then '日'
		          when VWXBSC1005_3.work_type = '03' then '中'
		     end),  VWXBSC1006_3.CREATE_DATETIME--,VWXBSC1006_3.current_product_code
		)t_a
      group by PRODUCT_LINE,CURRENT_TEAM_NO,CREATE_USER_NO,line_name,PRODUCT_day,wk_type

OPEN  KC_TBCPKCHZS_C1

FETCH NEXT FROM kc_tbcpkchzs_C1 INTO 	@line_no, @current_team_no, @create_user_no,@line_name,@product_end_time,@wk_type,@cnt_in_time,@cnt_out_time,@cnt_tot,@current_product_weight

WHILE (@@FETCH_STATUS = 0)
BEGIN

	if substring(convert(varchar(08),@product_end_time,112),1,8) = @wk_yymm +'01'
	    begin 
		update sc_tbline_month
	           set d1 = @current_product_weight--cast(@cnt_out_time as varchar(4))+'/'+cast(@cnt_tot as varchar(4))
	         where line_no = @line_no
	           and wk_type = @wk_type
		   and wk_yymm = @wk_yymm
		   and spid    = @spid
	    end 
 	if substring(convert(varchar(08),@product_end_time,112),1,8) = @wk_yymm +'02'
	    begin 
		update sc_tbline_month
	           set d2 = @current_product_weight--cast(@cnt_out_time as varchar(4))+'/'+cast(@cnt_tot as varchar(4))
	         where line_no = @line_no
	           and wk_type = @wk_type
		   and wk_yymm = @wk_yymm
		   and spid    = @spid
	    end        
 	if substring(convert(varchar(08),@product_end_time,112),1,8) = @wk_yymm +'03'
	    begin 
		update sc_tbline_month
	           set d3 = @current_product_weight--cast(@cnt_out_time as varchar(4))+'/'+cast(@cnt_tot as varchar(4))
	         where line_no = @line_no
	           and wk_type = @wk_type
		   and wk_yymm = @wk_yymm
		   and spid    = @spid
	    end 
 	if substring(convert(varchar(08),@product_end_time,112),1,8) = @wk_yymm +'04'
	    begin 
		update sc_tbline_month
	           set d4 = @current_product_weight--cast(@cnt_out_time as varchar(4))+'/'+cast(@cnt_tot as varchar(4))
	         where line_no = @line_no
	           and wk_type = @wk_type
		   and wk_yymm = @wk_yymm
		   and spid    = @spid
	    end        
 	if substring(convert(varchar(08),@product_end_time,112),1,8) = @wk_yymm +'05'
	    begin 
		update sc_tbline_month
	           set d5 = @current_product_weight--cast(@cnt_out_time as varchar(4))+'/'+cast(@cnt_tot as varchar(4))
	         where line_no = @line_no
	           and wk_type = @wk_type
		   and wk_yymm = @wk_yymm
		   and spid    = @spid
	    end        
 	if substring(convert(varchar(08),@product_end_time,112),1,8) = @wk_yymm +'06'
	    begin 
		update sc_tbline_month
	           set d6 = @current_product_weight--cast(@cnt_out_time as varchar(4))+'/'+cast(@cnt_tot as varchar(4))
	         where line_no = @line_no
	           and wk_type = @wk_type
		   and wk_yymm = @wk_yymm
		   and spid    = @spid
	    end        
 	if substring(convert(varchar(08),@product_end_time,112),1,8) = @wk_yymm +'07'
	    begin 
		update sc_tbline_month
	           set d7 = @current_product_weight--cast(@cnt_out_time as varchar(4))+'/'+cast(@cnt_tot as varchar(4))
	         where line_no = @line_no
	           and wk_type = @wk_type
		   and wk_yymm = @wk_yymm
		   and spid    = @spid
	    end        
 	if substring(convert(varchar(08),@product_end_time,112),1,8) = @wk_yymm +'08'
	    begin 
		update sc_tbline_month
	           set d8 = @current_product_weight--cast(@cnt_out_time as varchar(4))+'/'+cast(@cnt_tot as varchar(4))
	         where line_no = @line_no
	           and wk_type = @wk_type
		   and wk_yymm = @wk_yymm
		   and spid    = @spid
	    end        
 	if substring(convert(varchar(08),@product_end_time,112),1,8) = @wk_yymm +'09'
	    begin 
		update sc_tbline_month
	           set d9 = @current_product_weight--cast(@cnt_out_time as varchar(4))+'/'+cast(@cnt_tot as varchar(4))
	         where line_no = @line_no
	           and wk_type = @wk_type
		   and wk_yymm = @wk_yymm
		   and spid    = @spid
	    end        
 	if substring(convert(varchar(08),@product_end_time,112),1,8) = @wk_yymm +'10'
	    begin 
		update sc_tbline_month
	           set d10 = @current_product_weight--cast(@cnt_out_time as varchar(4))+'/'+cast(@cnt_tot as varchar(4))
	         where line_no = @line_no
	           and wk_type = @wk_type
		   and wk_yymm = @wk_yymm
		   and spid    = @spid
	    end        
 	if substring(convert(varchar(08),@product_end_time,112),1,8) = @wk_yymm +'11'
	    begin 
		update sc_tbline_month
	           set d11 = @current_product_weight--cast(@cnt_out_time as varchar(4))+'/'+cast(@cnt_tot as varchar(4))
	         where line_no = @line_no
	           and wk_type = @wk_type
		   and wk_yymm = @wk_yymm
		   and spid    = @spid
	    end        
 	if substring(convert(varchar(08),@product_end_time,112),1,8) = @wk_yymm +'12'
	    begin 
		update sc_tbline_month
	           set d12 = @current_product_weight--cast(@cnt_out_time as varchar(4))+'/'+cast(@cnt_tot as varchar(4))
	         where line_no = @line_no
	           and wk_type = @wk_type
		   and wk_yymm = @wk_yymm
		   and spid    = @spid
	    end        
 	if substring(convert(varchar(08),@product_end_time,112),1,8) = @wk_yymm +'13'
	    begin 
		update sc_tbline_month
	           set d13 = @current_product_weight--cast(@cnt_out_time as varchar(4))+'/'+cast(@cnt_tot as varchar(4))
	         where line_no = @line_no
	           and wk_type = @wk_type
		   and wk_yymm = @wk_yymm
		   and spid    = @spid
	    end        
 	if substring(convert(varchar(08),@product_end_time,112),1,8) = @wk_yymm +'14'
	    begin 
		update sc_tbline_month
	           set d14 = @current_product_weight--cast(@cnt_out_time as varchar(4))+'/'+cast(@cnt_tot as varchar(4))
	         where line_no = @line_no
	           and wk_type = @wk_type
		   and wk_yymm = @wk_yymm
		   and spid    = @spid
	    end        
 	if substring(convert(varchar(08),@product_end_time,112),1,8) = @wk_yymm +'15'
	    begin 
		update sc_tbline_month
	           set d15 = @current_product_weight--cast(@cnt_out_time as varchar(4))+'/'+cast(@cnt_tot as varchar(4))
	         where line_no = @line_no
	           and wk_type = @wk_type
		   and wk_yymm = @wk_yymm
		   and spid    = @spid
	    end        

 	if substring(convert(varchar(08),@product_end_time,112),1,8) = @wk_yymm +'16'
	    begin 
		update sc_tbline_month
	           set d16 = @current_product_weight--cast(@cnt_out_time as varchar(4))+'/'+cast(@cnt_tot as varchar(4))
	         where line_no = @line_no
	           and wk_type = @wk_type
		   and wk_yymm = @wk_yymm
		   and spid    = @spid
	    end         


 	if substring(convert(varchar(08),@product_end_time,112),1,8) = @wk_yymm +'17'
	    begin 
		update sc_tbline_month
	           set d17 = @current_product_weight--cast(@cnt_out_time as varchar(4))+'/'+cast(@cnt_tot as varchar(4))
	         where line_no = @line_no
	           and wk_type = @wk_type
		   and wk_yymm = @wk_yymm
		   and spid    = @spid
	    end         

 	if substring(convert(varchar(08),@product_end_time,112),1,8) = @wk_yymm +'18'
	    begin 
		update sc_tbline_month
	           set d18 = @current_product_weight--cast(@cnt_out_time as varchar(4))+'/'+cast(@cnt_tot as varchar(4))
	         where line_no = @line_no
	           and wk_type = @wk_type
		   and wk_yymm = @wk_yymm
		   and spid    = @spid
	    end         

 	if substring(convert(varchar(08),@product_end_time,112),1,8) = @wk_yymm +'19'
	    begin 
		update sc_tbline_month
	           set d19 = @current_product_weight--cast(@cnt_out_time as varchar(4))+'/'+cast(@cnt_tot as varchar(4))
	         where line_no = @line_no
	           and wk_type = @wk_type
		   and wk_yymm = @wk_yymm
		   and spid    = @spid
	    end         

 	if substring(convert(varchar(08),@product_end_time,112),1,8) = @wk_yymm +'20'
	    begin 
		update sc_tbline_month
	           set d20 = @current_product_weight--cast(@cnt_out_time as varchar(4))+'/'+cast(@cnt_tot as varchar(4))
	         where line_no = @line_no
	           and wk_type = @wk_type
		   and wk_yymm = @wk_yymm
		   and spid    = @spid
	    end         

 	if substring(convert(varchar(08),@product_end_time,112),1,8) = @wk_yymm +'21'
	    begin 
		update sc_tbline_month
	           set d21 = @current_product_weight--cast(@cnt_out_time as varchar(4))+'/'+cast(@cnt_tot as varchar(4))
	         where line_no = @line_no
	           and wk_type = @wk_type
		   and wk_yymm = @wk_yymm
		   and spid    = @spid
	    end         

 	if substring(convert(varchar(08),@product_end_time,112),1,8) = @wk_yymm +'22'
	    begin 
		update sc_tbline_month
	           set d22 = @current_product_weight--cast(@cnt_out_time as varchar(4))+'/'+cast(@cnt_tot as varchar(4))
	         where line_no = @line_no
	           and wk_type = @wk_type
		   and wk_yymm = @wk_yymm
		   and spid    = @spid
	    end         

 	if substring(convert(varchar(08),@product_end_time,112),1,8) = @wk_yymm +'23'
	    begin 
		update sc_tbline_month
	           set d23 = @current_product_weight--cast(@cnt_out_time as varchar(4))+'/'+cast(@cnt_tot as varchar(4))
	         where line_no = @line_no
	           and wk_type = @wk_type
		   and wk_yymm = @wk_yymm
		   and spid    = @spid
	    end         

 	if substring(convert(varchar(08),@product_end_time,112),1,8) = @wk_yymm +'24'
	    begin 
		update sc_tbline_month
	           set d24 = @current_product_weight--cast(@cnt_out_time as varchar(4))+'/'+cast(@cnt_tot as varchar(4))
	         where line_no = @line_no
	           and wk_type = @wk_type
		   and wk_yymm = @wk_yymm
		   and spid    = @spid
	    end         

 	if substring(convert(varchar(08),@product_end_time,112),1,8) = @wk_yymm +'25'
	    begin 
		update sc_tbline_month
	           set d25 = @current_product_weight--cast(@cnt_out_time as varchar(4))+'/'+cast(@cnt_tot as varchar(4))
	         where line_no = @line_no
	           and wk_type = @wk_type
		   and wk_yymm = @wk_yymm
		   and spid    = @spid
	    end         

 	if substring(convert(varchar(08),@product_end_time,112),1,8) = @wk_yymm +'26'
	    begin 
		update sc_tbline_month
	           set d26 = @current_product_weight--cast(@cnt_out_time as varchar(4))+'/'+cast(@cnt_tot as varchar(4))
	         where line_no = @line_no
	           and wk_type = @wk_type
		   and wk_yymm = @wk_yymm
		   and spid    = @spid
	    end         

 	if substring(convert(varchar(08),@product_end_time,112),1,8) = @wk_yymm +'27'
	    begin 
		update sc_tbline_month
	           set d27 = @current_product_weight--cast(@cnt_out_time as varchar(4))+'/'+cast(@cnt_tot as varchar(4))
	         where line_no = @line_no
	           and wk_type = @wk_type
		   and wk_yymm = @wk_yymm
		   and spid    = @spid
	    end         

 	if substring(convert(varchar(08),@product_end_time,112),1,8) = @wk_yymm +'28'
	    begin 
		update sc_tbline_month
	           set d28 = @current_product_weight--cast(@cnt_out_time as varchar(4))+'/'+cast(@cnt_tot as varchar(4))
	         where line_no = @line_no
	           and wk_type = @wk_type
		   and wk_yymm = @wk_yymm
		   and spid    = @spid
	    end         

 	if substring(convert(varchar(08),@product_end_time,112),1,8) = @wk_yymm +'29'
	    begin 
		update sc_tbline_month
	           set d29 =  @current_product_weight--cast(@cnt_out_time as varchar(4))+'/'+cast(@cnt_tot as varchar(4)) 
	         where line_no = @line_no
	           and wk_type = @wk_type
		   and wk_yymm = @wk_yymm
		   and spid    = @spid
	    end         

 	if substring(convert(varchar(08),@product_end_time,112),1,8) = @wk_yymm +'30'
	    begin 
		update sc_tbline_month
	           set d30 = @current_product_weight--cast(@cnt_out_time as varchar(4))+'/'+cast(@cnt_tot as varchar(4))
	         where line_no = @line_no
	           and wk_type = @wk_type
		   and wk_yymm = @wk_yymm
		   and spid    = @spid
	    end 
	
 	if substring(convert(varchar(08),@product_end_time,112),1,8) = @wk_yymm +'31'
	    begin 
		update sc_tbline_month
	           set d31 = @current_product_weight--cast(@cnt_out_time as varchar(4))+'/'+cast(@cnt_tot as varchar(4))
	         where line_no = @line_no
	           and wk_type = @wk_type
		   and wk_yymm = @wk_yymm
		   and spid    = @spid
	    end 

	FETCH NEXT FROM KC_TBCPKCHZS_C1 INTO 	@line_no, @current_team_no, @create_user_no,@line_name,@product_end_time,@wk_type,@cnt_in_time,@cnt_out_time,@cnt_tot,@current_product_weight

END 

CLOSE KC_TBCPKCHZS_C1
DEALLOCATE KC_TBCPKCHZS_C1













CREATE VIEW dbo.wj_vwcl_90not
AS
SELECT cl_id, ckdd_no, SUM(kc_num) AS kc_num, company_id, SUM(kc_num2) 
      AS kc_num2, SUM(kc_money) AS kc_money
FROM (SELECT a.cl_id, a.ckdd_no, a.kc_num, a.company_id, a.kc_num2, a.kc_money
        FROM wj_tbClkchzs AS a
        WHERE a.hz_month =
                  (SELECT MAX(d .hz_month)
                 FROM wj_tbClkchzs d)
        UNION ALL
        SELECT b.cl_id, b.ckdd_no, 0 - b.fkd_synum AS kc_num, b.company_id, 
              0 - b.fkd_synum2 AS kc_num2, 0 - b.rkd_money AS kc_money
        FROM wj_vwcl_rk90 AS b) t
GROUP BY cl_id, ckdd_no, company_id



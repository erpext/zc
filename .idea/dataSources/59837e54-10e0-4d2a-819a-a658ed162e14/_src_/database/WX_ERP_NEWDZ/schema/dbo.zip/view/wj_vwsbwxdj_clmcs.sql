CREATE VIEW dbo.wj_vwsbwxdj_clmc
AS
SELECT DISTINCT 
      TOP 100 PERCENT dbo.wj_tbSbwxdjs.clmc_no, dbo.wj_tbClmcs.clmc_name
FROM dbo.wj_tbSbwxdjs INNER JOIN
      dbo.wj_tbClmcs ON dbo.wj_tbSbwxdjs.clmc_no = dbo.wj_tbClmcs.clmc_no
ORDER BY dbo.wj_tbSbwxdjs.clmc_no

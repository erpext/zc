









--select * from  cb_tbjzdlhzs   
--delete from cb_tbjzdlhzs
--exec p_cb_tbjzdlhzs '999','201709','0027','admin',1
CREATE            procedure p_cb_tbjzdlhzs (@spid		int,
					@wk_yymm 	varchar(6),
					@line_no	varchar(4),
					@user_no	varchar(12),
					@backuplevel	int)
as
BEGIN
   
 declare @wk_yy		varchar(4),
	 @wk_mm		varchar(2),
	 @wk_last_yy	varchar(4),

 	 @weight	numeric(18,6),

	 @sql		varchar(6000),
	 @cpgg_width	numeric(18,8)
--set @wk_yymm = '201611'
--set @line_no = '0026'
set @wk_yy  	= substring(@wk_yymm,1,4)
set @wk_mm   	= cast(cast(substring(@wk_yymm,5,2) as int) as varchar(2))
set @wk_last_yy	= convert(varchar(04),dateadd(year,-1,@wk_yymm+'01'),112)

--2.insert
DECLARE cb_tbjzdlhzs_c1 CURSOR FOR 
	
	select cb_tbjzdls.line_no,cb_tbjzdls.weight,cb_tbjzdls.cpgg_width
          from cb_tbjzdls
          where wk_yymm = @wk_yymm

OPEN cb_tbjzdlhzs_c1  
FETCH NEXT FROM cb_tbjzdlhzs_c1 into @line_no,@weight,@cpgg_width
WHILE @@FETCH_STATUS = 0
    BEGIN

	exec p_cb_tbjzdls @spid,@wk_yymm,@line_no,@user_no,@backuplevel

	FETCH NEXT FROM cb_tbjzdlhzs_c1 into @line_no,@weight,@cpgg_width
    END

CLOSE cb_tbjzdlhzs_c1  --关闭游标
DEALLOCATE cb_tbjzdlhzs_c1  --释放游标
END






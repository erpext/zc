-- --select * from VWXBSC1006_XS_TBCHANGE_LINES where current_product_code = '16020321604-'
-- select current_company_no,source_company_no,pre_db_company_no,* from VWXBSC1006_XS_TBCHANGE_LINES where current_product_code = '15234434401'
-- select current_company_no,source_company_no,pre_db_company_no,* from VWXBSC1006_XS_TBCHANGE_LINES where current_product_code = '16022723710'
-- select current_company_no,source_company_no,pre_db_company_no,* from VWXBSC1006_XS_TBCHANGE_LINES where current_product_code = '1602264402'
-- select current_company_no,source_company_no,pre_db_company_no,* from VWXBSC1006_XS_TBCHANGE_LINES where current_product_code = '1602224701'
-- select current_company_no,source_company_no,pre_db_company_no,* from VWXBSC1006_XS_TBCHANGE_LINES where current_product_code = '6A42202200'

-- 
-- select  b.ck_framework_no,b.rk_framework_no
--   from kc_tbcpdb_lines a,kc_tbcpdbs b
--  where a.master_id = b.id
--    and a.cpjh = '1602264402'
-- -- 
-- 
-- select * from kc_tbcprkd_lines where cpjh = '1602264402'
-- 
-- select * from kc_tbcpckds where  id = '1239950'
-- select * from kc_tbcpckds where  id = '1239949'
-- 
-- select * from kc_tbcpckd_lines where cpjh = '1602264402'
-- 
-- select * from kc_tbcpdb_lines where  cpjh = '1602264402'
-- select * from kc_tbcpdbs where  id = '259692'
--  
-- 
-- select * from XBSC1006 where current_product_code = '1602264402'
-- 
-- select * from XBSC1005 where product_record_no = 'YXSC1602270004'

--select ck_framework_no,ck_prod_framework_no,note,* from kc_tbcprkd_lines where cpjh = '1602264402'


CREATE  VIEW dbo.VWXBSC1006_XS_TBCHANGE_LINES
AS

--1.生产信息
select a.current_product_no,a.current_product_ply,a.current_product_width,a.current_product_length,a.current_product_level,a.current_product_add_no,a.cpph,a.current_product_weight,b.current_procedure_no,
      b.product_line,a.create_datetime,b.current_company_no,b.current_workshop_no,b.current_team_no,a.current_product_code,a.source_trademark,a.source_prod_company,a.source_product_code,a.source_company_no,isnull(a.pre_db_company_no,a.source_company_no) pre_db_company_no
 from VWXBSC1006_3 a(nolock),VWXBSC1005_3 b(nolock)
where a.master_id = b.id 
 -- and a.current_company_no = @framework_no1
 -- and a.current_product_code = '16020321604'

union all

--2.销售信息变更部分
select c.new_cppm_no,c.new_cpgg_ply,c.new_cpgg_width,c.new_cpgg_length,c.new_quality_level,c.new_cpgg_add,'销售变更' as new_cpph,c.new_weight,'销售变更'as current_procedure_no,'销售变更'as product_line,c.create_datetime,b.current_company_no as current_company_no,'销售变更'as current_workshop_no,'销售变更'current_team_no,c.new_cpjh,'销售变更' as source_trademark,'销售变更' as source_prod_company,c.cpjh ,a.source_company_no,a.source_company_no
 from xs_tbchange_lines c(nolock),xs_tbchanges d(nolock), VWXBSC1006_3 a(nolock),VWXBSC1005_3 b(nolock)
where a.master_id = b.id 
  and c.master_id = d.id 
  and c.cpjh = a.current_product_code
  and c.company_id = d.company_id
  and d.framework_no = b.current_company_no
-- and c.new_cpjh = '16020321604-'

union all

--3.原料信息
-- 
select c.cppm_no,cpgg_ply,cpgg_width,cpgg_length,quality_level,cpgg_add,cpph,weight,'原料'as current_procedure_no,product_line,ys_date,framework_no,'原料'as current_workshop_no,'原料'current_team_no,cpjh,br,prod_company,'原料'+c.cpjh as source_product_code,framework_no as source_company_no,framework_no as pre_db_company_no
  from kc_vwcprkd_lines_3 c(nolock),kc_vwcprkds_3 d(nolock)
 where c.master_id = d.id
   AND d.rkdlx not in ('AZ'  ,'AY' )   --生产自动入库




-- select a.cppm_no,cpgg_ply,cpgg_width,cpgg_length,quality_level,cpgg_add,cpph,rk_weight,'原料'as current_procedure_no,product_line,rk_date,framework_no,'原料'as current_workshop_no,'原料'current_team_no,cpjh,br,prod_company,'原料' as source_product_code,framework_no as source_company_no,framework_no as pre_db_company_no
--  from kc_vwCpkchzs_3 a
-- where --rkdlx in( 'A1','AA','AD')--采购入库,外加工入库
--   --and 
--       rk_date >= '20150101'
-- --  and rk_date = (select max(rk_date) from kc_vwCpkchzs_3 where cpjh = a.cpjh ) 
-- --  and cpjh = '6A42202200'

-- select * from kc_vwCpkchzs_3 where cpjh = '6A42202200' and rkdlx = 'A1'--采购入库
-- 
-- 
-- select a.current_product_no,a.current_product_ply,a.current_product_width,a.current_product_length,a.current_product_level,a.current_product_add_no,a.cpph,a.current_product_weight,b.current_procedure_no,
--       b.product_line,a.create_datetime,b.current_company_no,b.current_workshop_no,b.current_team_no,a.current_product_code,a.source_trademark,a.source_prod_company,a.source_product_code,a.source_company_no,isnull(a.pre_db_company_no,a.source_company_no) pre_db_company_no
--  from VWXBSC1006_3 a,VWXBSC1005_3 b
-- where a.master_id = b.id 
--  -- and a.current_company_no = @framework_no1
--  and a.current_product_code = '16022010213'
-- 
-- select * from VWXBSC1006_3 where current_product_code = '16022010213'
-- 
-- --生产时自动调拨


-- union all
-- 
-- select new_cppm_no,new_cpgg_ply,new_cpgg_width,new_cpgg_length,new_quality_level,new_cpgg_add,'销售变更' as new_cpph,new_weight,'销售变更'as current_procedure_no,'销售变更'as product_line,create_datetime,company_id as current_company_no,'销售变更'as current_workshop_no,'销售变更'current_team_no,new_cpjh,'销售变更' as source_trademark,'销售变更' as source_prod_company,cpjh 
--   from xs_tbchange_lines where new_cpjh = '16020321604-'
 
-- 
-- select * from xs_tbchange_lines where new_cpjh = '16020321604-'
-- 
-- 
-- select * from xs_tbchanges where id = '4964'
-- 
-- 
-- select a.current_product_no,a.current_product_ply,a.current_product_width,a.current_product_length,a.current_product_level,a.current_product_add_no,a.cpph,a.current_product_weight,b.current_procedure_no,
--       b.product_line,a.create_datetime,b.current_company_no,b.current_workshop_no,b.current_team_no,a.current_product_code,a.source_trademark,a.source_prod_company,a.source_product_code
--  from VWXBSC1006_3 a,VWXBSC1005_3 b
-- where a.master_id = b.id 
-- 
--  and a.current_product_code = '16020321604'










CREATE VIEW dbo.xs_vwxsfhjsd_lines_3
AS
SELECT *
FROM dbo.xs_tbxsfhjsd_lines
UNION ALL
SELECT *
FROM dbo.xs_tbxsfhjsd_lines_level2
UNION ALL
SELECT *
FROM dbo.xs_tbxsfhjsd_lines_level3




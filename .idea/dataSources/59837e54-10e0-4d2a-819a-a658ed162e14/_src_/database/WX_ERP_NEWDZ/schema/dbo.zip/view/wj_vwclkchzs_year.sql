

CREATE VIEW dbo.wj_vwclkchzs_year
AS
SELECT company_id, ckdd_no, cl_id, SUM(kc0) AS kc0, SUM(kc1) AS kc1, SUM(kc2) AS kc2, 
      SUM(kc3) AS kc3
FROM (SELECT company_id, ckdd_no, cl_id, hz_month, kc_num AS kc0, 0 AS kc1, 
              0 AS kc2, 0 AS kc3
        FROM wj_tbclkchzs
        WHERE hz_month = ltrim(STR(DATEPART(YYYY, GETDATE()) - 3)) + '12'
        UNION ALL
        SELECT company_id, ckdd_no, cl_id, hz_month, 0 AS kc0, kc_num AS kc1, 
              0 AS kc2, 0 AS kc3
        FROM wj_tbclkchzs
        WHERE hz_month = ltrim(STR(DATEPART(YYYY, GETDATE()) - 2)) + '12'
        UNION ALL
        SELECT company_id, ckdd_no, cl_id, hz_month, 0 AS kc0, 0 AS kc1, 
              kc_num AS kc2, 0 AS kc3
        FROM wj_tbclkchzs
        WHERE hz_month = ltrim(STR(DATEPART(YYYY, GETDATE()) - 1)) + '12'
        UNION ALL
        SELECT company_id, ckdd_no, cl_id, hz_month, 0 AS kc0, 0 AS kc1, 0 AS kc2, 
              kc_num AS kc3
        FROM wj_tbclkchzs
        WHERE hz_month = LEFT(CONVERT(varchar(100), GETDATE(), 112), 6)) T
WHERE (company_id = 9)
GROUP BY company_id, ckdd_no, cl_id



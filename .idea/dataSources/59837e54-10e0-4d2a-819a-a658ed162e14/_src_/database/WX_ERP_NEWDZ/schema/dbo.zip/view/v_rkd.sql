CREATE VIEW dbo.v_rkd
AS
SELECT dbo.kc_tbCprkd_lines.id, dbo.kc_tbCprkd_lines.prod_company, 
      dbo.kc_tbCprkds.framework_no
FROM dbo.kc_tbCprkds INNER JOIN
      dbo.kc_tbCprkd_lines ON dbo.kc_tbCprkds.id = dbo.kc_tbCprkd_lines.master_id

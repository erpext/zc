CREATE VIEW dbo.a_rk
AS
SELECT dbo.wj_tbClrkd_lines.cllb_no, dbo.wj_tbClrkd_lines.clmc_no, 
      dbo.wj_tbClrkd_lines.clgg_no, dbo.wj_tbClrkd_lines.fkd_synum, 
      dbo.wj_tbClrkd_lines.Rkd_money, dbo.wj_tbClrkd_lines.clsldw_no, 
      dbo.wj_tbClrkds.framework_no, dbo.wj_tbClrkds.clrkd_no, dbo.wj_tbClrkds.ckry_no, 
      dbo.wj_tbClrkds.dj_date
FROM dbo.wj_tbClrkds INNER JOIN
      dbo.wj_tbClrkd_lines ON dbo.wj_tbClrkds.clrkd_id = dbo.wj_tbClrkd_lines.clrkd_id

CREATE VIEW xs_vwxsckd_lines_2 AS SELECT * FROM xs_tbxsckd_lines UNION SELECT * FROM xs_tbxsckd_lines_level2

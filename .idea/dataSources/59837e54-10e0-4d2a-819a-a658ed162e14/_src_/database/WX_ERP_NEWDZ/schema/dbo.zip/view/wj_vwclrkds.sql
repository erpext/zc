

CREATE    VIEW dbo.wj_vwclrkds
AS
SELECT dbo.wj_tbClrkds.company_id, dbo.wj_tbClrkd_lines.cl_name, 
      dbo.wj_tbClrkd_lines.cl_id, dbo.wj_tbClrkd_lines.fp_no, 
      dbo.wj_tbClrkd_lines.clsldw1_no, dbo.wj_tbClrkd_lines.clsldw2_no, 
      dbo.wj_tbClrkd_lines.fkd_synum, dbo.wj_tbClrkd_lines.fkd_synum2, 
      dbo.wj_tbClrkd_lines.rkd_money, dbo.wj_tbClrkd_lines.ghs_id, 
      dbo.wj_tbClrkds.dj_date, dbo.wj_tbClrkds.ys_date, dbo.wj_tbClrkds.ys_no, 
      dbo.wj_tbClrkds.cgry_no, dbo.wj_tbClrkds.clrkd_no, dbo.wj_tbClrkds.ckry_no, 
      dbo.wj_tbClrkd_lines.clrkd_line_id, dbo.wj_tbClrkd_lines.ckdd_no, 
      dbo.wj_clb.clfl1_name, dbo.wj_clb.clfl2_name, dbo.wj_clb.clfl3_name, 
      dbo.wj_clb.clfl4_name, dbo.wj_clb.clfl5_name, dbo.wj_clb.clfl6_name, 
      dbo.wj_clb.clfl7_name, dbo.wj_clb.clfl8_name, dbo.wj_clb.clfl9_name, 
      dbo.wj_clb.clfl_lvl, dbo.wj_tbClrkds.sh_flag, dbo.wj_tbClrkds.clrkd_type, 
      dbo.wj_tbClrkd_lines.fp_price, dbo.wj_tbClrkd_lines.rkd_fpnum, 
      dbo.wj_tbClrkd_lines.fp_money, dbo.wj_tbClrkd_lines.fp_flag, 
      dbo.wj_tbClrkds.create_user_no, dbo.wj_tbClrkds.create_datetime AS Expr1, 
      dbo.wj_tbClrkd_lines.create_datetime, dbo.wj_tbClrkds.clrkd_id, dbo.wj_clb.clfl9_id, 
      dbo.wj_clb.clfl8_id, dbo.wj_clb.clfl7_id, dbo.wj_clb.clfl6_id, dbo.wj_clb.clfl5_id, 
      dbo.wj_clb.clfl4_id, dbo.wj_clb.clfl3_id, dbo.wj_clb.clfl2_id, dbo.wj_clb.clfl1_id, 
      dbo.wj_tbClrkds.shr, dbo.wj_tbClrkds.clrkd_unite_type,dbo.wj_tbClrkd_lines.rkd_money_hs,
      dbo.wj_tbClrkd_lines.vat_rate,dbo.wj_tbClrkds.cw_sh_flag, dbo.wj_tbClrkd_lines.remark as remark_lines
FROM dbo.wj_tbClrkds INNER JOIN
      dbo.wj_tbClrkd_lines ON 
      dbo.wj_tbClrkds.clrkd_id = dbo.wj_tbClrkd_lines.clrkd_id INNER JOIN
      dbo.wj_clb ON dbo.wj_tbClrkd_lines.cl_id = dbo.wj_clb.cl_id








CREATE VIEW dbo.xs_vwXsthds_2
AS
SELECT *
FROM dbo.xs_tbXsthds
UNION ALL
SELECT *
FROM dbo.xs_tbXsthds_level2




CREATE VIEW dbo.kc_vwcpckd
AS
SELECT dbo.kc_tbCpckds.kh_no, dbo.kc_tbCpckds.ck_date, 
      dbo.kc_tbCpckd_lines.cppm_no, dbo.kc_tbCpckd_lines.cpjh, 
      dbo.kc_tbCpckd_lines.sldw, dbo.kc_tbCpckd_lines.weight, dbo.kc_tbCpckd_lines.note, 
      dbo.kc_tbCpckd_lines.rk_framework_no, dbo.kc_tbCpckd_lines.cpgg_ply, 
      dbo.kc_tbCpckd_lines.cpgg_width, dbo.kc_tbCpckd_lines.cpgg_length, 
      dbo.kc_tbCpckd_lines.cpgg_color, dbo.kc_tbCpckd_lines.cpgg, 
      dbo.kc_tbCpckd_lines.cpgg_ply_t, dbo.kc_tbCpckds.send_framework_no, 
      dbo.kc_tbCpckds.prod_framework_no, dbo.kc_tbCpckds.prod_workshop_no, 
      dbo.kc_tbCpckds.receive_framework_no, dbo.kc_tbCpckds.ysr, dbo.kc_tbCpckds.cklx, 
      dbo.kc_tbCpckds.thr, dbo.kc_tbCpckds.sbyfhr, dbo.kc_tbCpckds.ck_note, 
      dbo.kc_tbCpckds.company_id, dbo.kc_tbCpckds.data_id, dbo.kc_tbCpckd_lines.ckdd, 
      dbo.kc_tbCpckd_lines.master_id
FROM dbo.kc_tbCpckds INNER JOIN
      dbo.kc_tbCpckd_lines ON dbo.kc_tbCpckds.id = dbo.kc_tbCpckd_lines.master_id

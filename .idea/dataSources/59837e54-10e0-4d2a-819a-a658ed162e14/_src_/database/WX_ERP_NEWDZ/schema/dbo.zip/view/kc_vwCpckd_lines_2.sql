CREATE VIEW kc_vwCpckd_lines_2 AS SELECT * FROM kc_tbcpckd_lines UNION SELECT * FROM kc_tbCpckd_lines_level2

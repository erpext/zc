CREATE VIEW dbo.jp_cpk_test
AS
SELECT dbo.kc_tbCprkd_lines.cppm_no, dbo.kc_tbCprkd_lines.id, 
      dbo.kc_tbCpkchzs.cprkd_line_id, dbo.kc_tbCpkchzs.hz_month, 
      dbo.kc_tbCprkd_lines.cpgg_length, 
      dbo.kc_tbCpkchzs.cpgg_length AS hz_length
FROM dbo.kc_tbCprkd_lines INNER JOIN
      dbo.kc_tbCpkchzs ON dbo.kc_tbCprkd_lines.id = dbo.kc_tbCpkchzs.cprkd_line_id

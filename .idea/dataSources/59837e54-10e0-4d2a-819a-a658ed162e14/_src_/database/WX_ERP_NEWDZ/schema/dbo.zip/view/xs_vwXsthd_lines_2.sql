CREATE VIEW dbo.xs_vwXsthd_lines_2
AS
SELECT *
FROM dbo.xs_tbXsthd_lines
UNION
SELECT *
FROM dbo.xs_tbXsthd_lines_level2

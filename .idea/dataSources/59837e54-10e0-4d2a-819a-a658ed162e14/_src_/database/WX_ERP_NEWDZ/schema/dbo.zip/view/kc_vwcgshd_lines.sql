CREATE VIEW dbo.kc_vwcgshd_lines
AS
SELECT dbo.cg_tbCgshds.cgshddh, dbo.cg_tbCgshds.shrq, dbo.cg_tbCgshds.ylghdw_no, 
      dbo.cg_tbCgshds.shdd, dbo.cg_tbCgshds.cgry, dbo.cg_tbCgshd_lines.ylpm_no, 
      dbo.cg_tbCgshd_lines.ylgg_hd, dbo.cg_tbCgshd_lines.ylgg_kd, 
      dbo.cg_tbCgshd_lines.sldw, dbo.cg_tbCgshd_lines.weight, 
      dbo.cg_tbCgshd_lines.finish_flag, dbo.cg_tbCgshd_lines.ja_2, 
      dbo.cg_tbCgshd_lines.note, ' ' AS expr1
FROM dbo.cg_tbCgshds INNER JOIN
      dbo.cg_tbCgshd_lines ON dbo.cg_tbCgshds.id = dbo.cg_tbCgshd_lines.master_id



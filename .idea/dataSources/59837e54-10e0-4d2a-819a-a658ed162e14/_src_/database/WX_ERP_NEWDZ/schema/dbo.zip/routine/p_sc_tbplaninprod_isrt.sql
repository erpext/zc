





--delete from sc_tbplaninprod where   wk_yymm = '201701'
--exec p_sc_tbplaninprod_isrt '777','2017-3-23','0051','admin'
-- select * from sc_tbplaninprod where spid =777
-- select * from sc_tbplanin
-- select * from sc_tbprodin


CREATE             procedure p_sc_tbplaninprod_isrt 	(@spid		int,
						@wk_yymmdd 	datetime,
						@line_no	varchar(4),
						@user_no	varchar(12))
as
BEGIN
 declare @id		int
 declare @wk_yy		varchar(4),
	 @wk_mm		varchar(2),
	 @wk_yymm	varchar(6),
	 @wk_last_yymm	varchar(6),
	 @wk_last_yymmdd	datetime,
 	 @cpgg		varchar(40),
 	 @banbie	varchar(2),
 	 @fb_type	varchar(2),
	 @product_line  varchar(4),
 	 @workload	numeric(18,3), --产量
 	 @workload_prod	numeric(18,3), --产量
 	 @workload_prod_01_sq	numeric(18,3), --产量
 	 @workload_prod_02_sq 	numeric(18,3), --产量
 	 @workload_prod_03_sq	numeric(18,3), --产量
 	 @workload_prod_01_bq	numeric(18,3), --产量
 	 @workload_prod_02_bq 	numeric(18,3), --产量
 	 @workload_prod_03_bq	numeric(18,3), --产量
	 @workload_prod_01_bq_y numeric(18,3), --产量
	 @workload_prod_01_bq_r numeric(18,3), --产量
	 @workload_prod_01_bq_z numeric(18,3), --产量

	 @workload_plan_sq	numeric(18,3),	--计划
	 @workload_plan1_sq	numeric(18,3),	--计划1
	 @workload_plan_add_bq numeric(18,3),
 	 @prod_date	datetime

delete from sc_tbplaninprod where  spid = @spid

--1.插入表头
insert into sc_tbplaninprod  (spid,prod_date,product_line,cpgg_ply,cpgg_width,cpgg_length,cpgg,create_user_no,create_datetime )
   select @spid,@wk_yymmdd,product_line,cpgg_ply,cpgg_width,cpgg_length,cpgg,@user_no,getdate()
     from sc_tbplanin
    where isnull(flag,0) = 0
      and convert(varchar(08),plan_date,112) <= @wk_yymmdd
-- UNION 
--    select @spid,@wk_yymmdd,product_line,cpgg_ply,cpgg_width,cpgg_length,cpgg,@user_no,getdate()
--      from sc_tbplanin
--   	   WHERE isnull(flag,0) = 1
--            and convert(varchar(08),end_plan_date,112) > @wk_yymmdd
--            and product_line = @product_line
-- 	   and convert(varchar(08),plan_date,112) < @wk_yymmdd
    union 
   select @spid,@wk_yymmdd,product_line,cpgg_ply,cpgg_width,cpgg_length,cpgg ,@user_no,getdate()
     from sc_tbprodin
    where convert(varchar(08),prod_date,112) <= @wk_yymmdd

IF  @@ERROR <> 0 
	BEGIN
		RAISERROR('sc_tbplaninprod INSERT ERROR',16,-1)
		RETURN -1
	END  

DECLARE sc_tbplaninprod_C1 SCROLL CURSOR FOR

    select id,cpgg,product_line
      from sc_tbplaninprod
     where spid = @spid
       and convert(varchar(08),prod_date,112) =@wk_yymmdd 

OPEN  sc_tbplaninprod_C1

FETCH NEXT FROM sc_tbplaninprod_C1 INTO @id,@cpgg,@product_line

WHILE (@@FETCH_STATUS = 0)
BEGIN

	select @workload_plan_sq = isnull(sum(workload),0)	--日期前未完成计划量
          from sc_tbplanin 
	 where cpgg = @cpgg
           and convert(varchar(08),plan_date,112) < @wk_yymmdd
	   and isnull(flag,0) = 0
           and product_line = @product_line


	select @workload_plan1_sq = isnull(sum(workload),0)	--完成日期》查询日期的计划量
          from sc_tbplanin 
	 where cpgg = @cpgg
  	   and isnull(flag,0) = 1
           and convert(varchar(08),end_plan_date,112) > @wk_yymmdd
           and product_line = @product_line
	   and convert(varchar(08),plan_date,112) < @wk_yymmdd


	select @workload_plan_add_bq = isnull(sum(workload),0)	--本期新增计划量
          from sc_tbplanin 
	 where cpgg = @cpgg
           and convert(varchar(08),plan_date,112) =@wk_yymmdd
	  -- and flag = 0
           and product_line = @product_line

	select @workload_prod_01_sq = isnull(sum(workload),0)	--期前生产量
          from sc_tbprodin 
	 where cpgg = @cpgg
           and convert(varchar(08),prod_date,112) < @wk_yymmdd
	   and fb_type = '01'
           and product_line = @product_line

	select @workload_prod_02_sq = isnull(sum(workload),0)	--期前封闭量
          from sc_tbprodin 
	 where cpgg = @cpgg
           and convert(varchar(08),prod_date,112) < @wk_yymmdd
	   and fb_type = '02'
           and product_line = @product_line

	select @workload_prod_03_sq = isnull(sum(workload),0)	--期前解封量
          from sc_tbprodin 
	 where cpgg = @cpgg
           and convert(varchar(08),prod_date,112) < @wk_yymmdd
	   and fb_type = '03'
           and product_line = @product_line

	
	select @workload_prod_02_bq = isnull(sum(workload),0)	--本期封闭量
	  from sc_tbprodin
         where cpgg = @cpgg
           and convert(varchar(08),prod_date,112) = @wk_yymmdd
	   and fb_type = '02'
           and product_line = @product_line

	select @workload_prod_03_bq = isnull(sum(workload),0)	--本期解封量
	  from sc_tbprodin
         where cpgg = @cpgg
           and convert(varchar(08),prod_date,112) = @wk_yymmdd
	   and fb_type = '03'
           and product_line = @product_line

	select @workload_prod_01_bq_y = isnull(sum(workload),0)	--本期夜班生产量
	  from sc_tbprodin
         where cpgg = @cpgg
           and convert(varchar(08),prod_date,112)  = @wk_yymmdd
	   and fb_type = '01'
	   and banbie = '01'
           and product_line = @product_line

	select @workload_prod_01_bq_r = isnull(sum(workload),0)	--本期日班生产量
	  from sc_tbprodin
         where cpgg = @cpgg
           and convert(varchar(08),prod_date,112) = @wk_yymmdd
	   and fb_type = '01'
	   and banbie = '02'
           and product_line = @product_line

	select @workload_prod_01_bq_z = isnull(sum(workload),0)	--本期中班生产量
	  from sc_tbprodin
         where cpgg = @cpgg
           and convert(varchar(08),prod_date,112) = @wk_yymmdd
	   and fb_type = '01'
	   and banbie = '03'
           and product_line = @product_line



	--上汽未完成计划
	update sc_tbplaninprod
           set --sq_wwc = @workload_plan_sq + @workload_plan1_sq - @workload_prod_01_sq + @workload_prod_02_sq ,
		sq_wwc = @workload_plan_sq + @workload_plan1_sq ,

	       bq_zj  = @workload_plan_add_bq,
               zr_cl  = (select sum(workload) from sc_tbprodin where fb_type = '01'and prod_date = dateadd(dd ,-1,@wk_yymmdd) and cpgg = @cpgg and product_line = @product_line ),
	       dr_cl_ye = @workload_prod_01_bq_y,
	       dr_cl_ri = @workload_prod_01_bq_r,
	       dr_cl_zh = @workload_prod_01_bq_z,
	       dr_cl_hj = @workload_prod_01_bq_y + @workload_prod_01_bq_r + @workload_prod_01_bq_z,
	       --bq_wwc   =(@workload_plan_sq - @workload_prod_01_sq + @workload_prod_02_sq)+ @workload_plan_add_bq - ( @workload_prod_01_bq_y + @workload_prod_01_bq_r + @workload_prod_01_bq_z) + @workload_prod_02_bq,
	       bq_wwc   =(@workload_plan_sq + @workload_plan1_sq)+ @workload_plan_add_bq - ( @workload_prod_01_bq_y + @workload_prod_01_bq_r + @workload_prod_01_bq_z) + @workload_prod_02_bq,
	
	       sq_fb_jc = @workload_prod_02_sq - @workload_prod_03_sq,
	       bq_fb	= @workload_prod_02_bq,
	       bq_jf    = @workload_prod_03_bq,
	       bq_fb_jc =(@workload_prod_02_sq - @workload_prod_03_sq)  +  @workload_prod_02_bq - @workload_prod_03_bq,
	       update_user_no = @user_no,
	       update_datetime = getdate()
	 where cpgg = @cpgg
           and id = @id
           and spid = @spid
           and product_line = @product_line
	   and prod_date = @wk_yymmdd

	FETCH NEXT FROM sc_tbplaninprod_C1 INTO @id,@cpgg ,@product_line

END

CLOSE sc_tbplaninprod_C1
DEALLOCATE sc_tbplaninprod_C1

END

--select *   from sc_tbplaninprod




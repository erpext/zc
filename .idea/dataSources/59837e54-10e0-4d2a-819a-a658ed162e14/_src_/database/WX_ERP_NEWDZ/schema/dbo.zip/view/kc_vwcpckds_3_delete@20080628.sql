
CREATE VIEW dbo.kc_vwcpckds_3
AS
SELECT *
FROM dbo.kc_tbCpckds
UNION
SELECT *
FROM dbo.kc_tbCpckds_level2
UNION
SELECT *
FROM dbo.kc_tbCpckds_level3


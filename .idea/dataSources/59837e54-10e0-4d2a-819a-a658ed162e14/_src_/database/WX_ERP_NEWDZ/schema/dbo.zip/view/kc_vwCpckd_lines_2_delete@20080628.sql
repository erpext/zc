
CREATE VIEW dbo.kc_vwCpckd_lines_2
AS
SELECT *
FROM dbo.kc_tbCpckd_lines
UNION
SELECT *
FROM dbo.kc_tbCpckd_lines_level2



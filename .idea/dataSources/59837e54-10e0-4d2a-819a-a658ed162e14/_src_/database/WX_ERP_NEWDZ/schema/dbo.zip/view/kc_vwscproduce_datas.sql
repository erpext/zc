CREATE VIEW dbo.kc_vwscproduce_datas
AS
SELECT dbo.sc_tbproduce_datas.framework_no, dbo.sc_tbproduce_datas.workshop, 
      dbo.sc_tbproduce_datas.produce_datetime_b, dbo.sc_tbproduce_datas.team_no, 
      dbo.sc_tbproduce_datas.produce_datetime_e, dbo.sc_tbproduce_data_lines.spec, 
      dbo.sc_tbproduce_data_lines.spec_ply, dbo.sc_tbproduce_data_lines.spec_length, 
      dbo.sc_tbproduce_data_lines.spec_width, dbo.sc_tbproduce_data_lines.spec_color, 
      dbo.sc_tbproduce_data_lines.finish_flag, dbo.sc_tbproduce_data_lines.weight, 
      dbo.sc_tbproduce_data_lines.wrap, '' AS Expr1, 
      dbo.sc_tbproduce_datas.produce_datetime_e AS Expr2, 
      dbo.sc_tbproduce_data_lines.produce_data_line_id, 
      dbo.sc_tbproduce_data_lines.data_id, dbo.sc_tbproduce_data_lines.quality_level, 
      dbo.sc_tbproduce_data_lines.sldw
FROM dbo.sc_tbproduce_datas INNER JOIN
      dbo.sc_tbproduce_data_lines ON 
      dbo.sc_tbproduce_datas.produce_data_id = dbo.sc_tbproduce_data_lines.produce_data_id

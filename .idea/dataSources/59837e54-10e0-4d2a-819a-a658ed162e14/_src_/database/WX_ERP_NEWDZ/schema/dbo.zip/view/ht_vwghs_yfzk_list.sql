
create view ht_vwghs_yfzk_list
as 
select a.ghs_id,
       a.company_id,
       b.clrkd_no,
       a.fp_no,
       count(b.clrkd_no) as num0,
       0   as num1,
       0   as fp_money
from wj_tbclrkd_lines a , wj_tbclrkds b
where a.clrkd_id = b.clrkd_id and a.fp_flag = 0 and b.sh_flag = 1
group by a.ghs_id,a.company_id,b.clrkd_no,a.fp_no
union
select a.ghs_id,
       a.company_id,
       b.clrkd_no,
       a.fp_no,
       0 as num0,
       count(b.clrkd_no) as num1,
       sum(fp_money) as fp_money
from wj_tbclrkd_lines a , wj_tbclrkds b
where a.clrkd_id = b.clrkd_id and a.fp_flag = 1 and b.sh_flag = 1
group by a.ghs_id,a.company_id,b.clrkd_no,a.fp_no


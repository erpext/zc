
CREATE VIEW dbo.cb_vwkhdjcx
AS
SELECT dbo.cb_khdj.company_id, dbo.cb_khdj.kh_no, dbo.cb_khdj.workshop_no, 
      dbo.cb_khdj.unit_no, dbo.cb_khdj.kh_date, dbo.cb_khdj.total_qty, 
      dbo.cb_khdj.total_pfmj, dbo.cb_khdj_mx.item_id, dbo.cb_khdj_mx.item_name, 
      dbo.cb_khdj_mx.clfl_lvl, dbo.cb_khdj_mx.sjhy_qty, dbo.cb_khdj_mx.sjhy_money, 
      dbo.cb_khdj_mx.sjdh_qty, dbo.cb_khdj_mx.sjdh_money, dbo.cb_khdj_mx.jhdh_qty, 
      dbo.cb_khdj_mx.jhdh_moeny, dbo.cb_khdj_mx.dh_award, 
      dbo.cb_khdj_mx.dh_punish, dbo.cb_khdj.create_user_no, dbo.cb_khdj.id
FROM dbo.cb_khdj INNER JOIN
      dbo.cb_khdj_mx ON dbo.cb_khdj.id = dbo.cb_khdj_mx.master_id


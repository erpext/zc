CREATE VIEW dbo.zl_vmzlzm
AS
SELECT dbo.xs_tbXsthds.xsthddh, dbo.xs_tbxsckd_lines.wlpm_no, 
      dbo.zl_tbProductQuality.prec, dbo.zl_tbProductQuality.jh, 
      dbo.zl_tbProductQuality.workshop_no, dbo.zl_tbProductQuality.Quality_type, 
      dbo.zl_tbProductQuality.Product_type, dbo.zl_tbProductQuality.zjr, 
      dbo.zl_tbProductQuality.zj_datetime, dbo.zl_tbProductQuality.note, 
      dbo.zl_tbProductQuality.result, dbo.zl_tbProductQuality.company_id, 
      dbo.zl_tbProductQuality.hxcf_c, dbo.zl_tbProductQuality.hxcf_si, 
      dbo.zl_tbProductQuality.hxcf_mn, dbo.zl_tbProductQuality.hxcf_p, 
      dbo.zl_tbProductQuality.hxcf_s, dbo.zl_tbProductQuality.smooth, 
      dbo.zl_tbProductQuality.ldw, dbo.zl_tbProductQuality.qxl, 
      dbo.zl_tbProductQuality.bmzk, dbo.zl_tbProductQuality.bmzl, 
      dbo.zl_tbProductQuality.ccjd, dbo.zl_tbProductQuality.bmjg, 
      dbo.zl_tbProductQuality.bmcl, dbo.zl_tbProductQuality.dxl, 
      dbo.zl_tbProductQuality.shw, dbo.zl_tbProductQuality.dgl, 
      dbo.zl_tbProductQuality.jgxl, dbo.zl_tbProductQuality.yd, dbo.zl_tbProductQuality.btz, 
      dbo.zl_tbProductQuality.klqd, dbo.zl_tbProductQuality.ysl, 
      dbo.zl_tbProductQuality.qfqd, dbo.zl_tbProductQuality.wqsy, 
      dbo.zl_tbProductQuality.lwz, dbo.zl_tbProductQuality.yt, 
      dbo.zl_tbProductQuality.dhfs, dbo.zl_tbProductQuality.jc, dbo.zl_tbProductQuality.tyl, 
      dbo.zl_tbProductQuality.tchd, dbo.zl_tbProductQuality.tclx, 
      dbo.zl_tbProductQuality.tcjg, dbo.zl_tbProductQuality.tcys, 
      dbo.zl_tbProductQuality.gz, dbo.zl_tbProductQuality.qbyd, 
      dbo.zl_tbProductQuality.fcjsy, dbo.zl_tbProductQuality.mek, 
      dbo.zl_tbProductQuality.lyw, dbo.zl_tbProductQuality.llh, 
      dbo.xs_tbxsckd_lines.weight, dbo.zl_tbProductQuality.xczl
FROM dbo.zl_tbProductQuality INNER JOIN
      dbo.xs_tbxsckd_lines INNER JOIN
      dbo.xs_tbXsthds ON 
      dbo.xs_tbxsckd_lines.master_id = dbo.xs_tbXsthds.id INNER JOIN
      dbo.kc_tbCprkd_lines ON 
      dbo.xs_tbxsckd_lines.wlpm_no = dbo.kc_tbCprkd_lines.cppm_no AND 
      dbo.xs_tbxsckd_lines.wljh = dbo.kc_tbCprkd_lines.cpjh INNER JOIN
      dbo.kc_tbCprkds ON dbo.kc_tbCprkd_lines.master_id = dbo.kc_tbCprkds.id ON 
      dbo.zl_tbProductQuality.workshop_no = dbo.kc_tbCprkds.prod_workshop_no AND 
      dbo.zl_tbProductQuality.jh = dbo.kc_tbCprkd_lines.cpjh

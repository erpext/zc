CREATE VIEW dbo.kc_vwcprkd
AS
SELECT dbo.kc_tbCprkds.prod_framework_no, dbo.kc_tbCprkds.prod_workshop_no, 
      dbo.kc_tbCprkds.ysr_no, dbo.kc_tbCprkds.ys_date, dbo.kc_tbCprkds.framework_no, 
      dbo.kc_tbCprkds.ckdd, dbo.kc_tbCprkd_lines.cppm_no, dbo.kc_tbCprkd_lines.cpgg, 
      dbo.kc_tbCprkd_lines.cpgg_ply_t, dbo.kc_tbCprkd_lines.cpjh, 
      dbo.kc_tbCprkd_lines.sldw, dbo.kc_tbCprkd_lines.weight
FROM dbo.kc_tbCprkd_lines INNER JOIN
      dbo.kc_tbCprkds ON dbo.kc_tbCprkd_lines.master_id = dbo.kc_tbCprkds.id

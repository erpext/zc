CREATE VIEW dbo.wj_vwclrkfp_insert
AS
SELECT TOP 100 PERCENT dbo.wj_tbClrkd_lines.clrkd_line_id, 
      dbo.wj_tbClmcs.clmc_name, dbo.wj_tbClggs.clgg_name, 
      dbo.wj_tbClrkd_lines.ghs_no, dbo.wj_tbClrkd_lines.fkd_synum, 
      dbo.wj_tbClrkds.framework_no, dbo.wj_tbClrkds.clrkd_no, 
      dbo.wj_tbClrkd_lines.clmc_no, dbo.wj_tbClrkd_lines.clgg_no, '' AS Expr1, 
      dbo.wj_tbClrkds.dj_date, dbo.wj_tbClrkd_lines.clsldw_no, 
      dbo.wj_tbClrkds.ys_date
FROM dbo.wj_tbClrkds INNER JOIN
      dbo.wj_tbClrkd_lines ON 
      dbo.wj_tbClrkds.clrkd_id = dbo.wj_tbClrkd_lines.clrkd_id INNER JOIN
      dbo.wj_tbClmcs ON 
      dbo.wj_tbClrkd_lines.clmc_no = dbo.wj_tbClmcs.clmc_no INNER JOIN
      dbo.wj_tbClggs ON dbo.wj_tbClrkd_lines.clgg_no = dbo.wj_tbClggs.clgg_no
WHERE (dbo.wj_tbClrkd_lines.fp_no IS NULL)
ORDER BY dbo.wj_tbClrkd_lines.clrkd_line_id

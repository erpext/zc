// 页面初始化时 就调用的方法
$(function() {
    //todo: 进入页面的时候，拉取数据，并给仓库 赋值
    let store1 = [{id:1,name:'仓库1'},{id:2,name:'仓库2'},{id:3,name:'仓库3'},{id:4,name:'仓库4'}]
    let store2 = [{id:1,name:'仓库1'},{id:2,name:'仓库2'},{id:3,name:'仓库3'},{id:4,name:'仓库4'}]
    
    // 添加 移出库 名单
    for (const val of store1) {
        $("#out_store").append("<option value='"+val.id+"'>"+val.name+"</option>");
    }
    // 添加 移入库 名单
    for (const val of store2) {
        $("#in_store").append("<option value='"+val.id+"'>"+val.name+"</option>");
    }
})

// todo:扫描框 点击事件（需要去集成 调取 微信扫码功能）
function scanClick(id){

    //todo: 修改 num_+id 显示文字
    $("#num_"+id).html(id)
    //todo: 给 num_+id 赋值 
    $("#num_"+id).val('我是id ' + id);

    $("#num_"+id).css("color","#333");
}

//删除按钮点击事件
function deleteClick(id){
    $("#num_"+id).html('请点此进行扫码')
    $("#num_"+id).css("color","lightgrey");
    $("#num_"+id).val(null);
}

function confirmClick(){
    // 移出库 值
    let outStore = $("#out_store").val()
    // 移入仓库 值
    let inStore = $("#in_store").val()
    //单号
    let val1 = $("#num_1").val();
    let val2 = $("#num_2").val();
    let val3 = $("#num_3").val();
    let val4 = $("#num_4").val();

    //todo:
    alert(outStore + inStore + val1 + val2 + val3 + val4);
}
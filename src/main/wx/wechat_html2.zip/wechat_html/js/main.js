
$(function() {
    //页面初始化时 就会调用的方法
    console.log('index.html 初始化好啦');


    
})